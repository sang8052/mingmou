#pragma once

// 自动加载 api 模型类, 这里需要手动将所有需要加载的类include 添加进来
#include "api_http_handle.h"

#include "api_file.h"
#include "api_auth.h"
#include "api_user.h"
#include "api_video.h"
#include "api_face.h"

#include "api_sys_config.h"