#pragma once
#include <vector>
#include "../ai_db.h"
#include "../arest/http_handle.h"
#include "../arest/arest_struct.h"
#include "../thread/thread_struct.h"

