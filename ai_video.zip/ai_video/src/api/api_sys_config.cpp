#include "api_sys_config.h"

void api_sys_config::on_http_query_sys_config(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value rqParams = http->get_http_request_query();
    int pageSize = 10; int pageNum = 1;
    if(rqParams["pagenum"].isString())   pageNum = atoi(rqParams["pagenum"].asString().c_str());
    if(rqParams["pagesize"].isString())  pageSize = atoi(rqParams["pagesize"].asString().c_str());
    if(pageNum <= 0) pageNum = 1;  if(pageSize <=0) pageSize = 10;
    string keyword = ""; string link_table = ""; int link_id = -1;
    if(rqParams["keyword"].isString())     keyword = rqParams["keyword"].asString();
    if(rqParams["link_table"].isString())  link_table =  rqParams["link_table"].asString();
    if(rqParams["link_id"].isString())     link_id =  atoi(rqParams["link_id"].asString().c_str());
    Json::Value data = db->query_sys_config(keyword,link_table,link_id,pageNum,pageSize);
    Json::Value response;
    response["code"] = 0; response["msg"] = "查询成功";
    response["data"] = data;
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200; 
}

void api_sys_config::on_http_create_sys_config(void *handle)
{
    http_handle *http = (http_handle*)handle;
    Json::Value response; Json::Value data;
    int user_level = http->request_session["level"].asInt();
    if(user_level != 2){
        response["code"] = 5000004; response["msg"] = "你无权限请求该接口!"; response["data"] = Json::Value::null;
    }
    else{
        ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
        Json::Value rqBody = http->get_http_request_body();
       
        string item = ""; string value = "";; string extend = ""; string link_table = "";; int link_id = 0;
        if(rqBody["item"].isString())   item = rqBody["item"].asString();
        if(rqBody["value"].isString())  value = rqBody["value"].asString();
        if(rqBody["extend"].isString()) extend = rqBody["extend"].asString();
        if(rqBody["link_table"].isString())  link_table =  rqBody["link_table"].asString();
        if(rqBody["link_id"].isInt())  link_id =  rqBody["link_id"].asInt();
        if(item == "") {
            response["code"] = 5000201; response["msg"] = "字段 item 的值不能为空";
            response["data"] = Json::nullValue;
        }
        if(db->exist_sys_config(item,link_table)){
            response["code"] = 5000501; response["msg"] = "已经存在该配置项";
            data["item"] = item;
            response["data"] = data;
        }
        else{
            if(link_table!= "" && link_id == 0){
                response["code"] = 5000201; response["msg"] = "传入 link_table 时,link_id 不能为空";
                response["data"] = Json::nullValue;
            }
            else{
                if(link_table == "") data["config_id"] = db->create_sys_config(item,value,extend);
                else data["config_id"] = db->create_sys_config(item,value,extend,link_table,link_id);
                response["code"] = 0 ;  response["msg"] = "新增配置项成功";
                response["data"] = data;
            }
      
        }
    }
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200; 
}

void api_sys_config::on_http_delete_sys_config(void *handle)
{
    http_handle *http = (http_handle*)handle;
    Json::Value response; Json::Value data;
    int user_level = http->request_session["level"].asInt();
    if(user_level != 2){
        response["code"] = 5000004; response["msg"] = "你无权限请求该接口!"; response["data"] = Json::Value::null;
    }
    else{
        ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
        Json::Value rqRoute = http->get_http_request_route();
        int config_id = atoi(rqRoute["config_id"].asString().c_str()); 
        db->delete_sys_config(config_id);
        response["code"] = 0; response["msg"] = "删除系统配置项成功";
        response["data"] = Json::Value::null;
    }
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200; 
}

void api_sys_config::on_http_update_sys_config(void *handle)
{
    http_handle *http = (http_handle*)handle;
    Json::Value response; Json::Value data;
    int user_level = http->request_session["level"].asInt();
    if(user_level != 2){
        response["code"] = 5000004; response["msg"] = "你无权限请求该接口!"; response["data"] = Json::Value::null;
    }
    else{
        ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
        Json::Value rqRoute = http->get_http_request_route();
        int config_id = atoi(rqRoute["config_id"].asString().c_str()); 
        string value = ""; string extend = "";
        Json::Value detail = db->query_sys_config_by_config_id(config_id);
        if(detail.size() == 0) {
            response["code"] = 5000502; response["msg"] = "指定的配置项目不存在";
            data["config_id"] = config_id;
            response["data"] = data;
        }
        Json::Value rqBody = http->get_http_request_body();
        if(rqBody["value"].isString())  value = rqBody["value"].asString();
        else value = detail[0]["config_value"].asString();
        if(rqBody["extend"].isString()) extend = rqBody["extend"].asString();
        else extend = detail[0]["extend"].asString();
        db->update_sys_config(config_id,value,extend);
        response["code"] = 0; response["msg"] = "修改系统配置项成功";
        response["data"] = Json::Value::null;
    }
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200; 
 
}

void api_sys_config::on_http_detail_sys_config(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value response; Json::Value data;
    Json::Value rqRoute = http->get_http_request_route();
    int config_id = atoi(rqRoute["config_id"].asString().c_str()); 
    Json::Value detail = db->query_sys_config_by_config_id(config_id);
    if(detail.size() == 0) {
        response["code"] = 5000502; response["msg"] = "指定的配置项目不存在";
        data["config_id"] = config_id;
        response["data"] = data;
    }
    else{
        response["code"] = 0; response["msg"] = "查询系统配置项详情成功";
        response["data"] = detail[0];
    }
    
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200; 
}
