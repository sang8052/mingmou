/*
 * @Author: SudemQaQ
 * @Date: 2024-01-17 16:23:56
 * @email: mail@szhcloud.cn
 * @Blog: https://blog.szhcloud.cn
 * @github: https://github.com/sang8052
 * @LastEditors: SudemQaQ
 * @LastEditTime: 2024-01-17 18:50:06
 * @Description: 
 */
#pragma once

#include "../extend/arc_soft.h"
#include "common.h"

using namespace cv;

class api_face{
    public:
        // 识别指定图片中的人脸信息
        static void on_http_face_detail(void* handle);
        // 提取指定图片中的人脸特征信息
        static void on_http_face_feature(void* handle);
        // 检测指定图片中人脸框
        static void on_http_face_position(void* handle);
        // 对指定图片进行活体检测(仅支持一张人脸)
        static void on_http_face_liveness(void* handle);
        // 对指定的图片进行人脸比对
        static void on_http_face_compare(void* handle);

        // 提取图片中人脸特征信息并加入到数据库
        static void on_http_db_face_feature_add(void* handle);
        // 提取图片中的人脸特征信息并与数据库比对
        static void on_http_db_face_find(void* handle);
        

        // 新建人脸人员信息 
        static void on_http_db_person_add(void* handle);
        // 删除人脸人员信息
        static void on_http_db_person_delete(void* handle);
        // 修改人脸人员信息
        static void on_http_db_person_update(void* handle);
        // 分页查询人脸人员信息
        static void on_http_db_person_search(void* handle);
        // 查询指定人员的信息（包含人脸特征数据）
        static void on_http_db_person_detail(void* handle);
        // 删除人脸特征 
        static void on_http_db_person_feature_detele(void* handle);


};