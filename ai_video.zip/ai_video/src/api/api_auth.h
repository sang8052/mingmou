#pragma once

#include "common.h"

class api_auth{
    public:
        static void on_http_auth_login(void* handle);
        static void on_http_auth_refresh_token(void* handle);
        static void on_http_auth_ping(void* handle);
};