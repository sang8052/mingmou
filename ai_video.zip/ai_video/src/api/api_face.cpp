#include "api_face.h"

void api_face::on_http_face_position(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value route = http->get_http_request_route();
    string filetoken =  route["token"].asString();
    
    Json::Value data;  Json::Value response;
    Json::Value file;
    if(!http->find_request_file_token(filetoken,file)) return;
        
    arc_soft *asoft = new arc_soft(http->_sp->_tools,http->_sp->thread_id,http->_sp->child_id);
    data["faces"] = asoft->get_face_postion(file["filepath"].asString(),true);
    string file_name = "face_position_"+ http->_sp->_tools->format_current_time_ex() + ".jpg";
    int file_id = db->create_file_record(file_name,asoft->result_file_path, ".jpg",http->request_session["uid"].asInt(),24 * 3600 * 30,false);
    data["file_token"] = db->create_file_token(file_id,http->get_client_ip(),http->get_user_agent(),600);
    response["code"] = 200; response["msg"] = "提取人脸坐标成功";
    response["data"] = data;
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200;   
    delete asoft;
      
}



void api_face::on_http_face_detail(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value route = http->get_http_request_route();
    string filetoken =  route["token"].asString();
    
    Json::Value data;  Json::Value response;
    Json::Value file;
    if(!http->find_request_file_token(filetoken,file)) return;
    arc_soft *asoft = new arc_soft(http->_sp->_tools,http->_sp->thread_id,http->_sp->child_id);
    data = asoft->get_face_detail(file["filepath"].asString());

    response["code"] = 200; response["msg"] = "提取人脸详情成功";
    response["data"] = data;
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200;   
    delete asoft;
    return ;
}

void api_face::on_http_face_feature(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value route = http->get_http_request_route();
    string filetoken =  route["file_token"].asString();

    Json::Value data;  Json::Value response;
    Json::Value file;
    if(!http->find_request_file_token(filetoken,file)) return;
    arc_soft *asoft = new arc_soft(http->_sp->_tools,http->_sp->thread_id,http->_sp->child_id);

    Json::Value faces = asoft->get_face_detail(file["filepath"].asString());
    asoft->get_face_feature(faces);
    
    response["code"] = 200; response["msg"] = "提取人脸特征成功";
    response["data"] = faces;
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200;   
    delete asoft;
    return ;


}


void api_face::on_http_db_face_feature_add(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value rqBody = http->get_http_request_body();
    Json::Value data;Json::Value response;

    int person_id = -1;
    if(rqBody["person_id"].isInt()) person_id = rqBody["person_id"].asInt();
    // 从数据库里面查询关于这个人 信息
    Json::Value person = db->query_person_by_person_id(person_id);
    if(person.size() ==0){
        response["code"] = 5000603; response["msg"] = "人员不存在!请检查person_id";
        response["data"] = rqBody;
    }
    // 找到这个人 获取人员的特征值信息
    else{
        Json::Value file;
        string filetoken =  rqBody["file_token"].asString();
        if(!http->find_request_file_token(filetoken,file)) return;
        arc_soft *asoft = new arc_soft(http->_sp->_tools,http->_sp->thread_id,http->_sp->child_id);
        Json::Value faces = asoft->get_face_detail(file["filepath"].asString());
        if(faces.size() > 1){
            response["code"] = 5000602; response["msg"] = "人脸数量不唯一!";
            response["data"] = Json::objectValue;
            response["data"]["file_token"] = filetoken;
            response["data"]["faces"] = faces;
        }
        else{
            asoft->get_face_feature(faces);
            string new_path = "./data/result/face_feature/" + http->_sp->_tools->get_uuid() + ".jpg";
            http->_sp->_tools->move_file(file["filepath"].asString(),new_path);
            // 永久保存这张图片
            db->update_file_expire(file["id"].asInt(),new_path,-1);
            db->update_file_token(filetoken,new_path,-1);
            // 把人脸特征值入库到数据库
            int face_feature_id = db->create_face_feature(person_id,file["id"].asInt(),faces[0]["orient"].asInt(),faces[0]["position"],faces[0]["feature"].asString(),faces[0]["feature_size"].asInt());
            data["person_id"] = person_id; data["feature_id"] = face_feature_id;
            data["feature"] = faces[0]["feature"];
            response["code"] = 200; response["msg"] = "新增人脸特征成功";
            response["data"] = data;
        }
        
    }
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200;

}

void api_face::on_http_db_face_find(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value route = http->get_http_request_route();
    Json::Value query = http->get_http_request_query();
    Json::Value data;Json::Value response;
    Json::Value file;
    float confidence = 0.6;
    if(query["confidence"].isString()){
        string _confidence = query["confidence"].asString();
        try{
            float tmp = atof(_confidence.c_str());
            if(tmp >= 0  && tmp <= 1 ) confidence = tmp;
        }
        catch(...){
            response["code"] = 5000001; response["msg"] = "refresh_token 参数必须为阈值在[0,1]之间的浮点数";
            response["data"] = query;
            http->response_body = http->_sp->_tools->json_encode(response);
            http->response_header->http_code = 200;
            return ;
        }
    }
    
    string filetoken =  route["token"].asString();
    if(!http->find_request_file_token(filetoken,file)) return;
    arc_soft *asoft = new arc_soft(http->_sp->_tools,http->_sp->thread_id,http->_sp->child_id);
    Json::Value faces = asoft->get_face_detail(file["filepath"].asString());
    asoft->get_face_feature(faces);
    // 从数据库中查询所有的人脸信息
    Json::Value features = db->query_person_all_feature();
    asoft->register_face_feature(features);
    http->console_log("[INFO]人脸数据库注册成功,共注册" + to_string(features.size()) + "张人脸");
    for(int i=0;i < faces.size();i++){
        search_result result =  asoft->search_face_feature(faces[i]["feature"].asString(),faces[i]["feature_size"].asInt());
        faces[i]["result"] = Json::objectValue;
        faces[i]["result"]["confidence"] = result.confidence; 
        faces[i]["result"]["feature_id"] = result.feature_id;
        faces[i]["result"]["person"] = db->query_person_by_feature_id(result.feature_id);
    }
    response["code"] = 200; response["msg"] = "人脸搜索成功";
    response["data"] = faces;
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200;
}

void api_face::on_http_db_person_add(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value rqBody = http->get_http_request_body();
    Json::Value data;Json::Value response;

    string name = ""; string idcard = ""; string ecard = ""; string telphone = "";
    string email = ""; string org_part = ""; string other_json = "{}"; string extend = "";
   
    if(rqBody["name"].isString()) name = rqBody["name"].asString();
    if(name == "" ){
        response["code"] = 5000201; response["msg"] = "字段 name 的值不能为空";
        response["data"] = rqBody;
    }
    if(rqBody["idcard"].isString()) idcard = rqBody["idcard"].asString();
    if(rqBody["ecard"].isString()) ecard = rqBody["ecard"].asString();
    if(rqBody["telphone"].isString()) telphone = rqBody["telphone"].asString();
    if(rqBody["email"].isString()) email = rqBody["email"].asString();
    if(rqBody["org_part"].isString()) org_part = rqBody["org_part"].asString();
    if(rqBody["other_json"].isObject()) other_json = http->_sp->_tools->json_encode(rqBody["other_json"]);
    if(rqBody["extend"].isString()) extend = rqBody["extend"].asString();
   
    int person_id = db->create_face_person(http->request_session["puid"].asInt(),name,idcard,ecard,telphone,email,org_part,other_json,extend);
    data["person_id"] = person_id;
    data["puid"] = http->request_session["uid"].asInt();
    data["name"] = name;
    response["code"] = 200; response["msg"] = "新增人脸识别人员信息成功";
    response["data"] = data;
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200;   
}

void api_face::on_http_db_person_delete(void *handle)
{ 
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value route = http->get_http_request_route();
    Json::Value response;

    int person_id =  atoi(route["person_id"].asString().c_str());
    Json::Value person = db->query_person_by_person_id(person_id);
    if(person.size() ==0){
        response["code"] = 5000603; response["msg"] = "人员不存在!请检查person_id";
        response["data"] = Json::objectValue; response["data"]["person_id"] = person_id;
    }
    else{
        person = person[0];
        if(person["puid"]!= http->request_session["puid"]){
            response["code"] = 5000004; response["msg"] = "你无权限访问";
            response["data"] = Json::objectValue; 
            response["data"]["person_id"] = person_id;
            http->response_body = http->_sp->_tools->json_encode(response);
            http->response_header->http_code = 200; 
            return ;
        }
        // 删除人员 
        db->_conn->quick_mysql_exec("DELETE FROM `face_person` WHERE id = " + to_string(person_id));
        Json::Value files = db->_conn->quick_mysql_query("SELECT `sys_file`.* FROM `sys_file` JOIN `face_person_feature` ON `face_person_feature`.file_id = `sys_file`.id   WHERE `face_person_feature`.person_id = " + to_string(person_id));
        // 删除文件
        for(int i=0;i<files.size();i++){
             db->_conn->quick_mysql_exec("UPDATE `sys_file` set `delete_expire` = " + to_string(http->_sp->_tools->get_timestamp()) 
                + " WHERE id = " + to_string(files[i]["id"].asInt()));
        }
        // 删除特征
        db->_conn->quick_mysql_exec("DELETE FROM `face_person_feature` WHERE person_id = " + to_string(person_id));
        response["code"] = 200; response["msg"] = "删除人员信息成功";
        response["data"] = Json::nullValue;
        
    }
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200; 
}

void api_face::on_http_db_person_update(void *handle)
{
     http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value route = http->get_http_request_route();
    Json::Value rqBody = http->get_http_request_body();

    Json::Value data;Json::Value response;

    int person_id =  atoi(route["person_id"].asString().c_str());
    Json::Value person = db->query_person_by_person_id(person_id);
    if(person.size() ==0){
        response["code"] = 5000603; response["msg"] = "人员不存在!请检查person_id";
        response["data"] = Json::objectValue; response["data"]["person_id"] = person_id;
    }
    else{
        person = person[0];
        if(person["puid"]!= http->request_session["puid"]){
            response["code"] = 5000004; response["msg"] = "你无权限访问";
            response["data"] = Json::objectValue; 
            response["data"]["person_id"] = person_id;
            http->response_body = http->_sp->_tools->json_encode(response);
            http->response_header->http_code = 200; 
            return ;
        }
        Json::Value update;
        vector<string> fields = {"name","idcard","ecard","telphone","email","org_part","extend"};
        for(int i=0;i<fields.size();i++){
            string field = fields[i];
            if(rqBody[field].isString()) update[field] = rqBody[field].asString();
        }
        if(rqBody["other_json"].isObject()) update["other_json"] = http->_sp->_tools->json_encode(rqBody["other_json"]);
        db->sobj->sql_where("id","=",db->sobj->sql_value(person_id));
        db->_conn->quick_mysql_exec(db->sobj->sql_update("face_person",update));
        response["code"] = 200; response["msg"] = "修改人员信息成功";
        response["data"] = Json::nullValue;
        http->response_body = http->_sp->_tools->json_encode(response);
        http->response_header->http_code = 200; 
    }
   
}


void api_face::on_http_db_person_detail(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value route = http->get_http_request_route();
    Json::Value response;

    int person_id =  atoi(route["person_id"].asString().c_str());
    Json::Value person = db->query_person_by_person_id(person_id);
    if(person.size() ==0){
        response["code"] = 5000603; response["msg"] = "人员不存在!请检查person_id";
        response["data"] = Json::objectValue; response["data"]["person_id"] = person_id;
    }
    else{
        person = person[0];
        if(person["puid"] != http->request_session["puid"].asInt() && http->request_session["level"] != 2){
            response["code"] = 5000004; response["msg"] = "你无权限访问";
            response["data"] = Json::objectValue; response["data"]["person_id"] = person_id;
        }
        // 查询关联的 人脸特征
        Json::Value features = db->query_person_feature_by_person_id(person_id);
        for(int i=0;i<features.size();i++){
            features[i]["feature_id"] = features[i]["id"];
            features[i]["position"] = http->_sp->_tools->json_decode(features[i]["position"].asString());
            features[i].removeMember("feature_hex");
            features[i].removeMember("feature_size");
            features[i].removeMember("id");
            // 生成文件的访问授权token 有效期5分钟
            string file_token = db->create_file_token(features[i]["file_id"].asInt(),http->get_client_ip(),http->get_user_agent(),5 * 60);
            features[i]["file_token"] = file_token;
        }
        person["features"] = features;
        response["code"] = 200; response["msg"] = "查询人脸识别人员详情成功";
        response["data"] = person;
    }
   
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200;   

}

void api_face::on_http_db_person_feature_detele(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value route = http->get_http_request_route();
    Json::Value response;

    int feature_id = atoi(route["feature_id"].asString().c_str());

    // 查询feature 信息 
    Json::Value feature = db->query_person_feature_by_feature_id(feature_id);
    if(feature.size() == 0){
        response["code"] = 5000604; response["msg"] = "人脸特征不存在!请检查 feature_id";
        response["data"] = Json::objectValue; response["data"]["feature_id"] = feature_id;
        http->response_body = http->_sp->_tools->json_encode(response);
        http->response_header->http_code = 200; 
        return ;
    }
    feature = feature[0];
    // 查询人员信息
    Json::Value person = db->query_person_by_person_id(feature["person_id"].asInt());
    if(person.size() ==0){
        response["code"] = 5000603; response["msg"] = "人员不存在!请检查person_id";
        response["data"] = Json::objectValue; 
        response["data"]["person_id"] = feature["person_id"].asInt();
        response["data"]["feature_id"] = feature_id;
        http->response_body = http->_sp->_tools->json_encode(response);
        http->response_header->http_code = 200; 
        return ;
    }
    // 判断是否有操作权限
    person = person[0];
    if(person["puid"]!= http->request_session["puid"]){
        response["code"] = 5000004; response["msg"] = "你无权限访问";
        response["data"] = Json::objectValue; 
        response["data"]["person_id"] = feature["person_id"].asInt();
        response["data"]["feature_id"] = feature_id;
        http->response_body = http->_sp->_tools->json_encode(response);
        http->response_header->http_code = 200; 
        return ;
    }
    // 执行删除 
    db->_conn->quick_mysql_exec("DELETE FROM `face_person_feature` WHERE id = " + to_string(feature_id));

    response["code"] = 200; response["msg"] = "删除特征信息成功";
    response["data"] = Json::nullValue;
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200; 

}
