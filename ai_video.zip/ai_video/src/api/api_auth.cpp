#include "api_auth.h"


void api_auth::on_http_auth_login(void *handle)
{    
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value rqBody = http->get_http_request_body();
    string username = "";
    string password = "";
    if(rqBody["username"].isString()) username = rqBody["username"].asString();
    if(rqBody["password"].isString()) password = rqBody["password"].asString();
    Json::Value response;
    Json::Value data;
    bool status = false;
    if(username == "" || password == ""){
        response["code"] = 5000201; response["msg"] = "用户名或密码不能为空";
        data["username"] = username ; data["password"] = password;
        response["data"] = data;
      
    }
    else{
        Json::Value result = db->query_user_account(username);
        if(result.size() == 0) {
            response["code"] = 5000201; response["msg"] = "用户名不存在!";
            data["username"] = username ; data["password"] = password;
            response["data"] = data;
        }
        else{
            Json::Value user = result[0];
            string _password = http->_sp->_tools->str_hash_sha256( password + ":" +  user["salt"].asString()) ;
            if(_password != user["password"].asString()) {
                response["code"] = 5000201; response["msg"] = "密码不正确,请输入正确的密码";
                data["username"] = username; 
                response["data"] = data;
            }
            else if(user["status"] == 0){
                response["code"] = 5000202; response["msg"] = "当前账户已经被禁用,请与管理员联系";
                data["ban_msg"] = user["ban_msg"].asString();
                data["uid"] = user["uid"].asString(); data["username"] = user["username"].asString(); data["nickname"] = user["nickname"].asString();
            }
            else{
                oauth_user *ouser  = db->oauth_create_token(http->get_client_ip(),http->get_http_header()->user_agent,user);
                data["uid"] = user["uid"].asInt(); data["nickname"] = user["nickname"].asString(); data["level"] = user["level"].asInt();
                data["access_token"] = ouser->access_token;
                data["refresh_token"] = ouser->refresh_token;
                response["code"] = 0; response["msg"] = "登录成功";
                response["data"] = data;
               
            }
        }

    }
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200;  

   
}

void api_auth::on_http_auth_refresh_token(void *handle)
{
    http_handle *http = (http_handle*)handle;
    string http_access_token;
    http_header *request =  http->get_http_header();
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value rqBody = http->get_http_request_body();
    string refresh_token = "";
    Json::Value response; Json::Value result;
    Json::Value data; 
    bool status = false;
    if(rqBody["refresh_token"].isString()) refresh_token = rqBody["refresh_token"].asString();
    if(refresh_token==""){
            response["code"] = 5000001; response["msg"] = "refresh_token 参数不能为空!";
            data["refresh_token"] = refresh_token; 
            response["data"] = data;
    }
    else{
        vector<string> tmp = http->_sp->_tools->explode(refresh_token,":");
        string _refresh_token ;
        if(tmp.size() == 4)  _refresh_token = tmp[3]; 
        result = db->query_oauthToken_refresh_token(_refresh_token);
        if(result.size() == 0){
             response["code"] = 5000203; response["msg"] = "refresh token 不存在!";
             data["refresh_token"] = refresh_token; data["access_token"] = http->request_access_token;
             response["data"] = data;
        }
        else{
            result = result[0];
            if(result["status"].asInt() != 0 ){
                response["code"] = 5000203; response["msg"] = "refresh token 已经被使用!";
                data["refresh_token"] = refresh_token; data["access_token"] = http->request_access_token;
                response["data"] = data;
            }            
            if(request->authorization!="") http_access_token = request->authorization;
            else if(request->custom_header["x-access-token"].isString()) http_access_token = request->custom_header["x-access-token"].asString();
            string tmp_access_token; tmp = http->_sp->_tools->explode(http_access_token,":");
            if(tmp.size() == 4) tmp_access_token = tmp[3];
            if(result["access_token"].asString() != tmp_access_token){
                response["code"] = 5000204; response["msg"] = "该 access_token 绑定的 refresh_token 不正确";
                data["refresh_token"] = http_access_token; data["access_token"] = http_access_token;
                response["data"] = data;
            }
            else{
                Json::Value user = db->query_user_account(result["uid"].asInt())[0];
                if(user["status"] != 1) {
                     response["code"] = 5000202; response["msg"] = "当前账户已经被禁用,请与管理员联系";
                     data["uid"] = user["uid"].asString(); data["username"] = user["username"].asString(); data["nickname"] = user["nickname"].asString();
                }
                else{
                    // 变更 refresh_token 的状态
                    db->update_oauthToken_refresh_token(_refresh_token,1);
                    // 删除旧的access_token 
                    http->_sp->_conn->redis->del(http->request_session_key);
                    // 生成新的 access_token refresh_token 
                     oauth_user *ouser  = db->oauth_create_token(http->get_client_ip(),http->get_user_agent(),user);
                    data["uid"] = user["uid"].asInt(); data["nickname"] = user["nickname"].asString(); data["level"] = user["level"].asInt();
                    data["access_token"] = ouser->access_token;
                    data["refresh_token"] = ouser->refresh_token;
                    response["code"] = 0; response["msg"] = "刷新票据成功!";
                    response["data"] = data;
                }
            }
        }
    }
    if(!status){
         http->response_body = http->_sp->_tools->json_encode(response);
         http->response_header->http_code = 403;
         http->response_header->http_msg = "Forbbiden";
    }
}

void api_auth::on_http_auth_ping(void *handle)
{
    http_handle *http = (http_handle*)handle;
    Json::Value response; 
    Json::Value data; 
    response["code"] = 200; response["msg"] = "";
    data["access_expire"] = http->request_session["access_expire"].asInt();
    data["access_expire_abs"] = abs(http->_sp->_tools->get_timestamp() - data["access_expire"].asInt());
    response["data"] = data;
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200;
}

