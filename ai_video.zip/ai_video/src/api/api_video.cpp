#include "api_video.h"

// 视频流
void api_video::on_http_stream_captcha(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value rqBody = http->get_http_request_body();
    Json::Value response; Json::Value data;
    string stream_url = "";
    if(rqBody["stream_url"].isString()) stream_url = rqBody["stream_url"].asString();
    else{
        response["code"] = 5000001; response["msg"] = "stream_url 参数不能为空!";
        data["stream_url"] = stream_url; 
        response["data"] = data;
        http->response_body = http->_sp->_tools->json_encode(response);
        return ;
    }
    http->console_log("[LOG]输入的原始视频流地址:" + stream_url);

    // 调用 ffmpeg  拉取视频流 


    AVFormatContext* pFormatCtx = NULL;
	AVDictionary* options = NULL;
	AVPacket* av_packet = (AVPacket*)av_malloc(sizeof(AVPacket));
	// 多媒体帧 
	AVFrame* pAvFrame = av_frame_alloc();
	// 解码器列表类
	AVCodecContext* pCodecCtx = avcodec_alloc_context3(NULL);
	// 解码器 指针
	const AVCodec* pCodec;

    response["code"] = 200; response["msg"] = "";
    av_log_set_level(AV_LOG_ERROR);
	av_dict_set(&options, "buffer_size", "4096000", 0); 
	av_dict_set(&options, "rtsp_transport", "tcp", 0);  
	av_dict_set(&options, "stimeout", "3000000", 0);    
	av_dict_set(&options, "max_delay", "500000", 0);    
	pFormatCtx = avformat_alloc_context();

    // 打开视频流 
    if (avformat_open_input(&pFormatCtx, stream_url.c_str(), NULL, &options) != 0)
	{
		http->console_log("[ERROR]打开输入的媒体流失败,请检查地址[" + stream_url + "]是否有误");
        data["stream_url"] = stream_url;
        response["code"] = 5000101; response["msg"] = "拉流失败,请检查媒体流是否正确或网络连接状态!"; response["data"] = data;
        http->response_body = http->_sp->_tools->json_encode(response);
        return ;
	}
    
    http->console_log("[LOG]媒体流[" + stream_url + "]打开成功");
    if (avformat_find_stream_info(pFormatCtx, NULL) < 0)  {
        avformat_close_input(&pFormatCtx);
        http->console_log("[WANRING]在媒体流中没有找到有效的视频/音频流");
        data["stream_url"] = stream_url;
        response["code"] = 5000102; response["msg"] = "拉流成功,但没有识别到视频/音频流"; response["data"] = data;
        http->response_body = http->_sp->_tools->json_encode(response);
        return ;
    }
	http->console_log("[INFO]输入流信息如下");
	AVDictionaryEntry* tag = NULL;
	while ((tag = av_dict_get(pFormatCtx->metadata, "", tag, AV_DICT_IGNORE_SUFFIX)))
	{
		string key = tag->key;
		string value = tag->value;
		data[key] = value;
	}
    data["audios"].resize(0);
    data["videos"].resize(0);

    int videoindex = -1;int audioindex = -1; 
	unsigned i = 0;

	for (i = 0; i < pFormatCtx->nb_streams; i++)
	{
		if (pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_AUDIO && audioindex == -1) {
			audioindex = i;
			http->console_log("[INFO]在轨道[" + to_string(i) + "]中发现音频流");
			http->console_log("[LOG]编码器名称:" + (string)avcodec_get_name(pFormatCtx->streams[i]->codecpar->codec_id));
            http->console_log("[LOG]采用率:" + to_string(pFormatCtx->streams[i]->codecpar->sample_rate));
            http->console_log("[LOG]通道数:" + to_string(pFormatCtx->streams[i]->codecpar->ch_layout.nb_channels));
            Json::Value audio;
            audio["stream_id"] = i;
            audio["ffmpeg_code_id"] = (int)pFormatCtx->streams[i]->codecpar->codec_id;
            audio["sample_rate"] = (int)pFormatCtx->streams[i]->codecpar->sample_rate;
            audio["channels"] = (int)pFormatCtx->streams[i]->codecpar->ch_layout.nb_channels;
            audio["code_name"] = (string)avcodec_get_name(pFormatCtx->streams[i]->codecpar->codec_id);
            data["audios"].append(audio);
		}

		if (pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO && videoindex == -1)
		{
			videoindex = i;
			http->console_log("[INFO]在轨道[" + to_string(i) + "]中发现视频流");
			http->console_log("[LOG]编码器名称:" + (string)avcodec_get_name(pFormatCtx->streams[i]->codecpar->codec_id));
			http->console_log("[LOG]视频宽度:" + to_string(pFormatCtx->streams[i]->codecpar->width));
			http->console_log("[LOG]视频高度:" + to_string(pFormatCtx->streams[i]->codecpar->height));
			http->console_log("[LOG]视频FPS:"  + to_string(http->_sp->_tools->RationaltoDouble(pFormatCtx->streams[i]->avg_frame_rate)));
            
            Json::Value video;
            video["stream_id"] = i;
            video["ffmpeg_code_id"] = (int)pFormatCtx->streams[i]->codecpar->codec_id;
            video["code_name"] = (string)avcodec_get_name(pFormatCtx->streams[i]->codecpar->codec_id);
            video["width"] = (int)pFormatCtx->streams[i]->codecpar->width;
            video["height"] = (int)pFormatCtx->streams[i]->codecpar->height;
            video["fps"] = http->_sp->_tools->RationaltoDouble(pFormatCtx->streams[i]->avg_frame_rate);
            data["videos"].append(video);
		}
	}
    if (audioindex == -1)  http->console_log("[WARNING]在指定的流中没有找到音频流数据");
	if (videoindex == -1)  http->console_log("[WARNING]在指定的流中没有找到视频流数据");
    else{
       
        avcodec_parameters_to_context(pCodecCtx, pFormatCtx->streams[videoindex]->codecpar);
	    pCodec = avcodec_find_decoder(pCodecCtx->codec_id);
        int ret;  int got_picture;

        if (pCodec == NULL) {
            response["code"] = 5000102; response["msg"] = "拉流失败,没有找到对应视频流[" + to_string(videoindex) + ",code_id:" + to_string(pCodecCtx->codec_id) + "]的编码器"; response["data"] = data;
            http->response_body = http->_sp->_tools->json_encode(response);
            return ;
        }
        if (avcodec_open2(pCodecCtx, pCodec, NULL) < 0) {
		    http->console_log("[ERROR]打开编码器code_id:" + to_string(pCodecCtx->codec_id) + "]失败");
            response["code"] = 5000102; response["msg"] = "拉流失败,打开视频流[" + to_string(videoindex) + ",code_id:" + to_string(pCodecCtx->codec_id) + "]的编码器出现错误"; 
            response["data"] = data;
            http->response_body = http->_sp->_tools->json_encode(response);
            return ;
	    }
        bool save_img = false;
        while (!save_img)
	    {
            if (av_read_frame(pFormatCtx, av_packet) >= 0)
		    {
			    if (av_packet->stream_index == videoindex)
			    {
						
				    if (ret = avcodec_send_packet(pCodecCtx, av_packet) < 0 || (got_picture = avcodec_receive_frame(pCodecCtx, pAvFrame)) < 0)
					    http->console_log("[WARNING]解码错误,code:" + to_string(ret) + ",error:" + strerror(errno));
				    else {
					    cv::Mat cv_frame = http->_sp->_tools->avFrame2Mat(pAvFrame);
                        http->console_log("[LOG]解码成功");
                        string frame_name = http->_sp->_tools->get_uuid() + ".jpg";
                        string frame_path= "./data/captcha/" + frame_name;
					    imwrite(frame_path, cv_frame);
                        cv_frame.release();
                        // 生成文件的 file_id 
                        int file_id = db->create_file_record(frame_name,frame_path,".jpg",http->request_session["uid"].asInt(),60 * 15 , true);
                        // 生成文件的 访问token 
                        string file_token = db->create_file_token(file_id,http->get_client_ip(),http->get_user_agent());
                        Json::Value video_checkup = data;
                        video_checkup["stream_url"] = stream_url;
                        data["captcha_file_token"] = file_token; 
                        data["video_checkup_token"] = http->_sp->_tools->get_uuid();
                        string ckey = http->_sp->_config->get_string_value("REDIS_KEY","KEY_VIDEO_CHECK_UP","ai_video:video:check_up:") + data["video_checkup_token"].asString();
                        http->_sp->_conn->redis->set(ckey,http->_sp->_tools->json_encode(video_checkup));
                        http->_sp->_conn->redis->expire(ckey,120);
                        save_img = true;		
				    }
			    }
		    }
		    if (av_packet != NULL)  av_packet_unref(av_packet);		
	    }
    }
    avformat_close_input(&pFormatCtx);
    response["data"] = data;
    http->response_body = http->_sp->_tools->json_encode(response);
    return ;
}

void api_video::on_http_stream_add(void *handle)
{
    http_handle *http = (http_handle*)handle;
    Json::Value response; Json::Value data;
    int user_level = http->request_session["level"].asInt();
    if(user_level == 0){
        response["code"] = 5000004; response["msg"] = "你无权限请求该接口!"; response["data"] = Json::Value::null;
        http->response_body = http->_sp->_tools->json_encode(response);
        return ;
    }
    else{
        sys_thread *th_pools = (sys_thread*)http->_sp->th_pools;
        sys_thread *current_th = th_pools;
        // 遍历 直到移动到 链表的最后一个节点
        while (current_th->next !=nullptr) current_th = current_th->next;
        Json::Value rqBody = http->get_http_request_body();
        string video_token = "";
        if(rqBody["video_token"].isString()) video_token = rqBody["video_token"].asString();
        if(video_token == ""){
            response["code"] = 5000001; response["msg"] = "video_token 参数不能为空!";
            data["video_token"] = video_token; 
            response["data"] = data;
            http->response_body = http->_sp->_tools->json_encode(response);
            return ;
        }
        else{
            string ckey =  http->_sp->_config->get_string_value("REDIS_KEY","KEY_VIDEO_CHECK_UP","ai_video:video:check_up:") + video_token;
            if(!http->_sp->_conn->redis->exists(ckey)){
                response["code"] = 5000104; response["msg"] = "token 不存在或者已经被删除";
                data["video_token"] = video_token; 
                response["data"] = data;
                http->response_body = http->_sp->_tools->json_encode(response);
                return ;
            }
            else{
                Json::Value video = http->_sp->_tools->json_decode(*http->_sp->_conn->redis->get(ckey));
                ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
                string name; string extend;
                if(rqBody["name"].isString())    name = rqBody["name"].asString();
                if(rqBody["extend"].isString())  extend = rqBody["extend"].asString();
                int video_id =  db->create_video_stream(video,http->request_session["puid"].asInt(),name,extend);
                if(video_id < 0){
                     response["code"] = 5000105; response["msg"] = "视频流已经存在";
                     data["video_token"] = video_token; 
                     data["stream_url"] = video["stream_url"];
                     data["puid"] = http->request_session["puid"].asInt();
                     response["data"] = data;
                     http->response_body = http->_sp->_tools->json_encode(response);
                     return ;
                }
                else{
                     // 删除token 
                     http->_sp->_conn->redis->del(ckey);
                     response["code"] = 0; response["msg"] = "操作成功";
                     data["video_token"] = video_token; 
                     data["stream_url"] = video["stream_url"];
                     data["puid"] = http->request_session["puid"].asInt();
                     data["video_id"] = video_id;
                     response["data"] = data;
                     http->response_body = http->_sp->_tools->json_encode(response);
                     return ;
                }

            }
        }
    }
}
