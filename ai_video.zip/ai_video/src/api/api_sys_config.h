#pragma once

#include "common.h"

class api_sys_config{
    public:
        static void on_http_query_sys_config(void* handle);
        static void on_http_create_sys_config(void* handle);
        static void on_http_delete_sys_config(void* handle);
        static void on_http_update_sys_config(void* handle);
        static void on_http_detail_sys_config(void* handle);
};
