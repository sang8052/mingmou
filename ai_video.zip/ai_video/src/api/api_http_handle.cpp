#include "api_http_handle.h"

bool api_http_handle::on_hook_before_handle(void *handle)
{
    http_handle *http = (http_handle*)handle;
    http_header *request =  http->get_http_header();
 
    // content_type 判断 
    bool check_content_type = true;
    if(request->request_method != "GET" && request->request_method != "OPTIONS"){
        if(request->content_type.size() == 0) check_content_type = false;
        else{
            if(
                !http->_sp->_tools->str_include(request->content_type,"application/json") &&
                !http->_sp->_tools->str_include(request->content_type,"multipart/form-data") &&
                !http->_sp->_tools->str_include(request->content_type,"application/x-www-form-urlencoded")
            )
            check_content_type = false;
        }
    }
    if(!check_content_type){
        http->console_log("[DEBUG]前置路由HOOK[Content-Type 验证失败...]");
        Json::Value response; Json::Value data;
        data["content-type"] = request->content_type;
        data["request-method"] = request->request_method;
        response["code"] = 5000002; response["msg"] = "请传入正确的content-type 请求头!"; response["data"] = data;
        http->response_body = http->_sp->_tools->json_encode(response);
        http->response_header->http_code = 500;
        http->response_header->http_msg = "Server Error";
        return false;
    }

    // user_agent 判断 
    if(request->user_agent.size() == 0){
        http->console_log("[DEBUG]前置路由HOOK[User-Agent 验证失败...]");
        Json::Value response; Json::Value data;
        data["content-type"] = request->content_type;
        data["request-method"] = request->request_method;
        response["code"] = 5000003; response["msg"] = "请传入正确的user_agent 请求头!"; response["data"] = data;
        http->response_body = http->_sp->_tools->json_encode(response);
        http->response_header->http_code = 500;
        http->response_header->http_msg = "Server Error";
        return false;
    }




    string _access_token = "";  string access_token = "";
    string uid = ""; bool is_super_token = false;
    // 查找 authoriaztion 字段 或 x-access-token 字段 
    if(request->authorization!="") _access_token = request->authorization;
    else if(request->custom_header["x-access-token"].isString()) _access_token = request->custom_header["x-access-token"].asString();
    // 分割获取 真实的 access_token 
    if(_access_token !="") {
        vector<string> tmp =  http->_sp->_tools->explode(_access_token,":");
        if(tmp.size() == 4) { access_token = tmp[3];  uid = tmp[2];}
    } 

    if(access_token != ""){
        if(access_token == HTTP_SESSION_SUPER_TOKEN && uid == "10001"){
            http->console_log("[WARNING]******检测到使用超级[access_token]访问系统,请注意系统运行安全!******");
            is_super_token = true;
        }
        // 查询redis 是否存在这个键 
        string ckey = http->_sp->_config->get_string_value("REDIS_KEY","KEY_USER_SESSION","ai_video:session:user:") + access_token;
        if(http->_sp->_conn->redis->exists(ckey)){
            string json_session  = *http->_sp->_conn->redis->get(ckey);
            http->request_session = http->_sp->_tools->json_decode(json_session);
            if(http->request_session["access_http_user_agent"] != request->user_agent && !is_super_token) {
                http->console_log("[DEBUG]前置路由HOOK[鉴权失败,UA异常...]");
                Json::Value response;
                response["code"] = 403; response["msg"] = "User-Agent发生变化,请重新登录到会话!";response["data"] = Json::nullValue;
                http->response_body = http->_sp->_tools->json_encode(response);
                http->response_header->http_code = 403;
                http->response_header->http_msg = "Forbbiden";
                return false; 
            }
            if(http->request_session["uid"].asString() != uid){
                http->console_log("[DEBUG]前置路由HOOK[鉴权失败,uid 错误...]");
                Json::Value response; Json::Value data;
                response["code"] = 403; response["msg"] = "access_token 签名效验失败,请检查access_token";
                data["access_token"] = access_token; data["token"] = _access_token; data["uid"] = uid;
                response["data"] = data;
                http->response_body = http->_sp->_tools->json_encode(response);
                http->response_header->http_code = 403;
                http->response_header->http_msg = "Forbbiden";
                return false; 
            }
            // 续费当前 access_token 
            http->request_session["access_expire"] = http->_sp->_tools->get_timestamp() + HTTP_SESSION_EXPIRE;
            http->request_session["current_client_ip"] = http->get_client_ip();
            http->_sp->_conn->redis->set(ckey,http->_sp->_tools->json_encode(http->request_session),false);
            http->_sp->_conn->redis->expire(ckey,HTTP_SESSION_EXPIRE);
            http->request_access_token = access_token;
            http->request_session_key = ckey; 
        }
        else if(is_super_token ){
            http->console_log("[DEBUG]创建超级access_token 对应的session");
            ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
            db->oauth_super_access_token_login(http->get_client_ip(),http->get_user_agent(),db->query_user_account(10001)[0]);
            string json_session  = *http->_sp->_conn->redis->get(ckey);
            http->request_session = http->_sp->_tools->json_decode(json_session);
            http->request_access_token = access_token;
            http->request_session_key = ckey; 
        }
    }

  
    // 路由鉴权判断 
    // 当且仅当请求 /api/auth/login 和 /api/file/download/* 时不需要进行路由效验 
    bool need_login = true; 
    if(request->document_url == "/api/auth/login" || request->document_url == "/api/auth/oauth" || http->_sp->_tools->str_start_include(request->document_url,"/api/file/download/"))  need_login = false;
    if(need_login){
        if(http->request_access_token.size() != 0) http->console_log("[DEBUG]前置路由HOOK鉴权通过,access_token:" + http->request_access_token);
        else {
            http->console_log("[DEBUG]前置路由HOOK[鉴权失败,请重新登录...]");
            Json::Value response;
            response["code"] = 403; response["msg"] = "请重新登录到会话!";response["data"] = Json::nullValue;
            http->response_body = http->_sp->_tools->json_encode(response);
            http->response_header->http_code = 403;
            http->response_header->http_msg = "Forbbiden";
            return false;

        }
    }
    return true;

}

bool api_http_handle::on_hook_after_handle(void *handle)
{
    http_handle *http = (http_handle*)handle;
    
    if(http->request_session_key.size() !=0){
        if(http->_sp->_conn->redis->exists(http->request_session_key)){
            http->_sp->_conn->redis->set(http->request_session_key,http->_sp->_tools->json_encode(http->request_session));
            http->_sp->_conn->redis->expire(http->request_session_key,HTTP_SESSION_EXPIRE);
        }
    }
}
