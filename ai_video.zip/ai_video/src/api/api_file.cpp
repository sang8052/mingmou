#include "api_file.h"

void api_file::on_http_file_download(void *handle)
{
    // 强制类型转换
    http_handle *http = (http_handle*)handle;
     ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value response;Json::Value data;
    // 读取路由的 token 
    string token;
    Json::Value route = http->get_http_request_route();
    Json::Value query = http->get_http_request_query();
    if(route["token"].isString())  token = route["token"].asString();
    // 查找路由的token是否存在 
    string config_key = http->_sp->_config->get_string_value("REDIS_KEY","KEY_FILE_DOWNLOAD","ai_video:file:download:") + token;
    data["token"] = token ; data["client_ip"] = http->get_client_ip(); data["user_agent"] = http->get_user_agent();
    if(!http->_sp->_conn->redis->exists(config_key)){
         response["code"] = 5000303; response["msg"] = "访问文件失败,token 不存在或者已经被删除";
         response["data"] = data;
         http->response_body = http->_sp->_tools->json_encode(response);
         http->response_header->http_code = 403; 
         http->response_header->http_msg = "Forbidden";  
         return ;
    }
    else{
        Json::Value file = http->_sp->_tools->json_decode(*http->_sp->_conn->redis->get(config_key));
        data["file_id"] = http->_sp->_tools->str_base64_encode(to_string(file["id"].asInt())); 

        // 检查 源文件是否已经被删除 
        if(!http->_sp->_tools->exist_file(file["filepath"].asString()))  {
           response["code"] = 5000301; response["msg"] = "访问文件失败,元数据不存在或已被删除";
           response["data"] = data; 
           http->response_body = http->_sp->_tools->json_encode(response);
           http->response_header->http_code = 404; 
           http->response_header->http_msg = "Not Found";  
           return ;
        }

        // 检查 源文件是否已经过期
        if(file["delete_expire"].asInt() < http->_sp->_tools->get_timestamp() && file["delete_expire"].asInt() != -1){
            response["code"] = 5000301; response["msg"] = "访问文件失败,元数据已过期";
            response["data"] = data; 
            http->response_body = http->_sp->_tools->json_encode(response);
            http->response_header->http_code = 404; 
            http->response_header->http_msg = "Not Found";  
            return ;
        }

        if(file["client_ip"].asString() != http->get_client_ip() || file["user_agent"] != http->get_user_agent()){
            response["code"] = 5000302; response["msg"] = "请使用申请token 时的设备访问该文件!";
            response["data"] = data; 
            http->response_body = http->_sp->_tools->json_encode(response);
            http->response_header->http_code = 403; 
            http->response_header->http_msg = "Forbidden";  
            return ;
        }

        // 根据 ext 的文件类型 查询文件的content_type 
        http->response_header->content_type = http->get_content_type_byext(file["ext"].asString());
        http->response_header->custom_header["x-file-id"] = http->_sp->_tools->str_base64_encode(to_string(file["id"].asInt())); 
        http->response_file = true;
        if(query["download"].isString()){
            if(query["download"].asString() == "")   http->response_file_name = file["filename"].asString();
            else http->response_file_name = query["download"].asString();
        }
        http->response_file_path = file["filepath"].asString();
        http->response_file_remove = false;
        // 判断 文件是否需要删除 
        if(file["is_tmp"].asBool() == true) {
            http->response_file_remove = true;
            // 关闭断点续传
            http->response_allow_range_response = false;
            // 删除redis 的键
            http->_sp->_conn->redis->del(config_key);
            // 从数据库里面删除记录
            db->delete_file_byid(file["id"].asInt());
        }
       
    }
}

void api_file::on_http_file_upload(void *handle)
{
    http_handle *http = (http_handle*)handle;
    Json::Value rqBody = http->get_http_request_body();
    Json::Value response; Json::Value data;
    string filename;  string tmp_file_token = http->_sp->_tools->get_uuid();
    string local_filename = "";
    string content_type;  string params="file"; string binary_upload_path;
    bool upload_file = false; int i = 0; 
    string request_content_type = http->get_http_header()->content_type;
    if(http->_sp->_tools->str_include(request_content_type,"multipart/form-data")){ 
         for(;i<rqBody.size();i++){
            if(rqBody[i]["content_disposition"]["name"].asString() == params &&  rqBody[i]["content_type"].asString() != "text"){
                content_type = rqBody[i]["content_type"].asString();
                filename = rqBody[i]["content_disposition"]["filename"].asString();
                binary_upload_path = rqBody[i]["content_file_path"].asString();
                upload_file = true;
            }
            if(rqBody[i]["content_disposition"]["name"].asString() == (string)"filename" &&  rqBody[i]["content_type"].asString() == "text"){
                local_filename = rqBody[i]["content_body"].asString();
            }
        }
        if(!upload_file) response["msg"] = "表单字段file不存在或类型错误!";
    }
    else response["msg"] = "请求的content-type必须为multipart/form-data";
   
    if(upload_file){
        if(local_filename == "") local_filename = filename;
        // 复制临时文件 到 临时目录中
        string tmp_file_path = DIR_TMP_PATH + (string)("upload_") + http->_sp->_tools->get_uuid();
        http->_sp->_tools->copy_file(binary_upload_path,tmp_file_path);

        ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    
        int pos = filename.find_last_of(".");
        string ext = filename.substr(pos,filename.size() - pos);
        data["file_id"] = db->create_file_record(filename,tmp_file_path,ext,http->request_session["uid"].asInt(),10 * 60,false);
        data["file_token"] = db->create_file_token(data["file_id"].asInt(),http->get_client_ip(),http->get_user_agent(),600);
        data["file_size"] = http->_sp->_tools->get_file_size(tmp_file_path);
    
        response["code"] = 0; response["msg"] = "文件上传成功";
        response["data"] = data;
    }
    else{
        response["code"] = 5000305;
        data["content_type"] = request_content_type;
        response["data"] = data;
    }
    
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200; 

}

void api_file::on_http_file_token(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value rqBody = http->get_http_request_body();
    string localpath; string filename; string ext;
    Json::Value response;
    Json::Value data;
     response["code"] = 0; response["msg"] = "";
    if(rqBody["filename"].isString())  filename = rqBody["filename"].asString();
    if(rqBody["localpath"].isString()) localpath = rqBody["localpath"].asString();
    if(rqBody["ext"].isString()) ext = rqBody["ext"].asString();
    if(http->_sp->_tools->exist_file(localpath)){
        Json::Value files = db->query_file_bypath(localpath);
        int file_id;
        if(files.size() == 0 )  {
            if(filename == "") filename = localpath.substr(localpath.find_last_of("/"));
            if(ext == "") ext = localpath.substr(localpath.find_last_of("."));
            file_id = db->create_file_record(filename,localpath,ext,http->request_session["uid"].asInt(),3600 * 24 * 30 , false);
        }
        else file_id = files[0]["id"].asInt();
        data["file_id"] = http->_sp->_tools->str_base64_encode(to_string(file_id));
        string file_token = db->create_file_token(file_id,http->get_client_ip(),http->get_user_agent(),24 * 3600);
        data["file_token"] = file_token ; 
    }
    else { data["file_token"].isNull();  response["msg"] = "文件不存在"; response["code"] = 5000306;}
    data["file_path"] = localpath;
    response["data"] = data;
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200; 
}

void api_file::on_http_file_upload_download(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value rqBody = http->get_http_request_body();
    string download_url; string ext;
    Json::Value response; Json::Value data;
    if(rqBody["download_url"].isString())    download_url = rqBody["download_url"].asString();
    if(rqBody["ext"].isString())             ext = rqBody["ext"].asString();
    int user_level = http->request_session["level"].asInt();
    if(user_level < 2){
        response["code"] = 5000004; response["msg"] = "你无权限请求该接口"; response["data"] = Json::Value::null;
    }
    else{
        if(download_url == ""){
            response["code"] = 5000001; response["msg"] = "download_url 参数不能为空";
            data["download_url"] = download_url;
        }
        else if(ext == ""){
            response["code"] = 5000001; response["msg"] = "ext 参数不能为空";
            data["download_url"] = download_url;
        }
        else{
            
            string file_ext =  (string)"." + ext;
            string file_name = http->_sp->_tools->get_uuid() + file_ext;
            string local_path = (string)"./data/upload/" + file_name;
            http->console_log("[DEBUG]下载[URL:" + download_url + "]到本地路径:" + local_path);
            CURL *curl; FILE *fp; CURLcode res;
            curl = curl_easy_init();
            if(curl){
                fp = fopen(local_path.c_str(),"wb");
                if(fp == NULL){
                    response["code"] = 5000307; response["msg"] = "创建本地文件失败";
                    data["ext"] = ext; data["local_path"] = local_path;   data["download_url"] = download_url;
                }
                else{
                    char curl_error_buf[CURL_ERROR_SIZE];

                    curl_easy_setopt(curl,CURLOPT_URL,download_url.c_str());
                    curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,NULL);
                    curl_easy_setopt(curl,CURLOPT_ERRORBUFFER,curl_error_buf);
                    curl_easy_setopt(curl,CURLOPT_WRITEDATA, fp);
                    curl_easy_setopt(curl,CURLOPT_CONNECTTIMEOUT,3);
                    curl_easy_setopt(curl,CURLOPT_TIMEOUT,3);
                    http->console_log("[DEBUG]开始下载文件...");
                    res = curl_easy_perform(curl);
                    string curl_error_msg  = "";
                    fclose(fp);
                    curl_easy_cleanup(curl);
                    if(res != CURLE_OK) {
                        curl_error_msg = curl_error_buf;
                        response["code"] = 5000307; response["msg"] = "下载文件失败";
                        data["ext"] = ext ;   data["download_url"] = download_url; data["curl_error_msg"] = curl_error_msg;
                        response["data"] = data; 
                    }
                    else{
                        http->console_log("[DEBUG]文件下载结束...");
                        response["code"] = 0; response["msg"] = "下载文件到本地成功";
                        if(rqBody["need_hash"].isString()){
                            if(rqBody["need_hash"].asString() == "md5") {
                                data["file_hash"] =  http->_sp->_tools->get_file_md5(local_path);
                                data["file_hash_type"] = rqBody["need_hash"].asString();
                            }
                            if(rqBody["need_hash"].asString() == "sha1"){
                                data["file_hash"] =  http->_sp->_tools->get_file_sha1(local_path);
                                data["file_hash_type"] = rqBody["need_hash"].asString();
                            }
                            if(rqBody["need_hash"].asString() == "sha256"){
                                data["file_hash"] =  http->_sp->_tools->get_file_sha256(local_path);
                                data["file_hash_type"] = rqBody["need_hash"].asString();
                            }
                        }
                        int file_id = db->create_file_record(file_name,local_path,file_ext,http->request_session["uid"].asInt(),60 * 10);
                        data["file_id"] = http->_sp->_tools->str_base64_encode(to_string(file_id));
                        data["file_size"] = http->_sp->_tools->get_file_size(local_path);
                        string file_token = db->create_file_token(file_id,http->get_client_ip(),http->get_user_agent(),60 * 10);
                        data["file_token"] = file_token;
                        response["data"] = data; 
                    }
                }
            }
        }
    }
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200; 
}