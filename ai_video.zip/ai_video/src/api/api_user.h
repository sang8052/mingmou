#pragma once

#include "common.h"
class api_user{
    public:
      
        static void on_http_user_info(void* handle);
        static void on_http_user_update_password(void *handle);
        static void on_http_user_query_child(void *handle);
        static void on_http_user_update_info(void *handle);
        static void on_http_user_create(void *handle);
};
