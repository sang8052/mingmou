#pragma once

#include "common.h"

class api_http_handle{
    public:
        static bool on_hook_before_handle(void* handle);
        static bool on_hook_after_handle(void* handle);
};
