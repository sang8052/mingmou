#pragma once

#include "common.h"

// 加载 ffmpeg 的头文件
extern "C" {
	#include "libavcodec/avcodec.h"
	#include "libavformat/avformat.h"
	#include "libavutil/avutil.h"
	#include "libavutil/imgutils.h"
	#include "libswscale/swscale.h"
}
#include "opencv2/opencv.hpp"


class api_video{
	public:
    	static void on_http_stream_captcha(void* handle);
    	static void on_http_stream_add(void* handle);
};