#pragma once

#include "common.h"
#include "curl/curl.h"

class api_file{
    public:
        static void on_http_file_download(void* handle);
        static void on_http_file_upload(void* handle);
        static void on_http_file_token(void* handle);
        static void on_http_file_upload_download(void* handle);
};
