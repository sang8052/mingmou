#include "api_user.h"


void api_user::on_http_user_info(void* handle){
    // 强制类型转换
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value response;Json::Value data;
    int uid; string _uid;
    Json::Value route = http->get_http_request_route();
    if(route["uid"].isString())  _uid = route["uid"].asString();
    response["code"] = 0; response["msg"] = "操作成功";
    uid = db->check_user_child_auth(http->request_session["uid"].asInt(),http->request_session["level"].asInt(),_uid);
    if(uid > 0){
       Json::Value user = db->query_user_account(uid)[0];
       vector<string> fields = {"uid","username","nickname","level","status","extend","ban_msg","last_login_ip","create_time","last_login_time"};
        for(int i=0;i<fields.size();i++){
            data[fields[i]] = user[fields[i]];
        }
       data["puid"] = user["parent_uid"];
    }
    else{
        response["code"] = 5000004;
        response["msg"] = uid == -1 ? "你无权访问该用户的资料" : "用户不存在!" ;
        data["uid"] = atoi(_uid.c_str()); data["login_uid"] = http->request_session["uid"].asInt(); data["level"] = http->request_session["level"].asInt();
        response["data"] = data;
    }
    response["data"] = data;
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200;  
}
void api_user::on_http_user_update_password(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    int uid; string _uid;
    Json::Value route = http->get_http_request_route();
    Json::Value response;Json::Value data;

    if(route["uid"].isString())  _uid = route["uid"].asString();
     uid = db->check_user_child_auth(http->request_session["uid"].asInt(),http->request_session["level"].asInt(),_uid);
    if(uid > 0){
        Json::Value rqBody = http->get_http_request_body();
        string old_password = ""; string new_password = "";
        if(rqBody["old_password"].isString()) old_password = rqBody["old_password"].asString();
        if(rqBody["new_password"].isString()) new_password = rqBody["new_password"].asString();
        bool update_password = false;
        // 修改自己的密码
        if(uid == http->request_session["uid"].asInt()) {
            // 检查旧的密码是否正确
            Json::Value user = db->query_user_account(uid)[0];
            string _password = http->_sp->_tools->str_hash_sha256( old_password + ":" +  user["salt"].asString()) ;
            if(_password != user["password"].asString()){
                 response["code"] = 5000402;
                 response["msg"] = "用户的原始密码不正确!";
                 data["uid"] = atoi(_uid.c_str()); data["login_uid"] = http->request_session["uid"].asInt();
                 data["old_password"] = old_password; data["new_password"] = new_password;
                 response["data"] = data;
            }
            else update_password = true;

        }
        else update_password = true;
        if(update_password) {
            db->update_user_password(uid,new_password);
            response["code"] = 0; response["msg"] = "操作成功!";
            data["uid"] = atoi(_uid.c_str()); data["login_uid"] = http->request_session["uid"].asInt();
            response["data"] = data;
        }
    }
    // 用户不存在 或者无权限访问
    else{
        response["code"] = 5000004;
        response["msg"] = uid == -1 ? "你无权访问该用户的资料" : "用户不存在!" ;
        data["uid"] = atoi(_uid.c_str()); data["login_uid"] = http->request_session["uid"].asInt(); data["level"] = http->request_session["level"].asInt();
        response["data"] = data;
    }
     response["data"] = data;
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200; 
}
void api_user::on_http_user_query_child(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value response;Json::Value data;
    Json::Value route = http->get_http_request_route();
    int uid = -1; string _uid;
    if(route["uid"].isString())  _uid = route["uid"].asString();

     Json::Value rqParams = http->get_http_request_query();
    int pageSize = 10; int pageNum = 1;
    if(rqParams["pagenum"].isString())   pageNum = atoi(rqParams["pagenum"].asString().c_str());
    if(rqParams["pagesize"].isString())  pageSize = atoi(rqParams["pagesize"].asString().c_str());
    if(pageNum <= 0) pageNum = 1;  if(pageSize <=0) pageSize = 10;

    // 判断当前登录的用户的权限 
    int user_level = http->request_session["level"].asInt();
    if(user_level == 0){response["code"] = 5000004; response["msg"] = "你无权限请求该接口"; response["data"] = Json::Value::null;}
    else{
        if(user_level == 1 && _uid != "") {response["code"] = 5000004; response["msg"] = "普通用户不支持使用 uid 参数查询"; response["data"] = Json::Value::null;}
        else{
            if(_uid!="") uid = atoi(_uid.c_str());
            else uid = http->request_session["uid"].asInt();
            data["childs"] = db->query_user_childs(uid, http->request_session["uid"].asInt(),pageNum,pageSize);
            data["count"] = data["childs"].size();
            data["puid"] = uid > 0  ? to_string(uid) : "all";
            data["login_uid"] =   http->request_session["uid"].asInt();
            response["code"] = 0;
            response["msg"] = "操作成功";
            response["data"] = data;
        }
    }
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200;  
}
void api_user::on_http_user_update_info(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    Json::Value response;Json::Value data;
    Json::Value route = http->get_http_request_route();
    int uid = -1; string _uid;
    if(route["uid"].isString())  _uid = route["uid"].asString();
    int user_level = http->request_session["level"].asInt();
    if(user_level == 0){
        response["code"] = 5000004; response["msg"] = "你无权限请求该接口!"; response["data"] = Json::Value::null;
    }
    else{
        uid = db->check_user_child_auth(http->request_session["uid"].asInt(),http->request_session["level"].asInt(),_uid);
        if(uid > 0){
            Json::Value rqBody = http->get_http_request_body();
            Json::Value update;
            bool update_checkup = true;
            if(rqBody["nickname"].isString()) update["nickname"] = rqBody["nickname"].asString();
            if(rqBody["level"].isInt() && user_level == 2){
                if(rqBody["level"].asInt() < 0 && rqBody["level"] > 2) {
                     update_checkup = false;
                     response["code"] = 5000001; response["msg"] = "字段[level]的取值范围为 0-2 之间的整数"; response["data"] = Json::Value::null;
                }
                else update["level"] ==  rqBody["level"].asInt();
            }
          
            if(rqBody["status"].isInt()){
                if(rqBody["status"].asInt() < 0 && rqBody["status"] > 1) {
                     update_checkup = false;
                     response["code"] = 5000001; response["msg"] = "字段[status]的取值范围为 0-1 之间的整数"; response["data"] = Json::Value::null;
                }
                 else update["status"] ==  rqBody["status"].asInt();
            }
            if(rqBody["extend"].isString()) update["extend"] = rqBody["extend"].asString();
            if(rqBody["ban_msg"].isString()) update["ban_msg"] = rqBody["ban_msg"].asString();
            if(update_checkup) {
                response["code"] = 0; response["msg"] = "操作成功"; 
                response["data"] = db->update_user_info(uid,update);
            }
        }
        else{
            response["code"] = 5000004;
            response["msg"] = uid == -1 ? "你无权访问该用户的资料" : "用户不存在!" ;
            data["uid"] = atoi(_uid.c_str()); data["login_uid"] = http->request_session["uid"].asInt(); data["level"] = http->request_session["level"].asInt();
            response["data"] = data;
        }
    }
    http->response_body = http->_sp->_tools->json_encode(response); 
    http->response_header->http_code = 200;  
}
void api_user::on_http_user_create(void *handle)
{
    http_handle *http = (http_handle*)handle;
    ai_db *db = new ai_db(http->_sp->_conn,http->_sp->_config,http->_sp->_tools);
    int user_level = http->request_session["level"].asInt();
    Json::Value rqBody = http->get_http_request_body();
    Json::Value data; Json::Value response;
    if(user_level == 0){
        response["code"] = 5000004; response["msg"] = "你无权创建用户!"; response["data"] = Json::Value::null;
    }
    else{
        int n_level = 0;
        if(user_level == 2) n_level = atoi(rqBody["userlevel"].asString().c_str());
        string username;string password; string nickname; string extend;
         if(rqBody["username"].isString()) username = rqBody["username"].asString();
         if(rqBody["password"].isString()) password = rqBody["password"].asString();
         if(rqBody["nickname"].isString()) nickname = rqBody["nickname"].asString();
         if(rqBody["extend"].isString())   extend   = rqBody["extend"].asString();
         if(username == "" || password == "" || nickname == ""){
            response["code"] = 5000001; response["msg"] = "字段username,password,nickname的值不能为空";
            data["username"] = username; data["password"] = password; data["nickname"] = nickname;
         }
         else{
                // 查询系统中是否存在 同名的用户
                Json::Value user = db->query_user_account(username);
                if(user.size()!=0){
                    response["code"] = 5000401; response["msg"] = "该用户已经存在!";
                    data["username"] = username;
                }
                else{
                    // 查询新用户的 uid
                    Json::Value nuser;
                    nuser["uid"] =  db->query_new_user_uid();
                    nuser["parent_uid"] = n_level == 0 ? http->request_session["uid"].asInt() : nuser["uid"];
                    nuser["username"] = username; nuser["salt"] = http->_sp->_tools->get_uuid(); 
                    nuser["password"] = http->_sp->_tools->str_hash_sha256( password + ":" +  user["salt"].asString()) ;
                    nuser["nickname"] = nickname; nuser["level"] = n_level; nuser["status"] = 1;
                    nuser["extend"] = extend ;
                    http->_sp->_conn->quick_mysql_exec(db->sobj->sql_insert("user_account",nuser));
                    response["code"] = 0; response["msg"] = "操作成功";
                    data["uid"] = nuser["uid"] ; data["username"] = username; data["level"] = n_level;
                    response["data"] = data;
                }
         }
    }
    http->response_body = http->_sp->_tools->json_encode(response);
    http->response_header->http_code = 200;
}
