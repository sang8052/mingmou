#include "app.h"
// 定义app 全局变量

std::mutex console_lock;

const string APP_VERSION =K_APP_VERSION " " K_APP_BRANCH;
const string APP_AUTHOR_MAIL = "mail@szhcloud.cn";
const string APP_AUTHOR = "sudemqaq";


const vector <vector<string>> APP_LIBS = {
	{"embedFiglet","1.0","https://github.com/ebertolazzi/embedFiglet"},
	{"simpleini","4.19","https://github.com/brofield/simpleini"},
	{"jsoncpp","1.9.5","https://github.com/open-source-parsers/jsoncpp"},
	{"redis-plus-plus","1.3.8","https://github.com/sewenew/redis-plus-plus" },
	{"libmysql","8.0.32","https://github.com/mysql/mysql-server"},
	{"libuuid","1.0.3","https://sourceforge.net/projects/libuuid/"},
	{"boost","1.82.0","https://github.com/boostorg/boost"},
	{"zlmediakit","7.0[master:f8285a3]","https://github.com/ZLMediaKit/ZLMediaKit/"},
	{"ffmpeg","6.0","https://www.ffmpeg.org/"},
	{"opencv","4.8.0","https://github.com/opencv/opencv"},
	{"CUDA","12.0","https://developer.nvidia.com/cuda-downloads"},
	{"TensorRT","8.6.1.6","https://github.com/NVIDIA/TensorRT"},
	{"yolov8","","https://github.com/ultralytics/ultralytics"},
	{"r3","2.0[2.0:91405ad]","https://github.com/c9s/r3"}
};

  

