#pragma once

#include "arcsoft_face_sdk.h"
#include "amcomdef.h"
#include "asvloffscreen.h"
#include "merror.h"

#include "yolo/utils/yolo.h"
#include "yolo/yolov8.h"

#include "app.h"
#include "Figlet.hh"
#include <unistd.h>
#include <thread>

#include "extend/tools.h"
#include "extend/config.h"
#include "extend/conn.h"

#include "thread/thread_struct.h"
#include "thread/api_restful.h"
#include "thread/file_expire.h"
#include "thread/video_pull.h"
#include "thread/video_push.h"
#include "thread/video_ai.h"




#include "ai_db.h"
#include "mk_mediakit.h"




class ai_video
{

    public:
        ai_video();
        sys_thread *thread_pools;
        tools* _tools;
        config* _config;
        conn* _conn;
        stream_obj *p_stream;
        int thread_id = 0;
        void show_app_welcome();
        bool load_config();
        void run_server();
};

