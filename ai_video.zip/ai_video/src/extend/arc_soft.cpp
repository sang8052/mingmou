#include "arc_soft.h"


ASVLOFFSCREEN arc_soft::get_image_offscreen(cv::Mat img)
{
    ASVLOFFSCREEN offscreen = { 0 };
	offscreen.u32PixelArrayFormat = ASVL_PAF_RGB24_B8G8R8;
    offscreen.i32Width = img.cols;
    offscreen.i32Height = img.rows;
    offscreen.pi32Pitch[0] = (img.cols*img.elemSize()+3)/4*4;
    offscreen.ppu8Plane[0] = img.data;
    return offscreen;
}

arc_soft::arc_soft(tools *tools, int thread_id, int child_id)
{
     // 初始化人脸识别引擎
    this->hface = NULL;
    MInt32 mask = ASF_FACE_DETECT | ASF_FACERECOGNITION | ASF_AGE | ASF_GENDER | ASF_IMAGEQUALITY | ASF_MASKDETECT | ASF_UPDATE_FACEDATA ;
    //this->console_log("[LOG]mask_id:" + to_string(mask));
	this->res = ASFInitEngine(ASF_DETECT_MODE_IMAGE, ASF_OP_ALL_OUT,  FACE_MAX_NUM, mask, &this->hface);
    if ( this->res != MOK) this->console_log("[WARNING]ARC_SOFT::ASFDetectFacesEx 执行失败,Code:" + this->res );
    this->_tools = tools;
}

arc_soft::~arc_soft()
{
    this->detectedFaces = {0};
    ASFUninitEngine(this->hface);
    this->newImg.release();

}
void arc_soft::console_log(string log)
{
    this->_tools->console_log(log, this->thread_id, this->child_id);
}

cv::Mat arc_soft::image_init(cv::Mat OriginImage)
{
    Rect roi(0,0,OriginImage.cols - OriginImage.cols % 4,OriginImage.rows);
    this->newImg  = cv::Mat (roi.height, roi.width, IPL_DEPTH_8U);
    OriginImage(roi).copyTo(this->newImg );
    return this->newImg;
}
cv::Mat arc_soft::image_init(string filepath)
{
    cv::Mat originImg = imread(filepath);
    this->newImg = this->image_init(originImg);
    return newImg;
}

Json::Value arc_soft::get_face_postion(string filepath,bool save_img=true)
{
    cv::Mat img = imread(filepath);
    this->result_file_path = FACE_RESULT_PATH + this->_tools->get_uuid() + ".jpg";
    this->newImg = this->image_init(img);
    this->detectedFaces = { 0 };
    ASVLOFFSCREEN offscreen = this->get_image_offscreen(this->newImg);
    this->res = ASFDetectFacesEx(this->hface, &offscreen, &this->detectedFaces);
    if ( this->res != MOK) this->console_log("[WARNING]ARC_SOFT::ASFDetectFacesEx 执行失败,Code:" + this->res );
    this->result_face_num = detectedFaces.faceNum;
    Json::Value faces = Json::arrayValue;
    for(int i =0;i<this->detectedFaces.faceNum;i++){
        Json::Value face;Json::Value position;
        position["face"] = Json::arrayValue;    position["fore_head"] = Json::arrayValue;
        position["face"].append(this->detectedFaces.faceRect[i].left);
        position["face"].append(this->detectedFaces.faceRect[i].top);
        position["face"].append(this->detectedFaces.faceRect[i].right);
        position["face"].append(this->detectedFaces.faceRect[i].bottom);
        position["fore_head"].append(this->detectedFaces.foreheadRect[i].left);
        position["fore_head"].append(this->detectedFaces.foreheadRect[i].top);
        position["fore_head"].append(this->detectedFaces.foreheadRect[i].right);
        position["fore_head"].append(this->detectedFaces.foreheadRect[i].bottom);
  
        int image_x = this->detectedFaces.faceRect[i].left;
        int image_y = this->detectedFaces.faceRect[i].top;
        int image_width = this->detectedFaces.faceRect[i].right - image_x;
        int image_height = this->detectedFaces.faceRect[i].bottom - image_y;
        if(save_img) cv::rectangle(this->newImg,cv::Rect(image_x,image_y,image_width,image_height),cv::Scalar(0,0,255),3);
        if(save_img) cv::putText(this->newImg, "ID:" + to_string(i), cv::Point(image_x + 30,image_y + 45), cv::FONT_HERSHEY_SIMPLEX, FACE_RESULT_FONT_SIZE, cv::Scalar(FACE_RESULT_COLOR), 3);

        face["id"] = i;
        face["orient"] = this->_tools->arc_soft_orient(detectedFaces.faceOrient[i]); 
        face["position"] = position;

        faces.append(face);
    }
    if(save_img) cv::imwrite(this->result_file_path,this->newImg);
    img.release();
    return faces;
}

Json::Value arc_soft::get_face_postion_cv(cv::Mat img)
{
    this->newImg = this->image_init(img);
    this->detectedFaces = { 0 };
    ASVLOFFSCREEN offscreen = this->get_image_offscreen(this->newImg);
    this->res = ASFDetectFacesEx(this->hface, &offscreen, &this->detectedFaces);
    if ( this->res != MOK) this->console_log("[WARNING]ARC_SOFT::ASFDetectFacesEx 执行失败,Code:" + this->res );
    this->result_face_num = detectedFaces.faceNum;
    Json::Value faces = Json::arrayValue;
    for(int i =0;i<this->detectedFaces.faceNum;i++){
        Json::Value face;Json::Value position;
        position["face"] = Json::arrayValue;    position["fore_head"] = Json::arrayValue;
        position["face"].append(this->detectedFaces.faceRect[i].left);
        position["face"].append(this->detectedFaces.faceRect[i].top);
        position["face"].append(this->detectedFaces.faceRect[i].right);
        position["face"].append(this->detectedFaces.faceRect[i].bottom);
        position["fore_head"].append(this->detectedFaces.foreheadRect[i].left);
        position["fore_head"].append(this->detectedFaces.foreheadRect[i].top);
        position["fore_head"].append(this->detectedFaces.foreheadRect[i].right);
        position["fore_head"].append(this->detectedFaces.foreheadRect[i].bottom);
        face["id"] = i;
        face["orient"] = this->_tools->arc_soft_orient(detectedFaces.faceOrient[i]); 
        face["position"] = position;
        faces.append(face);
    }
    img.release();
    return faces;
}

int arc_soft::get_face_num(string filepath)
{
    if(this->result_face_num ==-1)  this->get_face_postion(filepath);
    return this->result_face_num;
}

Json::Value arc_soft::get_face_detail(string filepath)
{

    cv::Mat img = imread(filepath);
    ASF_AgeInfo ageInfo = { 0 };
    ASF_GenderInfo genderInfo = { 0 };
    ASF_MaskInfo  maskInfo = {0};
    Json::Value faces = this->get_face_postion(filepath,false);
    ASVLOFFSCREEN offscreen = this->get_image_offscreen(this->newImg);
   //  获取人脸详情信息
   if(this->result_face_num > 0){
        MInt32 processMask = ASF_AGE | ASF_GENDER | ASF_MASKDETECT;
        this->res = ASFProcessEx(this->hface, &offscreen, &this->detectedFaces, processMask); 
        if (this->res != MOK) this->console_log("[WARNING]ARC_SOFT::ASFProcessEx 执行失败,Code:" + this->res );
        this->res = ASFGetAge(hface, &ageInfo);
        if (this->res != MOK) this->console_log("[WARNING]ARC_SOFT::ASFGetAge 执行失败,Code:" + this->res );
        this->res = ASFGetGender(hface, &genderInfo);
        if (this->res != MOK) this->console_log("[WARNING]ARC_SOFT::ASFGetGender 执行失败,Code:" + this->res );
        this->res = ASFGetMask(hface, &maskInfo);
        if (this->res != MOK) this->console_log("[WARNING]ARC_SOFT::ASFGetMask 执行失败,Code:" + this->res );

        for(int i =0;i<this->detectedFaces.faceNum;i++){
            string gender = "";
            string wear_glassed = "";
            switch( genderInfo.genderArray[i]){case 0: gender = "man";case 1: gender = "woman";default: gender = "unknow";}
            switch( this->detectedFaces.faceAttributeInfo.wearGlasses[i]){ case 0: wear_glassed ="none";case 1: wear_glassed= "glasses";case 2: wear_glassed = "sunglasses";}
            faces[i]["age"] = ageInfo.ageArray[i];
            faces[i]["gender"] = gender;
            faces[i]["wear_glassed"] = wear_glassed;
            faces[i]["in_boundary"] = this->detectedFaces.faceIsWithinBoundary[i] == 1 ? true : false;
            faces[i]["left_eye"] =   this->detectedFaces.faceAttributeInfo.leftEyeOpen[i] == 1 ? true : false;
            faces[i]["right_eve"] =   this->detectedFaces.faceAttributeInfo.leftEyeOpen[i] == 1 ? true : false;
            faces[i]["mouth"] =   this->detectedFaces.faceAttributeInfo.mouthClose[i] == 1 ? false : true;
            faces[i]["3dangle"] = Json::objectValue;
            faces[i]["3dangle"]["roll"] = this->detectedFaces.face3DAngleInfo.roll[i];
            faces[i]["3dangle"]["yaw"] = this->detectedFaces.face3DAngleInfo.roll[i];
            faces[i]["3dangle"]["pitch"] = this->detectedFaces.face3DAngleInfo.roll[i];
            faces[i]["mask"] = maskInfo.maskArray[i];
        }
   }
    img.release();
    return faces;
}



// 获取人脸的特征值信息
// 调用此函数前必须先调用 get_face_detail 获取人脸信息
Json::Value arc_soft::get_face_feature(Json::Value &faces)
{
    ASVLOFFSCREEN offscreen = this->get_image_offscreen(this->newImg);

    for(int i=0;i<faces.size();i++){
        ASF_SingleFaceInfo singleDetectedFaces = { 0 };
        ASF_FaceFeature feature = { 0 };
        singleDetectedFaces.faceRect.left = this->detectedFaces.faceRect[i].left;
        singleDetectedFaces.faceRect.top = this->detectedFaces.faceRect[i].left;
        singleDetectedFaces.faceRect.right = this->detectedFaces.faceRect[i].left;
        singleDetectedFaces.faceRect.bottom = this->detectedFaces.faceRect[i].left;
        singleDetectedFaces.faceOrient =  this->detectedFaces.faceOrient[i];
        singleDetectedFaces.faceDataInfo = this->detectedFaces.faceDataInfoList[i];
        this->res = ASFFaceFeatureExtractEx(this->hface, &offscreen, &singleDetectedFaces,ASF_REGISTER,faces[i]["mask"].asInt(), &feature);
        if (this->res != MOK) this->console_log("[WARNING]ARC_SOFT::ASFFaceFeatureExtractEx 执行失败,Code:" + this->res);
        faces[i]["feature"] = this->_tools->char_to_hex((char*)feature.feature,feature.featureSize," ");
        faces[i]["feature_size"] = feature.featureSize;
    }

   return faces;
}

search_result arc_soft::search_face_feature(string feature_hex,int feature_size)
{
    MFloat confidenceLevel;
    ASF_FaceFeatureInfo faceFeatureInfo = {0};
    ASF_FaceFeature feature = { 0 };
    feature.feature = (MByte*) this->_tools->hex_to_char(feature_hex);
    feature.featureSize = (MInt32)feature_size;
    this->res = ASFFaceFeatureCompare_Search(this->hface, &feature, &confidenceLevel,&faceFeatureInfo,ASF_LIFE_PHOTO);
    search_result result;
    if (this->res != MOK){
        this->console_log("[WARNING]ARC_SOFT::ASFFaceFeatureCompare_Search 执行失败,Code:" + this->res);
        return result;
    } 

    result.feature_id = atoi(faceFeatureInfo.tag);
    result.confidence = (float)confidenceLevel;
   
    return result;
}

void arc_soft::register_face_feature(Json::Value db_features)
{
    for(int j=0; j < db_features.size(); j++){

        ASF_FaceFeature feature = { 0 };
        feature.feature = (MByte*) this->_tools->hex_to_char(db_features[j]["feature_hex"].asString());
        feature.featureSize = (MInt32)db_features[j]["feature_size"].asInt();
        ASF_FaceFeatureInfo face = {0};
        face.searchId = j;
        face.feature = &feature;
        face.tag = to_string(db_features[j]["id"].asInt()).c_str();
        this->res =  ASFRegisterFaceFeature(this->hface, &face, 1);
        if (this->res != MOK) this->console_log("[WARNING]ARC_SOFT::ASFRegisterFaceFeature 执行失败,Code:" + this->res);
    } 
    

}
