#pragma once
#include <vector>
#include "conn.h"
#include "tools.h"

struct s_where{
    string key;
    string op;
    string value;
    bool and_or;
};

class sql_obj{

    private:
        // 关联的表的名称
        // string table = "";
        // 查询的字段名, 默认为 *
        // string query_fields = "*";
        // 查询的条件 
        // string query_where = "";
        // key_value 键值条件
        // Json::Value key_value;

        string insert_fields = "";
        string insert_values = "";
        string update_values = "";
        vector<s_where> wheres ;
        tools *_tools;
        conn  *_conn;
    public:
    
        sql_obj(tools *tools,conn *conn);
        string sql_value(string value);
        string sql_value(int value);
        string sql_value(double value);
        string sql_value(bool value);
        string sql_value(Json::Value value,string key);
        string sql_like_value(string value);
        string sql_insert(string table,Json::Value key_value,bool create_time=true);
        string sql_delete(string table);
        string sql_update(string table,Json::Value key_value,bool update_time=true);
        string sql_select(string talbe,vector<string> fields);
        string sql_count(string table);
        bool clear_where();
        int sql_where(string key,string op,string value,bool and_or=true);
    
};