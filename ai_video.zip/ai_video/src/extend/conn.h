#pragma once
#include "config.h"
#include "tools.h"
#include "json/json.h"
#include <sw/redis++/redis++.h>
#include "mysql.h"

using namespace sw::redis;

// Redis MYSQL 中间件
struct c_mysql_error{
	string sql;
    string msg;
    int code;
};

class conn
{

	public:
		conn(config* config);
		bool connect_db(bool msg=true);


		Redis* redis;
		MYSQL* m_conn;
		MYSQL_RES* m_result;
		MYSQL_ROW m_row;
		MYSQL_FIELD* m_field;

		Json::Value quick_mysql_query(string sql,bool show = true);
		bool   quick_mysql_exec(string sql,bool show = true);
		string quick_mysql_escape(string text);
		int    quick_last_id();
	private:
		std::mutex mysql_lock;
		config *_config;
		tools* _tools;
		bool connect_redis_pool(bool msg);
		bool connect_mysql(bool msg);
		Json::Value get_redis_info();
		string get_redis_version();
		// 自动重连到MYSQL 服务器
		void connect_mysql_if_failed();

		
};

