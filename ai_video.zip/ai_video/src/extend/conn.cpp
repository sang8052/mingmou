#include "conn.h"

conn::conn(config *config)
{
    _config = config;
    _tools = new tools();
    m_conn = mysql_init(nullptr);

}



bool conn::connect_db(bool msg)
{
    bool redis = connect_redis_pool(msg);
    bool mysql = connect_mysql(msg);
    if (redis && mysql) return true;
    else return false;
}

bool conn::connect_redis_pool(bool msg)
{
    ConnectionOptions redis_options;
    redis_options.host = _config->get_string_value("REDIS", "REDIS_HOST","127.0.0.1");
    redis_options.port = _config->get_int_value("REDIS", "REDIS_PORT", 6379);
    redis_options.password = _config->get_string_value("REDIS", "REDIS_PASSWORD", "REDISPASSWORD") ;
    redis_options.db = _config->get_int_value("REDIS", "REDIS_INDEX", 0);
    redis_options.socket_timeout = std::chrono::milliseconds(_config->get_int_value("REDIS", "REDIS_SOCKET_TIMEOUT", 200));
    ConnectionPoolOptions pool_options;
    pool_options.size = _config->get_int_value("REDIS", "REDIS_POOL_SIZE", 8);
    pool_options.wait_timeout = std::chrono::milliseconds(_config->get_int_value("REDIS", "REDIS_POOL_WAITTIME", 100));
    pool_options.connection_lifetime = std::chrono::minutes(_config->get_int_value("REDIS", "REDIS_POOL_LIFETIME", 10));
    redis = new Redis(redis_options,pool_options);
    try {
        string redis_version = get_redis_version();
        if (msg)_tools->console_log("[INFO]Redis 连接成功,Redis Server Version:" + redis_version);
        return true;
    }
    catch (exception  e) {
        string error = e.what();
        if (msg)_tools->console_log("[ERROR]Redis 服务器连接失败,Error:" + error);
        return false;
    }

}

bool conn::connect_mysql(bool msg)
{
    if (m_conn != nullptr) { mysql_close(m_conn); m_conn = nullptr; }
    m_conn = mysql_init(nullptr);
    MYSQL* res = mysql_real_connect(m_conn,
        _config->get_string_value("MYSQL", "MYSQL_HOST", "127.0.0.1").c_str(),
        _config->get_string_value("MYSQL", "MYSQL_USERNAME", "root").c_str(),
        _config->get_string_value("MYSQL", "MYSQL_PASSWORD", "MYSQLPASSWORD").c_str(),
        _config->get_string_value("MYSQL", "MYSQL_DATABASE", "test").c_str(),
        _config->get_int_value("MYSQL", "MYSQL_PORT", 3306),
        nullptr,
        0
    );
    if (res) {
        mysql_set_character_set(m_conn, "utf8");
        string sql = "SELECT VERSION()";
        mysql_query(m_conn, sql.c_str());
        mysql_commit(m_conn);
        m_result = mysql_store_result(m_conn);
        m_row = mysql_fetch_row(m_result);
        mysql_free_result(m_result);
        string mysql_version = m_row[0];
        if(msg)_tools->console_log("[INFO]MYSQL 连接成功,MYSQL Server Version:" + mysql_version);
        return true;
    }
    else {
        string error = mysql_error(m_conn);
        if (msg)_tools->console_log("[ERROR]MYSQL 服务器连接失败,Error:" + error);
        return false;
    }
}

Json::Value conn::get_redis_info() {
    string redis_info = redis->info();
    vector<string> infos =_tools->explode(redis_info, "\n");
    Json::Value Infos;
    for (int i = 0; i < infos.size(); i++) {

        if (_tools->str_include(infos[i], ":")) {
            vector<string> items =_tools->explode(infos[i], ":");
            string key = items[0];
            string value = items[1];
            Infos[key] = value;
        }
    }
    return Infos;
}

string conn::get_redis_version()
{
    Json::Value infos = get_redis_info();
    return infos["redis_version"].asString();
}

void conn::connect_mysql_if_failed()
{
    int code = mysql_ping(this->m_conn);
     if(code!=0){
        #ifdef IS_DEBUG
        string error =  "\033[" + to_string(33) + "m" + "[MYSQL_CONN]:Code:"+to_string(code)+",Msg:MYSQL 服务器连接中断,尝试重新连接"  + "\033[0m";
        cout << error << endl;
        #endif
        while(!this->connect_mysql(true)){
            _tools->console_log("[ERROR]MYSQL 服务器重连失败,3秒后重试连接");
            sleep(3);
        }
    }
}

Json::Value conn::quick_mysql_query(string sql,bool show)
{
    #ifdef IS_DEBUG
    if(show) cout << "[SQL]" << sql << endl;
    #endif
    this->mysql_lock.lock();
    this->connect_mysql_if_failed();
    int query = mysql_query(this->m_conn,sql.c_str());
   
    // SQL 执行失败
    if(query!=0){
       c_mysql_error err;  
       err.sql = sql;
       err.code = mysql_errno(this->m_conn);
       err.msg = mysql_error(this->m_conn);
       #ifdef IS_DEBUG
        string error =  "\033[" + to_string(33) + "m" + "[SQL_ERROR]:Code:" + to_string(err.code) + ",Msg:" + err.msg  + "\033[0m";
        cout << error << endl;
       #endif
       this->mysql_lock.unlock();
       throw err;
    }
    Json::Value result = Json::arrayValue;
    Json::Value row;
    vector<string> fields;
    mysql_commit(this->m_conn);
    this->m_result = mysql_store_result(this->m_conn);
    this->m_field = mysql_fetch_fields(this->m_result);
    int field_num = mysql_num_fields( this->m_result);
    while(this->m_row = mysql_fetch_row(this->m_result)){
        for(int i=0;i<field_num;i++) {
            if(this->m_row[i] == NULL) row[this->m_field[i].name] = Json::nullValue;
            else {
                if(this->m_field[i].type == MYSQL_TYPE_LONG) row[this->m_field[i].name] = atoi(this->m_row[i]);
                else if(this->m_field[i].type == MYSQL_TYPE_LONGLONG) row[this->m_field[i].name] = atoi(this->m_row[i]);
                else if(this->m_field[i].type == MYSQL_TYPE_TINY) row[this->m_field[i].name] = this->_tools->str_to_bool(this->m_row[i]);
                else row[this->m_field[i].name] = this->m_row[i];
            }
        }
        result.append(row);    
    }
    mysql_free_result(this->m_result);
    this->mysql_lock.unlock();
    return result;
}

bool conn::quick_mysql_exec(string sql,bool show)
{
    #ifdef IS_DEBUG
    if(show) cout << "[SQL]" << sql << endl;
    #endif
    this->mysql_lock.lock();
    this->connect_mysql_if_failed();
    int query = mysql_query(this->m_conn,sql.c_str());
      if(query!=0){
       c_mysql_error err;
       err.sql = sql;
       err.code = mysql_errno(this->m_conn);
       err.msg = mysql_error(this->m_conn);
       #ifdef IS_DEBUG
        string error =  "\033[" + to_string(33) + "m" + "[SQL_ERROR]:Code:" + to_string(err.code) + ",Msg:" + err.msg  + "\033[0m";
        cout << error << endl;
       #endif
       this->mysql_lock.unlock();
       throw err;
    }
    mysql_commit(this->m_conn);
    this->mysql_lock.unlock();
}

string conn::quick_mysql_escape(string text)
{
    char *result = new char[strlen(text.c_str())*2 + 1];
    mysql_real_escape_string(this->m_conn,result,text.c_str(),text.length());
    return result;
}

int conn::quick_last_id()
{
    string sql = "SELECT LAST_INSERT_ID() AS ID";
    Json::Value result = this->quick_mysql_query(sql);
    return atoi(result[0]["ID"].asString().c_str());

}
