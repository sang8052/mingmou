/*
 * @Author: SudemQaQ
 * @Date: 2024-01-17 13:37:43
 * @email: mail@szhcloud.cn
 * @Blog: https://blog.szhcloud.cn
 * @github: https://github.com/sang8052
 * @LastEditors: SudemQaQ
 * @LastEditTime: 2024-02-01 11:48:20
 * @Description: 
 */
#pragma once

#include "arcsoft_face_sdk.h"
#include "amcomdef.h"
#include "asvloffscreen.h"
#include "merror.h"

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/imgproc/imgproc_c.h>
#include <opencv2/highgui.hpp>
#include <opencv2/highgui/highgui_c.h>

#include "tools.h"

using namespace std;

struct search_result{
	float confidence = 0;
	int feature_id = -1;
};

class arc_soft
{	
	private:
        // 引擎句柄
		MHandle hface ;
		tools* _tools;
		cv::Mat newImg;
		MRESULT res = MOK;
		ASF_MultiFaceInfo detectedFaces = {0};
		int thread_id;
		int child_id;
		ASVLOFFSCREEN get_image_offscreen(cv::Mat img);
	public:
		string result_file_path = "";
		int result_face_num = -1;

        arc_soft(tools *tools, int thread_id,int child_id);
		// 析构函数
		~arc_soft();

		void console_log(string log);


		// 图片预处理 4Byte 对齐
		cv::Mat image_init(cv::Mat OriginImage);
		cv::Mat image_init(string filepath);

		// 识别人脸的坐标位置信息
		Json::Value get_face_postion(string path,bool save_img);
		Json::Value get_face_postion_cv(cv::Mat img);

		int get_face_num(string filepath);

		// 识别人脸的详细信息 包括 坐标/性别/年龄/口罩/眼睛/眼镜/嘴巴/额头/俯仰角信息
		Json::Value get_face_detail(string path);

		// 识别人脸的特征值
		Json::Value get_face_feature(Json::Value &faces); 

		// 搜索人脸特征
		search_result search_face_feature(string feature,int feature_size);

		// 注册人脸搜索对象 
		// features {id,feature_hex}
		void register_face_feature(Json::Value features);
	
		// 更新人脸搜索对象

		// 删除人脸搜索对象

		




	



			
};

