#include "config.h"

config::config(string path)
{
    this->configpath = path;
    this->ini.SetUnicode(true);
}



string config::get_string_value(string node, string key,string p_default="127.0.0.1")
{
    const char* pv = nullptr;
    pv = this->ini.GetValue(node.c_str(), key.c_str(), p_default.c_str());
    return pv;
}

int config::get_int_value(string node, string key, int p_default)
{
    const char* pv = nullptr;
    pv = this->ini.GetValue(node.c_str(), key.c_str(), to_string(p_default).c_str());
    return (int)strtol(pv, nullptr,10);
}

double config::get_double_value(string node, string key, double p_default)
{
    double pv;
    pv = this->ini.GetDoubleValue(node.c_str(), key.c_str(), p_default);
    return pv;
}

bool config::get_bool_value(string node, string key, bool p_default)
{
    bool pv;
    pv = this->ini.GetBoolValue(node.c_str(), key.c_str(), p_default);
    return pv;
}


bool config::load_config()
{
    SI_Error  rc = this->ini.LoadFile(configpath.c_str());
    if (rc < 0) {
        return false;
    }
    else {
        return true;
    }
}
