#pragma once
#include "string"
#include "SimpleIni.h"
#include "tools.h"

using namespace std;
class config
{	
	private:
		CSimpleIniA ini;
	public:
		string configpath;
		bool load_config();
		config(string path="conf.ini");
		string get_string_value(string node, string key,string p_default);
		int get_int_value(string node, string key, int p_default = 0);
		double get_double_value(string node, string key, double p_default = 0.0);
		bool get_bool_value(string node, string key, bool p_default = false);

			
};

