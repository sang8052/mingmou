#include "tools.h"

string tools::get_root_path()
{
   char* current_path;
   current_path = get_current_dir_name();
   string root_path = current_path;
   free(current_path);
   return root_path;
}

string tools::read_file(string filepath, ios_base::openmode mode)
{
    ifstream  fp;
    string content;
    fp.open(filepath, mode);
    if (fp.is_open()) {
        char tmp[1024] = { 0 };
        while (fp.getline(tmp,sizeof(tmp)))
        {
            content = content + tmp;
        }
        fp.close();
    }
    return content;
}


void tools::write_file(string filepath, string content, ios_base::openmode mode)
{
    ofstream  fp;
    fp.open(filepath, mode);
    if (fp.is_open()) {
        fp << content << endl;
    }
    fp.close();
}

void tools::write_file_binary(string filepath, string content)
{
    ofstream  fp;
    fp.open(filepath,ios::out|ios::trunc|ios::binary);
    if(fp.is_open()){
       fp.write(content.c_str(),content.size());
    }
    fp.close();
}

bool tools::remove_file(string filepath)
{
    cout << "删除文件:" << filepath << endl;
    if(remove(filepath.c_str()) !=0) {
        return false;
    }
    return true;
}

bool tools::exist_file(string filepath)
{
    if(access(filepath.c_str(),F_OK) == 0) return true;
    else return false;
}

bool tools::copy_file(string origin_path, string dist_path)
{
    boost::filesystem::path source_path = origin_path;
    boost::filesystem::path target_path = dist_path;
    boost::filesystem::copy(source_path,target_path);
    return true;
}

bool tools::move_file(string origin_path, string dist_path)
{
    boost::filesystem::path source_path = origin_path;
    boost::filesystem::path target_path = dist_path;
    boost::filesystem::rename(source_path,target_path);
}

bool tools::create_folder(string filepath)
{
    boost::filesystem::path dir = filepath;
    return boost::filesystem::create_directories(dir);
}

void tools::console_log(string log, int thread_id,int child_id)
{
    console_lock.lock();
    string console = "[" + format_current_time(true) + "]";
    string s_thread_id;
    if (thread_id == 0) s_thread_id = "Main";
    else s_thread_id = to_string(thread_id);
    if (child_id != 0) s_thread_id = s_thread_id + ":" + to_string(child_id);
    console = console + "[Thread-" + s_thread_id + "]" + log;
    int color_id = 37;
    #ifdef IS_DEBUG
    if (str_include(console, "[DEBUG]") && color_id == 37 ) color_id = 35;
    #endif
    if (str_include(console, "[INFO]") && color_id == 37) color_id = 32;
    if (str_include(console, "[WARNING]") && color_id == 37) color_id = 33;
    if (str_include(console, "[ERROR]") && color_id == 37) color_id = 31;
    string console_out = "\033[" + to_string(color_id) + "m" + console + "\033[0m";
    cout << console_out << endl;
    console_lock.unlock();
}
void tools::g_console_log(string log)
{
    console_lock.lock();
    string console = "[" + format_current_time(true) + "]";
    console = console  + log;
    int color_id = 37;
    #ifdef IS_DEBUG
    if (str_include(console, "[DEBUG]") && color_id == 37 ) color_id = 35;
    #endif
    if (str_include(console, "[INFO]") && color_id == 37) color_id = 32;
    if (str_include(console, "[WARNING]") && color_id == 37) color_id = 33;
    if (str_include(console, "[ERROR]") && color_id == 37) color_id = 31;
    string console_out = "\033[" + to_string(color_id) + "m" + console + "\033[0m";
    cout << console_out << endl;
    console_lock.unlock();
}

long tools::get_file_size(string filepath)
{
    long filesize = boost::filesystem::file_size(filepath);
    return filesize;
}

string tools::get_file_md5(string filepath)
{
    unsigned char hash [MD5_DIGEST_LENGTH];
    char data_buffer[1024];
    MD5_CTX md5_ctx;
    MD5_Init(&md5_ctx);
    std::ifstream file(filepath.c_str(), std::ios::in | std::ios::binary); 
    while (!file.eof()) {
        file.read(data_buffer, 1024); 
        int length = file.gcount();
        if (length) {
            MD5_Update(&md5_ctx, data_buffer, length); 
        }
    }
    MD5_Final(hash, &md5_ctx);
    string NewString; char buf[2];
    for(int i = 0; i < MD5_DIGEST_LENGTH; i++)
    {
        sprintf(buf,"%02x",hash[i]);
        NewString = NewString + buf;
    }
    return NewString;
}

string tools::get_file_sha1(string filepath)
{
    char buf[2];
    unsigned char hash[SHA_DIGEST_LENGTH];
    char data_buffer[1024];
    SHA_CTX sha1;
    SHA1_Init (&sha1);
    std::ifstream file(filepath.c_str(), std::ios::in | std::ios::binary); 
    while (!file.eof()) {
        file.read(data_buffer, 1024); 
        int length = file.gcount();
        if (length) {
            SHA1_Update(&sha1, data_buffer, length); 
        }
    }
    SHA1_Final(hash, &sha1);
    std::string NewString = "";
    for(int i = 0; i < SHA_DIGEST_LENGTH; i++)
    {
        sprintf(buf,"%02x",hash[i]);
        NewString = NewString + buf;
    }
	return NewString;
}

string tools::get_file_sha256(string filepath)
{
    char buf[2];
    unsigned char hash[SHA256_DIGEST_LENGTH];
    char data_buffer[1024];
    SHA256_CTX sha256;
    SHA256_Init (&sha256);
    std::ifstream file(filepath.c_str(), std::ios::in | std::ios::binary); 
    while (!file.eof()) {
        file.read(data_buffer, 1024); 
        int length = file.gcount();
        if (length) {
            SHA256_Update(&sha256, data_buffer, length); 
        }
    }
    SHA256_Final(hash, &sha256);
    std::string NewString = "";
    for(int i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        sprintf(buf,"%02x",hash[i]);
        NewString = NewString + buf;
    }
	return NewString;
}


string tools::format_timestamp(char * timestamp)
{
    char format_time[32];
    time_t tTimeStamp = atoll(timestamp);
	struct tm* pTm = gmtime(&tTimeStamp);
    strftime(format_time, 32, "%Y-%m-%d %H:%M:%S", pTm);
    return format_time;

}

string tools::format_current_time( bool mstime)
{
    system_clock::time_point tp = system_clock::now();
    time_t raw_time = system_clock::to_time_t(tp);
    struct tm* timeinfo = std::localtime(&raw_time);
    char buf[24] = { 0 };
    strftime(buf, 24, "%Y-%m-%d %H:%M:%S", timeinfo);
    if (mstime) {
        std::chrono::milliseconds ms = std::chrono::duration_cast<std::chrono::milliseconds>(tp.time_since_epoch());
        std::string milliseconds_str = std::to_string(ms.count() % 1000);

        if (milliseconds_str.length() < 3) {
            milliseconds_str = std::string(3 - milliseconds_str.length(), '0') + milliseconds_str;
        }
        return string(buf) + "," + milliseconds_str;
    }
    else return buf;
    

}

string tools::format_current_time_ex(bool mstime)
{
    string current_time =  format_current_time();
    current_time = str_replace(current_time,"-","");
    current_time = str_replace(current_time,":","");
    current_time = str_replace(current_time,",","");
    current_time = str_replace(current_time," ","");
    return current_time;
}

string tools::format_gmt_current_time()
{
   system_clock::time_point tp = system_clock::now();
    time_t raw_time = system_clock::to_time_t(tp);
    struct tm* gmt_time = std::gmtime(&raw_time);
    char buf[64] = { 0 };
    strftime(buf, 64, "%a, %d %b %Y %H:%M:%S GMT", gmt_time);
    return buf;
}

string tools::get_gmt_file_write_time(string filepath)
{
    boost::filesystem::path fp(filepath);
	time_t raw_time = boost::filesystem::last_write_time(fp);
	struct tm* gmt_time = std::gmtime(&raw_time);
    char buf[64] = { 0 };
    strftime(buf, 64, "%a, %d %b %Y %H:%M:%S GMT", gmt_time);
    return buf;
}


long tools::get_ms_timestamp()
{
    std::chrono::milliseconds ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()
    );

    return ms.count();
}

int tools::get_timestamp()
{
    std::time_t t = std::time(0);
    return t;
}

bool tools::str_include(string text, string sub)
{
    if (text.size() >= sub.size()) {
        int len = int(sub.size());
        for(int i=0;i<int(text.size());i++){
            string tmp = text.substr(i, len);
            if (tmp == sub) return true;
        }
        return false;
    }
    return false;
}

bool tools::str_start_include(string text, string sub)
{
    if(!str_include(text,sub)) {
        return false;
    }
    else{
        string tmp = text.substr(0,strlen(sub.c_str()));
        if(tmp == sub) return true;
        return false;
    }
}

bool tools::str_to_bool(string text)
{
   text = this->str_lower(text);
   if(text == "true") return true;
   else if(text == "1") return true;
   else if(text == "false") return false;
   else return false;
}

string tools::bool_to_str(bool status, bool upper)
{
   string str;
   if(status) str = "true"; else str = "false";
   if(upper) return this->str_upper(str);
   else return str;
}

string tools::str_join(vector<string> strs, string c)
{
    string result ; 
    for(int i=0;i< strs.size(); i++){
        if(i == 0) result = strs[i];
        else result = result + c + strs[i];
    }
    return result;
}


vector<string> tools::explode(string text, string sub,int count)
{
    vector <string> result;
    int pos = text.find(sub.c_str());
    int c = 0;
    while (pos != -1)
    {
        string tmp = text.substr(0, pos);
        result.push_back(tmp);
        text = text.substr(pos + sub.size());
        c = c + 1;
        if (count > 0) {
            if (c >= count ) pos = -1;
        }
        else pos = text.find(sub.c_str());
    }
    result.push_back(text);
    return result;

}



string tools::json_encode(Json::Value data,bool compress)
{
    Json::StreamWriterBuilder writerBuilder;
    if(compress) writerBuilder["indentation"] = "";
    std::unique_ptr<Json::StreamWriter> json_write(writerBuilder.newStreamWriter());
    std::ostringstream ss;
    json_write->write(data, &ss);
    std::string strContent = ss.str();
    return strContent;
 
}

Json::Value tools::json_decode(string data)
{
    Json::Value Root;
    Json::Reader JReader;
    JReader.parse(data, Root);
    return Root;
}

string tools::get_uuid()
{
    uuid_t tmp_uuid;
    char uuid_str[40];
    uuid_generate_random(tmp_uuid);
    uuid_unparse(tmp_uuid, uuid_str);
    return uuid_str;


}

string tools::str_zfill(string text, int length)
{
    stringstream ss;		
    ss << setw(length) << setfill('0') << text ;
    string res;
    ss >> res;
    return res;  
}

string tools::str_upper(string text)
{
    transform(text.begin(), text.end(), text.begin(), ::toupper);
    return text;
}

string tools::str_lower(string text)
{
    transform(text.begin(), text.end(), text.begin(), ::tolower);
    return text;
}

string tools::str_trim(string text)
{
    return  boost::trim_copy(text);
}

string tools::str_replace(string text, string ostr, string nstr)
{
    return boost::replace_all_copy(text, ostr, nstr);
}
string tools::char_to_hex(const char *str, int len,string space=" ")
{
    string hex_string; 
    string hex_buffer;
    static const char *hex = "0123456789ABCDEF";
    for(int i=0;i<len;i++){
        hex_buffer = "";
        hex_buffer.push_back(hex[(str[i] >> 4) & 0xf]);
        hex_buffer.push_back(hex[str[i] & 0xf]);
        if(hex_string.size() == 0) hex_string = hex_buffer;
        else hex_string = hex_string + space + hex_buffer;
    }
    return hex_string;
}

char *tools::hex_to_char(string text)
{
    text = str_replace(text," ","");
    int pos = 0; string tmp = "";
    char* buffer = new char[text.size()];
    int val = 0; 
    while (pos < text.size())
    {
        tmp = text.substr(pos,2);
        val = stoi(tmp,0,16);
        buffer[pos/2] = val;
        pos = pos + 2;
    }
    return buffer;
}

int tools::htoi(char *s)
{
    int value;
    int c;

    c = ((unsigned char*)s)[0];
    if (isupper(c))
        c = tolower(c);
    value = (c >= '0' && c <= '9' ? c - '0' : c - 'a' + 10) * 16;

    c = ((unsigned char*)s)[1];
    if (isupper(c))
        c = tolower(c);
    value += c >= '0' && c <= '9' ? c - '0' : c - 'a' + 10;

    return (value);
}

 bool tools::in_list(vector<string> list, string text)
 {
     for (int i = 0; i < list.size(); i++) {
         if (list[i] == text) return true;
     }
     return false;
 }

 int tools::find_list_index(vector<string> list, string text)
 {
     for (int i = 0; i < list.size(); i++) {
         if (list[i] == text) return i;
     }
     return -1;
 }

 string tools::get_ip_socketaddr(sockaddr_in* addr)
 {
     string server_host = inet_ntoa(addr->sin_addr);
     int server_port = ntohs(addr->sin_port);
     return server_host + ":" + to_string(server_port);
 }

 vector<float> tools::letterbox_image(const cv::Mat& src, cv::Mat &dst, const cv::Size out_size)
 {
     auto in_h = static_cast<float>(src.rows);
     auto in_w = static_cast<float>(src.cols);
     float out_h = out_size.height;
     float out_w = out_size.width;

     float scale = std::min(out_w / in_w, out_h / in_h);

     int mid_h = static_cast<int>(in_h * scale);
     int mid_w = static_cast<int>(in_w * scale);

     cv::resize(src, dst, cv::Size(mid_w, mid_h));

     int top = (static_cast<int>(out_h) - mid_h) / 2;
     int down = (static_cast<int>(out_h) - mid_h + 1) / 2;
     int left = (static_cast<int>(out_w) - mid_w) / 2;
     int right = (static_cast<int>(out_w) - mid_w + 1) / 2;

     cv::copyMakeBorder(dst, dst, top, down, left, right, cv::BORDER_CONSTANT, cv::Scalar(0, 0, 0));

     std::vector<float> pad_info{static_cast<float>(left), static_cast<float>(top), scale};
     return pad_info;
 }

 vector<string> tools::regex_explode(string rule, string text)
 {
    vector<string>  result;
	boost::regex expr{rule}; 
	boost::regex_token_iterator<std::string::iterator> it{text.begin(), text.end(), expr, 1};
 	boost::regex_token_iterator<std::string::iterator> end;
  	while (it != end){
        result.push_back(*it++);
	}
    return result;
 }

 double tools::RationaltoDouble(AVRational r)
 {
     return (r.den == 0) ? 0 : (double)r.num / (double)r.den;
 }

 cv::Mat tools::avFrame2Mat(AVFrame *input_avframe)
 {
    int image_width = input_avframe->width;
    int image_height = input_avframe->height;

    cv::Mat resMat(image_height, image_width, CV_8UC3);
    int cvLinesizes[1];
    cvLinesizes[0] = resMat.step1();

    SwsContext* avFrameToOpenCVBGRSwsContext = sws_getContext(
        image_width,
        image_height,
        AVPixelFormat::AV_PIX_FMT_YUV420P,
        image_width,
        image_height,
        AVPixelFormat::AV_PIX_FMT_BGR24,
        SWS_FAST_BILINEAR,
        nullptr, nullptr, nullptr
    );

    sws_scale(avFrameToOpenCVBGRSwsContext,
        input_avframe->data,
        input_avframe->linesize,
        0,
        image_height,
        &resMat.data,
        cvLinesizes);

    if (avFrameToOpenCVBGRSwsContext != nullptr)
    {
        sws_freeContext(avFrameToOpenCVBGRSwsContext);
        avFrameToOpenCVBGRSwsContext = nullptr;
    }

    return resMat;
 }

 int tools::arc_soft_orient(int code)
 {

     int values[12] = {0,90,270,180,30,60,120,150,210,240,300,330};
     if(code>=1 && code<=12) return values[code-1];
     else return -1;
 }

 int tools::arc_soft_orient_code(int orient)
 {
    int values[12] = {0,90,270,180,30,60,120,150,210,240,300,330};
    for(int i=0;i < 12;i++) if(values[i] == orient) return i+1;
 }

 int tools::http_method(string method)
 {
    method = this->str_upper(method);
    if(method == "GET")      return METHOD_GET;
    if(method == "POST")     return METHOD_POST;
    if(method == "PUT")      return METHOD_PUT;
    if(method == "DELETE")   return METHOD_DELETE;
    if(method == "OPTIONS")  return METHOD_OPTIONS;
    if(method == "HEAD")     return METHOD_HEAD;
    if(method == "PATCH")    return METHOD_PATCH;
    return METHOD_GET;
 }

 void tools::draw_yolo_result(cv::Mat& frame, vector<yolo_result> results)
 {
     cv::Scalar color = cv::Scalar(0, 255, 0);
    cv::Point bbox_points[1][4];
    const cv::Point* bbox_point[1] = { bbox_points[0] };
	int num_points[] = { 4 };

	
    for(int i=0;i<results.size();i++){
        yolo_result result = results[i];
        if(result.label < this->default_colors.size()) color = this->default_colors[result.label];
        cv::rectangle(frame, cv::Point(result.left, result.top), cv::Point(result.right, result.bottom), color, 2, cv::LINE_AA);
        cv::String label = result.label_text;
        bbox_points[0][0] = cv::Point(result.left, result.top);
        bbox_points[0][1] = cv::Point(result.left + label.size() * 11, result.top);
        bbox_points[0][2] = cv::Point(result.left + label.size() * 11, result.top - 15);
        bbox_points[0][3] = cv::Point(result.left, result.top - 15);
        cv::fillPoly(frame, bbox_point, num_points, 1, color);	
        cv::putText(frame, label, bbox_points[0][0], cv::FONT_HERSHEY_DUPLEX, 0.6, cv::Scalar(255, 255, 255), 1, cv::LINE_AA);
        
    }
    
 }

 string tools::str_hash_sha256(string content)
 {
    char buf[2];
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, content.c_str(), content.size());
    SHA256_Final(hash, &sha256);
    std::string NewString = "";
    for(int i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        sprintf(buf,"%02x",hash[i]);
        NewString = NewString + buf;
    }
	return NewString;
 }

 string tools::str_hash_md5(string content)
 {
    char buf[2];
    unsigned char digest[MD5_DIGEST_LENGTH];
    MD5((const unsigned char*)content.c_str(), content.size(), (unsigned char*)&digest);  
    std::string HexString = "";
    for(int i = 0; i < MD5_DIGEST_LENGTH; i++){
         sprintf(buf, "%02x", (unsigned int)digest[i]);
         HexString = HexString + buf;
    }
    return HexString;
 }

 string tools::str_base64_encode(string input)
 {
    std::size_t len = input.size();
    string output;
    output.resize(boost::beast::detail::base64::encoded_size(len));
    output.resize(boost::beast::detail::base64::encode(&output[0], input.c_str(), len));
    return output;
 }

 string tools::str_base64_decode(string input)
 {
    string output;
    std::size_t len = input.size();
    output.resize(boost::beast::detail::base64::decoded_size(len));
    auto result = boost::beast::detail::base64::decode(&output[0], input.data(), len);
    output.resize(result.first);
    return output;
 }

 string tools::url_decode(string str_source)
 {
    char const* in_str = str_source.c_str();
    int in_str_len = strlen(in_str);
    int out_str_len = 0;
    string out_str;
    char* str;

    str = strdup(in_str);
    char* dest = str;
    char* data = str;

    while (in_str_len--) {
        if (*data == '+') {
            *dest = ' ';
        }
        else if (*data == '%' && in_str_len >= 2 && isxdigit((int)*(data + 1))
            && isxdigit((int)*(data + 2))) {
            *dest = (char)htoi(data + 1);
            data += 2;
            in_str_len -= 2;
        }
        else {
            *dest = *data;
        }
        data++;
        dest++;
    }
    *dest = '\0';
    out_str_len = dest - str;
    out_str = str;
    free(str);
    return out_str;
}



