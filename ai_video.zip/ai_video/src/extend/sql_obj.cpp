#include "sql_obj.h"

sql_obj::sql_obj(tools *tools,conn *conn)
{
    this->_tools = tools;
    this->_conn = conn;
}

int sql_obj::sql_where(string key,string op,string value,bool and_or){
    s_where where;
    where.key = key; where.op = op; where.value = value; where.and_or = and_or;
    this->wheres.push_back(where);
    return this->wheres.size();
}

string sql_obj::sql_insert(string table, Json::Value key_value,bool create_time){
    if(create_time) {
        if(!key_value["create_time"].isInt()) key_value["create_time"] = this->_tools->get_timestamp();
    }
    vector<string> keys= key_value.getMemberNames();
    this->insert_fields = "( " + this->_tools->str_join(keys,", ") + " )";
    vector<string> values;
   
    for(int i=0;i<keys.size();i++){
         values.push_back(this->sql_value(key_value,keys[i]));
    }
    this->insert_values = "( " + this->_tools->str_join(values,", ") + " )";

    string sql = "INSERT INTO `" + table + "` " + this->insert_fields + " VALUES " + this->insert_values;
    this->clear_where();
    return sql;
}

string sql_obj::sql_delete(string table)
{
    string sql = "DELETE FROM `" +  table + "`";
    if(this->wheres.size() != 0){
        sql = sql + " WHERE ";
    } 
    for(int i=0;i<this->wheres.size();i++){
        string twhere = "";
        if(i!=0){
            if(this->wheres[i].and_or) twhere = " AND ";
             else twhere = " OR ";
        }
        twhere = twhere + "`" +  this->wheres[i].key + "` " + this->wheres[i].op + " " + this->wheres[i].value;
        sql = sql + twhere + " ";
    }
    this->clear_where();
    return sql;
}

string sql_obj::sql_update(string table, Json::Value key_value,bool update_time)
{
    if(update_time) {
        if(!key_value["update_time"].isInt()) key_value["update_time"] = this->_tools->get_timestamp();
    }
    vector<string> keys= key_value.getMemberNames();
    string sql = "UPDATE `" +  table + "` SET ";
    vector<string> updates;
    for(int i=0;i<keys.size();i++){
        string k_value; string update;
        k_value = this->sql_value(key_value,keys[i]);
        update =   " `" + keys[i] + "` = " + k_value;
        updates.push_back(update);
    }
    this->update_values = this->_tools->str_join(updates,", ");
    sql = sql + this->update_values;
     if(this->wheres.size() != 0){
        sql = sql + " WHERE ";
    } 
    for(int i=0;i<this->wheres.size();i++){
        string twhere = "";
        if(i!=0){
            if(this->wheres[i].and_or) twhere = " AND ";
             else twhere = " OR ";
        }
        twhere = twhere + "`" +  this->wheres[i].key + "` " + this->wheres[i].op + " " + this->wheres[i].value;
        sql = sql + twhere + " ";
    }
     this->clear_where();
    return sql;

}

string sql_obj::sql_select(string table, vector<string> fields)
{
    string query_fields = "";
    if(fields.size() == 0) query_fields = "*";
    else query_fields = this->_tools->str_join(fields,", "); 
    string sql = "SELECT " + query_fields + " FROM `" +  table + "`";
    if(this->wheres.size() != 0){
        sql = sql + " WHERE ";
    } 
    for(int i=0;i<this->wheres.size();i++){
        string twhere = "";
        if(i!=0){
            if(this->wheres[i].and_or) twhere = " AND ";
             else twhere = " OR ";
        }
        twhere = twhere + "`" +  this->wheres[i].key + "` " + this->wheres[i].op + " " + this->wheres[i].value;
        sql = sql + twhere + " ";
    }
    this->clear_where();
    return sql;
}

string sql_obj::sql_count(string table)
{

    string sql = "SELECT COUNT(*) FROM `" +  table + "`";
    if(this->wheres.size() != 0){
        sql = sql + " WHERE ";
    } 
    for(int i=0;i<this->wheres.size();i++){
        string twhere = "";
        if(i!=0){
            if(this->wheres[i].and_or) twhere = " AND ";
             else twhere = " OR ";
        }
        twhere = twhere + "`" +  this->wheres[i].key + "` " + this->wheres[i].op + " " + this->wheres[i].value;
        sql = sql + twhere + " ";
    }
     return sql;
}

bool sql_obj::clear_where()
{
    this->wheres.clear();
}
string sql_obj::sql_value(string value)
{
    return "'" + this->_conn->quick_mysql_escape(value) + "'";
}

string sql_obj::sql_value(int value)
{
    return this->_conn->quick_mysql_escape(to_string(value));
}

string sql_obj::sql_value(double value)
{
    return this->_conn->quick_mysql_escape(to_string(value));
}

string sql_obj::sql_value(bool value)
{
    return this->_tools->bool_to_str(value);
}

string sql_obj::sql_value(Json::Value value, string key)
{
    string result;
    if(value[key].isString())   result = this->sql_value( value[key].asString());
    else if(value[key].isInt())      result = this->sql_value( value[key].asInt());
    else if(value[key].isDouble())   result = this->sql_value( value[key].asDouble());
    else if(value[key].isBool())     result = this->sql_value( value[key].asBool());
    else return result;
}

string sql_obj::sql_like_value(string value)
{
    return "'%" + this->_conn->quick_mysql_escape(value) + "%'";
}
