/*
 * @Author: SudemQaQ
 * @Date: 2024-01-16 19:58:13
 * @email: mail@szhcloud.cn
 * @Blog: https://blog.szhcloud.cn
 * @github: https://github.com/sang8052
 * @LastEditors: SudemQaQ
 * @LastEditTime: 2024-01-18 10:15:27
 * @Description: 
 */
#pragma once
#include "app.h"
#include <string>
#include "arest/http_handle.h"
#include "arest/arest_struct.h"
#include "extend/conn.h"
#include "extend/tools.h"
#include "extend/sql_obj.h"

struct oauth_user{
    string access_token;
    string refresh_token;
    Json::Value session;
};

class ai_db{

    private:
        tools *_tools;
        config *_config;
        Json::Value query_by_pagesize(string table,vector<string>fields,int pagenum,int pagesize);
    public:
        sql_obj *sobj;
        conn  *_conn;
        ai_db(conn *conn,config *config,tools *tools);

        http_content_type* get_http_content_type_list();
        Json::Value query_user_account(string username);
        Json::Value query_user_account(int uid);
        Json::Value query_file_need_delete(bool show_sql=false);
        Json::Value query_user_childs(int puid,int uid,int pagenum,int pagesize);
        Json::Value query_oauthToken_refresh_token(string refresh_token);
        Json::Value query_file_bypath(string filepath);
        Json::Value query_file_byid(int file_id);
        Json::Value query_video_by_stream_id(int stream_id);
        Json::Value query_sys_config(string keyword,string link_table,int link_id, int pagenum, int pagesize);
        Json::Value query_sys_config_by_config_id(int config_id);
        Json::Value query_person_by_person_id(int person_id);
        Json::Value query_person_by_feature_id(int feature_id);
        Json::Value query_person_feature_by_person_id(int person_id);
        Json::Value query_person_all_feature();
        Json::Value query_person_feature_by_feature_id(int feature_id);

        bool exist_sys_config(string item,string table);

        int check_user_child_auth(int login_uid,int level,string _uid);
        int query_new_user_uid();
        int query_user_parent_uid(int uid);
        Json::Value query_user_streams(int puid);

        void update_oauthToken_refresh_token(string refresh_token,int status);
        void update_user_password(int uid,string password);
        Json::Value update_user_info(int uid,Json::Value update);
        void update_sys_config(int config_id,string value,string extend);
        void update_file_expire(int fid,string file_path,int delete_time);
        void update_file_token(string file_token,string file_path,int delete_time);
       
        int create_video_stream(Json::Value video,int uid,string name,string extend);
        int create_file_record(string filename,string filepath,string ext,int uid,int delete_time = -1 , bool is_tmp = false);
        int create_sys_config(string item,string value,string extend,string table = "",int id = 0);
        string create_file_token(int file_id,string client_ip,string user_agent,int expire=0);
        oauth_user *oauth_create_token(string client_ip,string user_agent,Json::Value user);
        void *oauth_super_access_token_login(string client_ip,string user_agent,Json::Value user);
        int create_face_person(int uid,string name,string idcard,string ecard,string telphone,string email,string org_part,string other_json,string extend);
        int create_face_feature(int person_id,int file_id,int orient,Json::Value position,string feature_hex,int feature_size);

        void delete_file_byid(int file_id);
        void delete_sys_config(int config_id);
        void delete_sys_config(string table,int link_id);


        

};