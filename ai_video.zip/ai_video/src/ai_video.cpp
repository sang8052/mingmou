#include "ai_video.h"



#define LIB_STR_LENTH_NAME 20
#define LIB_STR_LENTH_VERSION 25
#define LIB_STR_LENTH_HOMEPAGE 80

ai_video::ai_video()
{
	this->_config = new config();
	this->_tools = new tools();
	this->thread_id = 0;
   
}

void ai_video::show_app_welcome()
{
    Figlet::small.printFramed("MingMou", cout, Figlet::FIGLET_SINGLE);
    cout << "运行目录地址:" + this->_tools->get_root_path() << endl;
    cout << "系统信息:  " << endl;
    cout << "Version:   " << APP_VERSION << endl;
    cout << "Author:    " << APP_AUTHOR << endl;
    cout << "Mail:      " << APP_AUTHOR_MAIL << endl;
    cout << "Thanks:    " << endl;
    cout << "   xia-chu https ://github.com/xia-chu" << endl;
    cout << "=======================================================" << endl;
    cout << "============       第三方拓展依赖       ===============" << endl;
    string lib_name;
    string lib_version;
    string lib_homepage; 
    int need_str = 0;
    for (int i = 0; i < int(APP_LIBS.size()); i++) {
        lib_name = "["  + APP_LIBS[i][0] + "]"; lib_version = APP_LIBS[i][1]; lib_homepage = APP_LIBS[i][2];
        if (lib_name.size() < LIB_STR_LENTH_NAME) { 
            need_str = LIB_STR_LENTH_NAME - lib_name.size();
            for (int j = 0; j < need_str; j++) lib_name = lib_name + " ";
        }
        if (lib_version.size() < LIB_STR_LENTH_VERSION) {
            need_str = LIB_STR_LENTH_VERSION - lib_version.size();
            for (int j = 0; j < need_str; j++) lib_version = lib_version + " ";
        }
        if (lib_homepage.size() < LIB_STR_LENTH_HOMEPAGE) {
            need_str = LIB_STR_LENTH_HOMEPAGE - lib_homepage.size();
            for (int j = 0; j < need_str; j++) lib_homepage = lib_homepage + " ";
        }
        cout <<  lib_name << " [Version]: " << lib_version << "    [HomePage]: " << lib_homepage << endl;
    }
    cout << "=======================================================" << endl;
    
}

bool ai_video::load_config()
{
    this->_tools->console_log("[LOG]系统自检完成,开始初始化环境...");
    this->_tools->console_log("[LOG]加载配置文件...");
    bool status = this->_config->load_config();
    if (!status) {
        string path = this->_config->configpath;
        _tools->console_log("[ERROR]读取配置文件失败,请检查配置文件[" + path + "]是否存在");
    }
    _tools->console_log("[INFO]配置文件加载成功");

    this->_conn = new conn(this->_config);
    status = _conn->connect_db();
    return status;
}




void ai_video::run_server()
{
    sys_thread *current_thread;
    //_tools->console_log("[LOG][ARC_SOFT]APP_ID:" + );
    //_tools->console_log("[LOG][ARC_SOFT]SDK_KEY:" + );

    MRESULT res = MOK;
	ASF_ActiveFileInfo activeFileInfo = { 0 };
	res = ASFGetActiveFileInfo(&activeFileInfo);
	if (res != MOK) { 
        _tools->console_log("[WARNING]虹软人脸识别SDK 离线激活失败,尝试在线激活!");
        string app_id = this->_config->get_string_value("arc_soft","app_id","Bbvyu5GeUE8eaBhyLsNcp49HW6tuPx3sqWog8i9S41Q7");
        string sdk_key = this->_config->get_string_value("arc_soft","sdk_key","EvvwdWPFj7XjL1siCQiSD2qGb9XanUowPRYyVML8o3wL");
        string active_key = this->_config->get_string_value("arc_soft","active_key","8281-1111-M125-XXKM");
        res = ASFOnlineActivation((MPChar)app_id.c_str(),(MPChar)sdk_key.c_str(),(MPChar)active_key.c_str());
        if (res != MOK && MERR_ASF_ALREADY_ACTIVATED != res){
            _tools->console_log("[ERROR]虹软人脸识别SDK 在线激活失败,请检查APP_ID,SDK_KEY");
            return ;
        } 
        res = ASFGetActiveFileInfo(&activeFileInfo);  
    }

	_tools->console_log("[INFO]虹软人脸识别SDK 激活成功!");
    const ASF_VERSION version = ASFGetVersion();
    cout << "==========================[ARC SOFT]==========================" << endl;
    cout << "版本号:" << version.Version << endl;
    cout << "编译日期:" << version.BuildDate << endl;
    cout << "授权开始日期:" << _tools->format_timestamp(activeFileInfo.startTime) << endl;
    cout << "授权结束日期:" << _tools->format_timestamp(activeFileInfo.endTime) << endl;
    cout << version.CopyRight << endl;
    cout << "==========================[ARC SOFT]==========================" << endl;

   

    
     
    // 新建 ZLM 线程
    mk_env_init1(4, 0, LOG_CONSOLE, NULL, 0, 1, "zlm.ini",0,NULL,NULL);
	int status = mk_http_server_start(8080,0);
    status = mk_rtsp_server_start(554,0);
	_tools->console_log("[INFO]启动ZLM 服务器成功");

    // 新建 虹软人脸识别对象
    


    // 新建api 线程
    this->thread_pools = new sys_thread();
    this->thread_id = this->thread_id + 1;
    api_restful ar = api_restful(this->_tools, this->_config, this->_conn,this->thread_pools);
    std::thread ar_conn(ar, this->thread_id);
    ar_conn.detach();
    this->thread_pools->thread_name = "API接口线程";
    this->thread_pools->object_type = "api_restful";
    this->thread_pools->th_object =&ar;
    this->thread_pools->thread_id = this->thread_id;
    this->thread_pools->last = nullptr;
    current_thread = this->thread_pools;

    
    // 新建文件 处理线程
    
    this->thread_id = this->thread_id + 1;
    file_expire fe = file_expire(this->_tools, this->_config, this->_conn);
    std::thread fe_conn(fe, this->thread_id);
    fe_conn.detach();
    sys_thread *n_thread = new sys_thread();
    current_thread->next = n_thread;
    n_thread->last = current_thread;
    n_thread->thread_id = this->thread_id;
    n_thread->thread_name = "文件异步删除线程";
    n_thread->object_type = "file_expire";
    n_thread->th_object = &fe;
    n_thread->next = nullptr;
    current_thread = n_thread;

   

    
    ai_db db = ai_db(this->_conn,this->_config,this->_tools);

   if(USE_YOLO_FRAME == 1){
        video_ai *ai = new video_ai(this->_tools, this->_config, this->_conn);
        ai->init_yolo_model("./data/models/yolov8n.trt",1080,1920);
        ai->test_ai_opencv("./data/upload/test.jpg",this->_tools->get_uuid());
   }

   if(USE_STREAM_THREAD == 1){

        stream_obj *c_sobj  = nullptr;

        // 查询视频流列表
        Json::Value streams = db.query_user_streams(0);
        // 新建视频流 拉流线程 
        for(int i=0;i<streams.size();i++){
            Json::Value stream = streams[i];

            stream_obj *sobj = new stream_obj();
            sobj->stream_id = stream["id"].asInt();
            sobj->stream_url = stream["stream_url"].asString();
            sobj->need_play = true;
            sobj->play_token = this->_tools->get_uuid();
            sobj->last = c_sobj;
            if(c_sobj != nullptr) c_sobj->next = sobj;
            if(p_stream == nullptr) p_stream = sobj;
            c_sobj = sobj;

            // 新建视频流 拉流线程   
            this->thread_id = this->thread_id + 1 ;
            sobj->pull_thread_id = this->thread_id;
            video_pull vpull = video_pull(this->_tools, this->_config, this->_conn);
            vpull.set_video_config(sobj);
            std::thread vpull_conn(vpull,this->thread_id);
            vpull_conn.detach();
            sys_thread *n_thread = new sys_thread();
            current_thread->next = n_thread;
            n_thread->last = current_thread;
            n_thread->thread_id = this->thread_id;
            n_thread->thread_name = "视频流拉流线程,video_id:" + to_string(stream["id"].asInt());
            n_thread->object_type = "video_pull";
            n_thread->th_object = &vpull;
            n_thread->next = nullptr;
            current_thread = n_thread;

            // 新建视频流 AI识别线程 
            
            this->thread_id = this->thread_id;
            sobj->ai_thread_id = this->thread_id;
            video_ai vai = video_ai(this->_tools,this->_config,this->_conn);
            vai.set_video_config(sobj);
            string model_url = "./data/models/yolov8n.trt";
            vai.init_yolo_model(model_url,stream["video_height"].asInt(),stream["video_width"].asInt());
            std::thread vai_conn(vai,this->thread_id);
            vai_conn.detach();
            n_thread = new sys_thread();
            current_thread->next = n_thread;
            n_thread->last = current_thread;
            n_thread->thread_id = this->thread_id;
            n_thread->thread_name = "视频流AI线程,video_id:" + to_string(stream["id"].asInt());
            n_thread->object_type = "video_ai";
            n_thread->th_object = &vpull;
            n_thread->next = nullptr;
            current_thread = n_thread;

          

            // 新建视频流 消费线程   
            
            this->thread_id = this->thread_id + 1 ;
            sobj->push_thread_id = this->thread_id;
            video_push vpush = video_push(this->_tools, this->_config, this->_conn);
            vpush.set_video_config(sobj);
            std::thread vpush_conn(vpush,this->thread_id);
            vpush_conn.detach();
            n_thread = new sys_thread();
            current_thread->next = n_thread;
            n_thread->last = current_thread;
            n_thread->thread_id = this->thread_id;
            n_thread->thread_name = "视频流消费线程,video_id:" + to_string(stream["id"].asInt());
            n_thread->object_type = "video_push";
            n_thread->th_object = &vpush;
            n_thread->next = nullptr;
            current_thread = n_thread;
            
        }
    
   }
 
    while (true) {
        usleep(1000);
    }
    

}
