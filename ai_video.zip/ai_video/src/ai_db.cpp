#include "ai_db.h"

Json::Value ai_db::query_by_pagesize(string table,vector<string>fields,int pagenum,int pagesize)
{
    string limit_start; string limit_end;
    limit_start = to_string((pagenum - 1) * pagesize);
    limit_end = to_string(pagenum * pagesize);
    Json::Value data;
    data["total"] = this->_conn->quick_mysql_query(this->sobj->sql_count(table))[0]["COUNT(*)"].asInt();
    data["data"] =  this->_conn->quick_mysql_query(this->sobj->sql_select(table,fields) + " ORDER BY `id` DESC LIMIT " + limit_start + "," + limit_end);
    data["pagenum"] = pagenum;
    data["pagesize"] = pagesize;
    data["allpage"] = data["total"].asInt() == 0 ? 0 : (int)ceil( data["total"].asInt() / pagesize);
    return data;
}

ai_db::ai_db(conn *conn, config *config, tools *tools)
{
    this->_tools =  tools;
    this->_config = config;
    this->_conn = conn;
    this->sobj = new sql_obj(this->_tools,this->_conn);
}

http_content_type *ai_db::get_http_content_type_list()
{
   
    http_content_type *head = nullptr;
    http_content_type *node = nullptr;
    Json::Value result;
    string default_content_type;
    // 查询默认的content_type 
    this->sobj->sql_where("config_item","=","'sys.default_content_type'");
    result = this->_conn->quick_mysql_query(this->sobj->sql_select("sys_config",{"*"}));
    if(result.size()>0) default_content_type= result[0]["config_value"].asString();
    else default_content_type = "application/octet-stream";
    head = new http_content_type();
    head->ext = ".*"; head->content_type = default_content_type;
    try{result = this->_conn->quick_mysql_query(this->sobj->sql_select("sys_content_type",{"*"}));}
    catch(c_mysql_error err){
        this->_tools->g_console_log("[ERROR]执行SQL语句出现错误!\nSQL:" + err.sql+"\nERROER:" + err.msg);
        return nullptr;
    }
    for(int i=0;i<result.size();i++){
        http_content_type *ctype = new http_content_type();
        ctype->ext = result[i]["ext"].asString();
        ctype->content_type = result[i]["content_type"].asString();
        ctype->next = nullptr;
        if(node == nullptr) head->next = ctype;
        else node->next = ctype; 
        node = ctype;
    }
    return head;
}


oauth_user *ai_db::oauth_create_token(string client_ip,string user_agent, Json::Value user)
{


    // 更新最新的登录ip 地址 
   
    this->sobj->sql_where("username","=",this->sobj->sql_value(user["username"].asString()));
    Json::Value update; 
    update["update_time"] = this->_tools->get_timestamp();
    update["last_login_time"] = this->_tools->get_timestamp();
    update["last_login_ip"] = client_ip;
    this->_conn->quick_mysql_exec(this->sobj->sql_update("user_account",update));

    // 生成 access_token 和 refresh_token 
    string uid = user["uid"].asString();
    string _access_token = this->_tools->get_uuid();
    string access_token = "mingmou:access_token:" + uid + ":" + _access_token;
    string _refresh_token = this->_tools->get_uuid();
    string refresh_token = "mingmou:refresh_token:" + uid + ":" + _refresh_token;
    Json::Value oauth;
    oauth["access_token"] = _access_token; oauth["refresh_token"] = _refresh_token;
    oauth["uid"] =  user["uid"].asInt(); oauth["status"] = 0 ; oauth["create_time"] = this->_tools->get_timestamp();
    this->_conn->quick_mysql_exec(this->sobj->sql_insert("user_refresh_token",oauth));

                
    // 向 access_token 对应的 session 中添加 用户数据信息 
    string ckey = this->_config->get_string_value("REDIS_KEY","KEY_USER_SESSION","ai_video:session:user:") + _access_token;
    Json::Value session; 
    session["uid"]= user["uid"].asInt();
    session["puid"] = user["parent_uid"].asInt();
    session["username"] = user["username"].asString();
    session["nickname"] = user["nickname"].asString();
    session["level"] = user["level"].asInt();
    session["login_client_ip"] = client_ip;
    session["last_login_time"] =  update["last_login_time"];
    session["access_token"] = access_token;
    session["access_expire"] = this->_tools->get_timestamp() + HTTP_SESSION_EXPIRE;
    session["access_http_user_agent"] = user_agent;
    this->_conn->redis->set(ckey,this->_tools->json_encode(session),false);
    this->_conn->redis->expire(ckey,HTTP_SESSION_EXPIRE);

    oauth_user *ouser = new oauth_user();
    ouser->access_token = access_token;
    ouser->refresh_token = refresh_token;
    ouser->session = session;
    return ouser;
}

void *ai_db::oauth_super_access_token_login(string client_ip, string user_agent, Json::Value user)
{
    string _access_token = HTTP_SESSION_SUPER_TOKEN;
    string access_token = "mingmou:access_token:" + to_string(user["uid"].asInt()) + ":" + _access_token;
    string ckey = this->_config->get_string_value("REDIS_KEY","KEY_USER_SESSION","ai_video:session:user:") + _access_token;
    Json::Value session; 
    session["uid"]= user["uid"].asInt();
    session["puid"] = user["parent_uid"].asInt();
    session["username"] = user["username"].asString();
    session["nickname"] = user["nickname"].asString();
    session["level"] = user["level"].asInt();
    session["login_client_ip"] = client_ip;
    session["last_login_time"] = user["last_login_time"];
    session["access_token"] = access_token;
    session["access_expire"] = this->_tools->get_timestamp() + HTTP_SESSION_EXPIRE;
    session["access_http_user_agent"] = user_agent;
    this->_conn->redis->set(ckey,this->_tools->json_encode(session),false);
    this->_conn->redis->expire(ckey,HTTP_SESSION_EXPIRE);
}

int ai_db::create_face_person(int uid, string name, string idcard, string ecard, string telphone, string email, string org_part, string other_json, string extend)
{
    Json::Value person; 
    person["name"] = name;
    person["idcard"] = idcard;
    person["ecard"] = ecard;
    person["telphone"] = telphone;
    person["email"] = email;
    person["org_part"] = org_part;
    person["other_json"] = other_json;
    person["extend"] = extend;
    person["puid"] = uid;
    this->_conn->quick_mysql_exec(this->sobj->sql_insert("face_person",person));
    return this->_conn->quick_last_id();
}

int ai_db::create_face_feature(int person_id, int file_id, int orient, Json::Value position, string feature_hex, int feature_size)
{
    Json::Value record;
    record["person_id"] = person_id;
    record["file_id"] = file_id;
    record["orient"] = orient;
    record["position"] = this->_tools->json_encode(position);
    record["feature_hex"] = feature_hex;
    record["feature_size"] = feature_size;
    this->_conn->quick_mysql_exec(this->sobj->sql_insert("face_person_feature",record));
    //cout << "执行SQL 成功"  << endl;
    return this->_conn->quick_last_id();
}

Json::Value ai_db::query_user_account(string username)
{
   
    this->sobj->sql_where("username","=",this->sobj->sql_value(username));
    Json::Value result = this->_conn->quick_mysql_query(this->sobj->sql_select("user_account",{"*"}));
    return result;
}

Json::Value ai_db::query_user_account(int uid)
{
   
    this->sobj->sql_where("uid","=",this->sobj->sql_value(uid));
    Json::Value result = this->_conn->quick_mysql_query(this->sobj->sql_select("user_account",{"*"}));
    return result;
}

int ai_db::query_new_user_uid()
{
   
    Json::Value result = this->_conn->quick_mysql_query(this->sobj->sql_select("user_account",{"MAX(uid)"}));
    int new_uid = result[0]["MAX(uid)"].asInt()  + 1 ;
    if(new_uid == 1) new_uid = 10001;
    return new_uid;
}

int ai_db::query_user_parent_uid(int uid)
{
   
    this->sobj->sql_where("uid","=",this->sobj->sql_value(uid));
    Json::Value result = this->_conn->quick_mysql_query(this->sobj->sql_select("user_account",{"parent_uid"}));
    if(result.size()==0) return -1;
    else return result[0]["parent_uid"].asInt();
}

Json::Value ai_db::query_user_streams(int puid)
{
   
    if(puid >0)  this->sobj->sql_where("puid","=",this->sobj->sql_value(puid));
    Json::Value result = this->_conn->quick_mysql_query(this->sobj->sql_select("stream_list",{"*"}));
    return result;
}

Json::Value ai_db::query_file_need_delete(bool show_sql)
{
    int current_time = this->_tools->get_timestamp();
    string sql = "SELECT * FROM `sys_file` WHERE `delete_expire` < "+to_string(current_time) + " AND `delete_expire` <> -1";
    Json::Value result = this->_conn->quick_mysql_query(sql,false);
    return result;

}

Json::Value ai_db::query_user_childs(int puid,int uid,int pagenum,int pagesize)
{
    
    if(puid > 0) {
        this->sobj->sql_where("parent_uid","=",this->sobj->sql_value(puid));
        this->sobj->sql_where("uid","<>",this->sobj->sql_value(uid));
    } 
    vector<string> fields = {"uid","parent_uid as puid","username","nickname","level","status","extend","ban_msg","last_login_ip","create_time","last_login_time"};
    Json::Value result =  this->query_by_pagesize("user_account",fields,pagenum,pagesize);
    return result;
}

Json::Value ai_db::query_oauthToken_refresh_token(string refresh_token)
{
   
    this->sobj->sql_where("refresh_token","=",this->sobj->sql_value(refresh_token));
    Json::Value result = this->_conn->quick_mysql_query(this->sobj->sql_select("user_refresh_token",{"*"}));
    return result;
}

Json::Value ai_db::query_file_bypath(string filepath)
{
   
    this->sobj->sql_where("filepath","=",this->sobj->sql_value(filepath));
    Json::Value result = this->_conn->quick_mysql_query(this->sobj->sql_select("sys_file",{"*"}));
    return result;
}

// 查询 login_uid ， 等级 为level 时 是否有操作 _uid 的权限 
int ai_db::check_user_child_auth(int login_uid, int level, string _uid)
{
    int uid;
    // 子用户不能有子用户的权限
    if(level == 0) return -1;
    else{
        if(_uid !="") uid = atoi(_uid.c_str()); else uid = login_uid;
        if(uid != login_uid){
            int puid = this->query_user_parent_uid(uid);
             // 当前用户不是管理员
            if(level != 2){
                // 访问非当前用户的子用户 
                if(puid != login_uid ) return -2;
            }
            // uid 不存在
            if(puid < 0) return -3;
        }
        return uid;
    }
}

void ai_db::update_oauthToken_refresh_token(string refresh_token, int status)
{
   
    this->sobj->sql_where("refresh_token","=",this->sobj->sql_value(refresh_token));
    Json::Value update; update["status"] = 1;
    this->_conn->quick_mysql_exec(this->sobj->sql_update("user_refresh_token",update));
}

Json::Value ai_db::update_user_info(int uid,Json::Value update)
{
    Json::Value info;
    vector<string> allow_fields = {"nickname","level","status","extend","ban_msg"};
    vector<string> update_keys = update.getMemberNames();
    for(int i=0;i<update_keys.size();i++){
        string key = update_keys[i];
        if(this->_tools->in_list(allow_fields,key)) info[key] = update[key];
    }
   
    this->sobj->sql_where("uid","=",this->sobj->sql_value(uid));
    this->_conn->quick_mysql_exec(this->sobj->sql_update("user_account",info));
    return info;
}

void ai_db::update_sys_config(int config_id, string value, string extend)
{
    Json::Value update;
    this->sobj->sql_where("id","=",this->sobj->sql_value(config_id));
    update["config_value"] = value; update["extend"] = extend;
    this->_conn->quick_mysql_exec(this->sobj->sql_update("sys_config",update));
}

void ai_db::update_file_expire(int fid, string file_path, int delete_time)
{
    Json::Value update;
    this->sobj->sql_where("id","=",this->sobj->sql_value(fid));
    update["delete_expire"]  = delete_time < 0  ? delete_time : this->_tools->get_timestamp() + delete_time ;
    update["filepath"] = file_path;
    this->_conn->quick_mysql_exec(this->sobj->sql_update("sys_file",update));
}

void ai_db::update_file_token(string file_token, string file_path, int delete_time)
{
    // 判断是否存在token 会话
    string config_key = this->_config->get_string_value("REDIS_KEY","KEY_FILE_DOWNLOAD","ai_video:file:download:");
    if(this->_conn->redis->exists(config_key)){
        Json::Value file = this->_tools->json_decode(*this->_conn->redis->get(config_key));
        file["filepath"] = file_path; file["delete_expire"] = delete_time;
        this->_conn->redis->set(config_key,this->_tools->json_encode(file),false);
    }
}

// 修改用户的密码
void ai_db::update_user_password(int uid, string password)
{
   
    this->sobj->sql_where("uid","=",this->sobj->sql_value(uid));
    string new_user_salt = this->_tools->get_uuid();
    string new_encrypt_password =  this->_tools->str_hash_sha256( password + ":" +  new_user_salt) ;
    Json::Value update; update["password"] = new_encrypt_password; update["salt"] = new_user_salt;
    this->_conn->quick_mysql_exec(this->sobj->sql_update("user_account",update));
}

int ai_db::create_file_record(string filename, string filepath, string ext, int uid, int delete_time, bool is_tmp)
{
    Json::Value record;
    record["filename"] = filename; record["filepath"] = filepath; record["filesize"] = (int)this->_tools->get_file_size(filepath);
    record["ext"] = ext; record["uid"] = uid; record["delete_expire"] = delete_time < 0  ? delete_time : this->_tools->get_timestamp() + delete_time ;
    record["is_tmp"] = is_tmp; 
   
    this->_conn->quick_mysql_exec(this->sobj->sql_insert("sys_file",record));
    return this->_conn->quick_last_id();
}

int ai_db::create_sys_config(string item, string value, string extend, string table, int id)
{
    Json::Value create;
    create["config_item"] = item; create["config_value"] = value ; create["extend"] = extend;
    create["link_table"] = table; 
    if(id > 0) create["link_id"] = id;
    this->_conn->quick_mysql_exec(this->sobj->sql_insert("sys_config",create));
    return this->_conn->quick_last_id();
}


Json::Value ai_db::query_file_byid(int file_id)
{
   
    string sql =  "SELECT * FROM `sys_file` WHERE `id` = " +  this->sobj->sql_value(file_id) + 
                  " AND (`delete_expire` = " + this->sobj->sql_value(-1)  +
                  " OR `delete_expire` > " + this->sobj->sql_value(this->_tools->get_timestamp()) + 
                  " )";
    return this->_conn->quick_mysql_query(sql);
}

Json::Value ai_db::query_video_by_stream_id(int stream_id)
{
  
   this->sobj->sql_where("id","=",this->sobj->sql_value(stream_id));
   return this->_conn->quick_mysql_query(this->sobj->sql_select("stream_list",{"video_width","video_height","video_fps"}));
}

Json::Value ai_db::query_sys_config(string keyword,string link_table,int link_id, int pagenum, int pagesize)
{
    this->sobj->sql_where("config_item","like", this->sobj->sql_like_value(keyword));
    if(link_table != "")  this->sobj->sql_where("link_table","=", this->sobj->sql_value(link_table));
    if(link_id > 0)  this->sobj->sql_where("link_id","=", this->sobj->sql_value(link_id));
    return query_by_pagesize("sys_config",{"*"},pagenum,pagesize);
}

Json::Value ai_db::query_sys_config_by_config_id(int config_id)
{
    this->sobj->sql_where("id","=",this->sobj->sql_value(config_id));
    return this->_conn->quick_mysql_query(this->sobj->sql_select("sys_config",{"*"}));
}

Json::Value ai_db::query_person_by_person_id(int person_id)
{
    this->sobj->sql_where("id","=",this->sobj->sql_value(person_id));
    return this->_conn->quick_mysql_query(this->sobj->sql_select("face_person",{"*"}));
}

Json::Value ai_db::query_person_by_feature_id(int feature_id)
{
    string sql = "SELECT `face_person`.id as person_id,`face_person`.name,`face_person`.idcard,`face_person`.ecard,`face_person`.telphone,`face_person`.email,`face_person`.org_part,`face_person`.other_json FROM `face_person` JOIN `face_person_feature` ON `face_person`.id = `face_person_feature`.person_id WHERE `face_person_feature`.id = "  
        + this->sobj->sql_value(feature_id);
    return this->_conn->quick_mysql_query(sql);
}

Json::Value ai_db::query_person_feature_by_person_id(int person_id)
{
    this->sobj->sql_where("person_id","=",this->sobj->sql_value(person_id));
    return this->_conn->quick_mysql_query(this->sobj->sql_select("face_person_feature",{"*"}));
}

Json::Value ai_db::query_person_all_feature()
{
    return this->_conn->quick_mysql_query(this->sobj->sql_select("face_person_feature",{"*"}));
}

Json::Value ai_db::query_person_feature_by_feature_id(int feature_id)
{
    this->sobj->sql_where("id","=",this->sobj->sql_value(feature_id));
    return this->_conn->quick_mysql_query(this->sobj->sql_select("face_person_feature",{"*"}));
}

bool ai_db::exist_sys_config(string item,string table)
{
    this->sobj->sql_where("config_item","=", this->sobj->sql_value(item));
    this->sobj->sql_where("link_table","=", this->sobj->sql_value(item));
    Json::Value data =  this->_conn->quick_mysql_query(this->sobj->sql_select("sys_config",{"COUNT(*)"}));
    if(data[0]["COUNT(*)"].asInt() == 0) return false;
    else return true;
}

void ai_db::delete_file_byid(int file_id)
{
    this->sobj->sql_where("id","=",this->sobj->sql_value(file_id));
    this->_conn->quick_mysql_exec(this->sobj->sql_delete("sys_file"));
}

void ai_db::delete_sys_config(int config_id)
{
    this->sobj->sql_where("id","=",this->sobj->sql_value(config_id));
    this->_conn->quick_mysql_exec(this->sobj->sql_delete("sys_config"));
}

void ai_db::delete_sys_config(string table, int link_id)
{
    this->sobj->sql_where("link_id","=",this->sobj->sql_value(link_id));
    this->sobj->sql_where("link_table","=",this->sobj->sql_value(table));
    this->_conn->quick_mysql_exec(this->sobj->sql_delete("sys_config"));
}

string ai_db::create_file_token(int file_id, string client_ip, string user_agent,int expire)
{
   Json::Value file = this->query_file_byid(file_id);
   if(file.size()!=0){
     file = file[0];
     file["client_ip"] = client_ip; file["user_agent"] = user_agent;
     string token = this->_tools->get_uuid();
     string cache_key = this->_config->get_string_value("REDIS_KEY","KEY_FILE_DOWNLOAD","ai_video:file:download:") + token;
     this->_conn->redis->set(cache_key, this->_tools->json_encode(file),false);
     if(expire !=0) this->_conn->redis->expire(cache_key,expire);
     else if(expire!= -1) this->_conn->redis->expire(cache_key,HTTP_FILEDOWNLOAD_EXPIRE);
     return token;
   }
   else return "";
}

int ai_db::create_video_stream(Json::Value stream, int puid,string name,string extend)
{
   
    this->sobj->sql_where("stream_url","=",this->sobj->sql_value(stream["stream_url"].asString()));
    this->sobj->sql_where("puid","=",this->sobj->sql_value(puid));
    Json::Value result =  this->_conn->quick_mysql_query(this->sobj->sql_select("stream_list",{"COUNT(*)"}));
    if(result[0]["COUNT(*)"].asInt() > 0) return -1;
    else{
        Json::Value create; 
        create["puid"] = puid;
        create["stream_url"] = stream["stream_url"].asString();
        if(stream["comment"].isString()) create["stream_comment"] = stream["comment"];
        if(stream["title"].isString()) create["stream_title"] = stream["title"];
        if(stream["videos"].size() > 0){
            Json::Value video = stream["videos"][0];
            create["video_code_name"] = video["code_name"];
            create["video_width"] = video["width"];
            create["video_height"] = video["height"];
            create["video_fps"] = video["fps"];
            create["video_stream_index"] = video["stream_id"];
        }
        if(stream["audios"].size() > 0){
            Json::Value audio = stream["audios"][0];
            create["audio_code_name"] = audio["code_name"];
            create["audio_stream_index"] = audio["stream_id"];
            create["audio_sample_rate"] = audio["sample_rate"];
            create["audio_channels"] = audio["channels"];
        }
        create["name"] = name;
        create["extend"] = extend;
        this->_conn->quick_mysql_exec(this->sobj->sql_insert("stream_list",create));
        return this->_conn->quick_last_id();
    }
}
