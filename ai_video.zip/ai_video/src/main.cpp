
#include "yolo/utils/yolo.h"
#include "yolo/yolov8.h"

#include <iostream>
#include "ai_video.h"
#include <signal.h>
#include "extend/tools.h"



using namespace cv;
using namespace std;


int main(int argc,char *argv[])
{
	tools *t = new tools();
	
	vector <vector<string>>  folder_list = {
		{"data","数据"},
		{"data/captcha","视频预览截图"},
		{"data/models","AI模型"},
		{"data/result","AI截图"},
		{"data/result/face_position/","AI人脸位置图"},
		{"data/result/face_feature/","AI人脸特征图"},
		{"data/upload","文件上传"},
		{"data/upload/people_face/","上传的人脸基准图"},
	};
	if(!t->exist_file(DIR_TMP_PATH)) t->create_folder(DIR_TMP_PATH);
	string root_path = t->get_root_path() + "/";
	for(int i=0; i < int(folder_list.size());i++){
		string path = folder_list[i][0];
		string name = folder_list[i][1];
		if(!t->exist_file(root_path + path)){
			t->console_log("新建 " + name + " 文件夹[" + root_path + path + "]");
			t->create_folder(root_path + path);
		}
	}
	ai_video *ai = new ai_video();
	ai->show_app_welcome();
	if (ai->load_config()) ai->run_server();
	
}