
#pragma once

#include <thread>
#include "string.h"

#include "thread_struct.h"
#include "../extend/tools.h"
#include "../extend/config.h"
#include "../extend/conn.h"


#include "../ai_db.h"

class video_push
{
	private:
		tools* _tools;
		config* _config;
		conn* _conn;
        stream_obj *_sobj;
		bool play_status;
		ai_db *db;

		SwsContext *vsc = NULL;
    	AVFrame *yuv = NULL;
    	AVCodecContext *vc = NULL;
    	AVFormatContext *ic = NULL;
		AVStream *vs = NULL;
		const AVOutputFormat *ofmt = NULL;
		const AVCodec *codec  = NULL;
		int vpts;
		AVPacket pack;

	public:
		int thread_id;
		video_push(tools* tools, config* config, conn* conn);
        void set_video_config(stream_obj *sobj);
		void operator()(int _thread_id);
		void console_log(string log);
		void on_start_video_play();
		void on_stop_video_play();
		void on_ffmpeg_send_frame(cv::Mat color_image);
	

};
