
#pragma once

#include <thread>
#include "string.h"

#include "thread_struct.h"
#include "../extend/tools.h"
#include "../extend/config.h"
#include "../extend/conn.h"


#include "../ai_db.h"

class video_pull
{
	private:
		tools* _tools;
		config* _config;
		conn* _conn;
        stream_obj *_sobj;

        // 媒体流处理
        AVFormatContext* pFormatCtx = NULL;
	    AVDictionary* options = NULL;
	    AVPacket* av_packet;
	    AVFrame* pAvFrame ;
	    AVCodecContext* pCodecCtx;
	    const AVCodec* pCodec;
        string stream_url;

        int videoindex = -1;
        int audioindex = -1; 
		void ffmpeg_stream_init();
        bool ffmpeg_open_stream();
        bool ffmpeg_load_stream_info();
        bool ffmpeg_open_codec();
        void ffmpeg_pull_frame();

	public:
		int thread_id;
		video_pull(tools* tools, config* config, conn* conn);
        void set_video_config(stream_obj *sobj);
		void operator()(int _thread_id);
		void console_log(string log);

};
