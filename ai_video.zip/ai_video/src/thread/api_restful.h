#pragma once

#include <thread>
#include "string.h"

#include "../extend/tools.h"
#include "../extend/config.h"
#include "../extend/conn.h"

#include "../arest/arest.h"

#include "../api/load.h"
#include "../ai_db.h"
#include <functional>

class api_restful
{
	private:
		tools* _tools;
		config* _config;
		conn* _conn;
		void* _th_pools;
		arest* server;
	public:
		int thread_id;
		api_restful(tools* tools, config* config, conn* conn,void* th_pools);
		void operator()(int _thread_id);
		void start_arest_server();
		void console_log(string log);
		

};


