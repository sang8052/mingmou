#include "api_restful.h"

// 进程构造函数
void api_restful::operator()(int thread_id)
{
	this->thread_id = thread_id;
	this->console_log("[LOG]启动API RestFul线程,thread_id:" + to_string(this->thread_id) );
	start_arest_server();
}



void api_restful::console_log(string log)
{
	this->_tools->console_log(log, this->thread_id);
}


api_restful::api_restful(tools* tools, config* config, conn* conn,void* th_pools)
{	
	this->_tools = tools;
	this->_config = config;
	this->_conn = conn;
	this->_th_pools = th_pools;
}


void api_restful::start_arest_server()
{
	ai_db *db = new ai_db(this->_conn,this->_config,this->_tools);
	arest* server = new arest(this->_th_pools,this->thread_id,"conf.ini",db->get_http_content_type_list());


	// 注册hook 事件
	server->http_hook_register("http_before_route_handle",&api_http_handle::on_hook_before_handle);
	server->http_hook_register("http_after_route_handle",&api_http_handle::on_hook_after_handle);
	
	// 注册系统路由

	// 文件控制
    server->http_route_register("/api/file/download/{token}","GET","on_http_file_download",&api_file::on_http_file_download);
	server->http_route_register("/api/file/upload","POST","on_http_file_upload",&api_file::on_http_file_upload);
	server->http_route_register("/api/file/upload/download","POST","on_http_file_upload_download",&api_file::on_http_file_upload_download);
	server->http_route_register("/api/file/token","POST","on_http_file_token",&api_file::on_http_file_token);

	
	// 用户鉴权接口
	server->http_route_register("/api/auth/login","POST","on_http_auth_login",&api_auth::on_http_auth_login);
	server->http_route_register("/api/auth/oauth","POST","on_http_auth_refresh_token",&api_auth::on_http_auth_refresh_token);
	server->http_route_register("/api/auth/ping","GET","on_http_auth_ping",&api_auth::on_http_auth_ping);

	// 用户信息管理
	server->http_route_register("/api/user/info","GET","on_http_user_info",&api_user::on_http_user_info);
	server->http_route_register("/api/user/{uid:\\d+}/info","GET","on_http_user_info",&api_user::on_http_user_info);
	server->http_route_register("/api/user/password","POST","on_http_user_update_password",&api_user::on_http_user_update_password);
	server->http_route_register("/api/user/{uid:\\d+}/password","POST","on_http_user_update_password",&api_user::on_http_user_update_password);
	server->http_route_register("/api/user/{uid:\\d+}/info","POST","on_http_user_update_info",&api_user::on_http_user_update_info);
	server->http_route_register("/api/user/child","GET","on_http_user_query_child",&api_user::on_http_user_query_child);
	server->http_route_register("/api/user/{uid:\\d+}/child","GET","on_http_user_query_child",&api_user::on_http_user_query_child);
	server->http_route_register("/api/user","POST","on_http_user_create",&api_user::on_http_user_create);

	
	// 视频拉流管理 
	server->http_route_register("/api/video/stream/captcha","POST","on_http_stream_captcha",&api_video::on_http_stream_captcha);
	server->http_route_register("/api/video/stream","POST","on_http_stream_add",&api_video::on_http_stream_add);

	
	// 系统配置项管理
	server->http_route_register("/api/sys_config","GET","on_http_query_sys_config",&api_sys_config::on_http_query_sys_config);
	server->http_route_register("/api/sys_config","POST","on_http_create_sys_config",&api_sys_config::on_http_create_sys_config);
	server->http_route_register("/api/sys_config/{config_id:\\d+}","GET","on_http_detail_sys_config",&api_sys_config::on_http_detail_sys_config);
	server->http_route_register("/api/sys_config/{config_id:\\d+}","POST","on_http_update_sys_config",&api_sys_config::on_http_update_sys_config);
	server->http_route_register("/api/sys_config/{config_id:\\d+}","DELETE","on_http_delete_sys_config",&api_sys_config::on_http_delete_sys_config);



	// 人脸信息管理
	server->http_route_register("/api/face/detail/{token}","GET","on_http_face_detail",&api_face::on_http_face_detail);
	server->http_route_register("/api/face/feature/{token}","GET","on_http_face_feature",&api_face::on_http_face_feature);
	server->http_route_register("/api/face/position/{token}","GET","on_http_face_position",&api_face::on_http_face_position);
	server->http_route_register("/api/face/find/{token}","GET","on_http_db_face_find",&api_face::on_http_db_face_find);


	// 人员管理
	server->http_route_register("/api/face/person","POST","on_http_db_person_add",&api_face::on_http_db_person_add);
	server->http_route_register("/api/face/person/feature","POST","on_http_db_face_feature_add",&api_face::on_http_db_face_feature_add);
	server->http_route_register("/api/face/person/{person_id:\\d+}","GET","on_http_db_person_detail",&api_face::on_http_db_person_detail);
	server->http_route_register("/api/face/person/{person_id:\\d+}","DELETE","on_http_db_person_delete",&api_face::on_http_db_person_delete);
	server->http_route_register("/api/face/person/{person_id:\\d+}","POST","on_http_db_person_update",&api_face::on_http_db_person_update);
	server->http_route_register("/api/face/person/feature/{feature_id:\\d}","DELETE","on_http_db_person_feature_detele",&api_face::on_http_db_person_feature_detele);


	server->start_server();





}
