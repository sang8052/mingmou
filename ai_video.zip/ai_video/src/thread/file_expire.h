
#pragma once

#include <thread>
#include "string.h"

#include "../extend/tools.h"
#include "../extend/config.h"
#include "../extend/conn.h"


#include "../ai_db.h"

class file_expire
{
	private:
		tools* _tools;
		config* _config;
		conn* _conn;
	public:
		int thread_id;
		file_expire(tools* tools, config* config, conn* conn);
		
		void operator()(int _thread_id);
		void console_log(string log);
		

};
