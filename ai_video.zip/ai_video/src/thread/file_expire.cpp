#include "file_expire.h"

file_expire::file_expire(tools *tools, config *config, conn *conn)
{
    this->_tools = tools;
	this->_config = config;
	this->_conn = conn;
}

void file_expire::operator()(int _thread_id)
{
    this->thread_id = _thread_id;
	this->console_log("[LOG]启动File Expire线程,thread_id:" + to_string(this->thread_id));
    ai_db *db = new ai_db(this->_conn,this->_config,this->_tools);

    while (true)
    {
        // 查询出所有需要删除的文件
        Json::Value delete_files = db->query_file_need_delete(true);
        for(int i=0;i<delete_files.size();i++){
            Json::Value file = delete_files[i];
            int expire_time = this->_tools->get_timestamp() -  file["delete_expire"].asInt();
            if(expire_time > 0){
                this->console_log("[LOG]文件[file_id:" + to_string(file["id"].asInt()) + ",file_name:" + file["filename"].asString() 
                    + "]过期" + to_string(expire_time) + "秒被自动删除");
            }
            else{
                this->console_log("[LOG]文件[file_id:" + to_string(file["id"].asInt()) + ",file_name:" + file["filename"].asString() 
                    + "]删除失败尝试重新删除");
            }
            bool status;
            //this->console_log("[LOG]需要被删除的文件地址:" + file["filepath"].asString());
            if(this->_tools->exist_file(file["filepath"].asString())){
                   status =  this->_tools->remove_file(file["filepath"].asString());
            }
            else status = true; 
           
            if(status) {
                this->console_log("[INFO]文件[file_id:" + to_string(file["id"].asInt()) + ",file_name:" + file["filename"].asString() + "]删除成功");
                db->delete_file_byid(file["id"].asInt());
            }
            else  this->console_log("[WARNING]文件[file_id:" + to_string(file["id"].asInt()) + ",file_name:" + file["filename"].asString() + "]删除失败");
        }
        sleep(3);
    }
}

void file_expire::console_log(string log)
{
	this->_tools->console_log(log, this->thread_id);
}
