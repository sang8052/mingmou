#include "video_pull.h"

video_pull::video_pull(tools *tools, config *config, conn *conn)
{
    this->_tools = tools;
	this->_config = config;
	this->_conn = conn;
}



void video_pull::set_video_config(stream_obj *sobj)
{
    this->_sobj = sobj;
}



void video_pull::operator()(int _thread_id)
{
    this->thread_id = _thread_id;
	this->console_log("[LOG]启动Video Pull线程,thread_id:" + to_string(this->_sobj->pull_thread_id));
    this->stream_url =  this->_sobj->stream_url;
    this->console_log("[LOG]RTSP原始视频流地址:" + this->stream_url);
     
    this->ffmpeg_stream_init();
    while (true)
    {
        // 打开媒体流成功
        if(this->ffmpeg_open_stream()){
            // 加载媒体流中的视频流
            if(this->ffmpeg_load_stream_info()){
                // 打开编码器
                if(this->ffmpeg_open_codec())
                this->ffmpeg_pull_frame();
            }
        }
        avformat_close_input(&this->pFormatCtx);
    }
    
}

void video_pull::console_log(string log)
{
    this->_tools->console_log(log, this->thread_id);
}

void video_pull::ffmpeg_stream_init()
{
    this->av_packet = (AVPacket*)av_malloc(sizeof(AVPacket));
	this->pAvFrame = av_frame_alloc();
	this->pCodecCtx = avcodec_alloc_context3(NULL);

    av_log_set_level(AV_LOG_ERROR);
	av_dict_set(&this->options, "buffer_size", "4096000", 0); 
	av_dict_set(&this->options, "rtsp_transport", "tcp", 0);  
	av_dict_set(&this->options, "stimeout", "3000000", 0);    
	av_dict_set(&this->options, "max_delay", "500000", 0);    
	this->pFormatCtx = avformat_alloc_context();

}

bool video_pull::ffmpeg_open_codec()
{
    avcodec_parameters_to_context(this->pCodecCtx, this->pFormatCtx->streams[this->videoindex]->codecpar);
	this->pCodec = avcodec_find_decoder(this->pCodecCtx->codec_id);
    if (this->pCodec == NULL){
        this->console_log("[ERROR]拉流失败,没有找到对应视频流[" + to_string(this->videoindex) + ",code_id:" + to_string(this->pCodecCtx->codec_id) + "]的编码器"); 
        return false;
    }
    else
    {
        if (avcodec_open2(this->pCodecCtx, pCodec, NULL) < 0) 
		{
            this->console_log("[ERROR]打开编码器code_id:" + to_string(this->pCodecCtx->codec_id) + "]失败");
            return false;
        }
        else return true;
    }
}


bool video_pull::ffmpeg_open_stream()
{
     if (avformat_open_input(&this->pFormatCtx, this->stream_url.c_str(), NULL, &this->options) != 0){
		this->console_log("[ERROR]打开输入的媒体流失败,请检查地址[" + this->stream_url + "]是否有误");
        return false;
     }
    else{
        this->console_log("[LOG]媒体流[" + this->stream_url + "]打开成功");
        return true;
    }
}

bool video_pull::ffmpeg_load_stream_info()
{
    if (avformat_find_stream_info(this->pFormatCtx, NULL) < 0)  {
        avformat_close_input(&this->pFormatCtx);
        this->console_log("[WANRING]在媒体流中没有找到有效的视频/音频流");
    }
    else
    {
        this->console_log("[INFO]输入流信息如下");
	    AVDictionaryEntry* tag = NULL;
	    while ((tag = av_dict_get(pFormatCtx->metadata, "", tag, AV_DICT_IGNORE_SUFFIX)))
	    {
		    string key = tag->key;
		    string value = tag->value;
		    this->console_log("[LOG]" + key + ":" + value);
	    }
                
	    int i = 0;
        for (i = 0; i < this->pFormatCtx->nb_streams; i++)
	    {
		    if (this->pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_AUDIO && this->audioindex == -1) {
			    this->audioindex = i;
			    this->console_log("[INFO]在轨道[" + to_string(i) + "]中发现音频流");
			    this->console_log("[LOG]编码器名称:" + (string)avcodec_get_name(this->pFormatCtx->streams[i]->codecpar->codec_id));
                this->console_log("[LOG]采用率:" + to_string(this->pFormatCtx->streams[i]->codecpar->sample_rate));
                this->console_log("[LOG]通道数:" + to_string(this->pFormatCtx->streams[i]->codecpar->ch_layout.nb_channels));
		    }

		    if (this->pFormatCtx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO && this->videoindex == -1)
		    {
			    this->videoindex = i;
			    this->console_log("[INFO]在轨道[" + to_string(i) + "]中发现视频流");
			    this->console_log("[LOG]编码器名称:" + (string)avcodec_get_name(this->pFormatCtx->streams[i]->codecpar->codec_id));
			    this->console_log("[LOG]视频宽度:" + to_string(this->pFormatCtx->streams[i]->codecpar->width));
			    this->console_log("[LOG]视频高度:" + to_string(this->pFormatCtx->streams[i]->codecpar->height));
			    this->console_log("[LOG]视频FPS:"  + to_string(this->_tools->RationaltoDouble(this->pFormatCtx->streams[i]->avg_frame_rate)));
		    }
	    }
        if (audioindex == -1)  this->console_log("[WARNING]在指定的流中没有找到音频流数据");
	    if (videoindex == -1)  {this->console_log("[ERROR]在指定的流中没有找到视频流数据"); return false;}
        return true;
    }
}

void video_pull::ffmpeg_pull_frame()
{
    int frame_id = 0;int ret;int got_picture;
    frame_obj *c_fobj = nullptr;

    while (true)
    {
        if (av_read_frame(this->pFormatCtx, this->av_packet) >= 0)
		{
            if (this->av_packet->stream_index == this->videoindex)
            {
              
                
                if (avcodec_send_packet(this->pCodecCtx, this->av_packet) != 0 || ( got_picture = avcodec_receive_frame(this->pCodecCtx, this->pAvFrame)) != 0)
					this->console_log("[WARNING]解码数据帧时出现了意外...");
                else{
                        cv::Mat frame = this->_tools->avFrame2Mat(this->pAvFrame);
                        // 防止空帧被投递 到其它线程导致错误
                        if(!frame.empty()){
                            frame_id = frame_id + 1 ;
                            frame_obj *fobj = new frame_obj();
                            fobj->create_time = this->_tools->get_ms_timestamp();
                            fobj->frame_id = frame_id;
                            fobj->cv_frame =  frame;
                            // 绘制缓存的AI 结果
                            if(this->_sobj->is_ai_result_cache) {
                                this->_tools->draw_yolo_result(fobj->cv_frame ,this->_sobj->ai_result_cache);
                            }
                        
                            fobj->need_handle = frame_id % 5 == 0 ? true : false;
                           // if(fobj->need_handle) this->console_log("[LOG]投递第[" + to_string(frame_id) + "]帧给AI处理");
                            //fobj->need_handle = false;
                            // 投递视频帧到其他线程中去
                            if(c_fobj != nullptr) { c_fobj->next = fobj;}
                            if(this->_sobj->frames == nullptr) this->_sobj->frames = fobj;
                            c_fobj = fobj;
                        }
                        
                }
                
            }
            if (this->av_packet != NULL)  av_packet_unref(this->av_packet);	
        }
    }
}
