/*
 * @Author: SudemQaQ
 * @Date: 2024-01-17 21:20:06
 * @email: mail@szhcloud.cn
 * @Blog: https://blog.szhcloud.cn
 * @github: https://github.com/sang8052
 * @LastEditors: SudemQaQ
 * @LastEditTime: 2024-01-17 23:41:25
 * @Description: 
 */
#pragma once


#include "../yolo/utils/yolo.h"
#include "../yolo/yolov8.h"

#include <thread>
#include "string.h"

#include "thread_struct.h"
#include "../extend/tools.h"
#include "../extend/config.h"
#include "../extend/conn.h"


#include "../ai_db.h"


class video_ai
{
    private:
        tools* _tools;
		config* _config;
		conn* _conn;
		stream_obj *_sobj;

        yoloUtils::InitParameter param;
		//cv::VideoCapture capture;
		YOLOV8 *yolo;
		void cuda_yolo_save_img(std::vector<cv::Mat>& imgsBatch,string img_uuid);
		vector<yolo_result> cuda_yolo_result(cv::Mat frame);
		vector<yolo_result> create_yolo_result(vector<yoloUtils::Box> box);
    public:
		int thread_id;
		video_ai(tools* tools, config* config, conn* conn);
		void set_video_config(stream_obj *sobj);
		void set_default_param(yoloUtils::InitParameter& initParameters);
		bool init_yolo_model(string model_path,int height,int width);
		// 线程开始处理的函数
		void operator()(int _thread_id);

		// 测试用 实验的函数
		void test_ai_opencv(string input_img,string img_uuid);
		
		void console_log(string log);
		
};