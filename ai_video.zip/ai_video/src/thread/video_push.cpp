#include "video_push.h"

video_push::video_push(tools *tools, config *config, conn *conn)
{
    this->_tools = tools;
	this->_config = config;
	this->_conn = conn;
}

void video_push::set_video_config(stream_obj *sobj)
{
    this->_sobj = sobj;
    this->play_status = false;
    this->db = new ai_db(this->_conn,this->_config,this->_tools);
}

void video_push::operator()(int _thread_id)
{    
    this->thread_id = _thread_id;
	this->console_log("[LOG]启动Video Push线程,thread_id:" + to_string( this->thread_id ));
    while(true){
        if(this->_sobj->frames!=nullptr)
        {
            // 始终保留 当前的frames 链表中 至少存在两个节点
            if(this->_sobj->frames->next!= nullptr){
              
                if(this->_sobj->need_play != this->play_status){
                    if(!this->_sobj->need_play) this->on_stop_video_play();
                    else this->on_start_video_play();
                }
                frame_obj *tmp_frame = this->_sobj->frames;

                cv::line(tmp_frame->cv_frame,cv::Point(842,420),cv::Point(1238,747),cv::Scalar(0,255,0),2.5);
                cv::line(tmp_frame->cv_frame,cv::Point(1238,747),cv::Point(1723,675),cv::Scalar(0,255,0),2.5);
                cv::line(tmp_frame->cv_frame,cv::Point(1723,675),cv::Point(1222,385),cv::Scalar(0,255,0),2.5);
                cv::line(tmp_frame->cv_frame,cv::Point(1222,385),cv::Point(842,420),cv::Scalar(0,255,0),2.5);

                // 微秒等待
                while(tmp_frame->need_handle && tmp_frame->handle_time == -1){ usleep(1000);}
            
                if(this->play_status) {
                   this->on_ffmpeg_send_frame(tmp_frame->cv_frame);
                } 
                this->_sobj->frames = this->_sobj->frames->next;
                // 释放当前 结构体
                tmp_frame->cv_frame.release();
                tmp_frame->next = nullptr;
                delete tmp_frame; 
            
            }
        }
    }
}

void video_push::console_log(string log)
{
    this->_tools->console_log(log, this->thread_id);

}

void video_push::on_start_video_play()
{
    this->play_status = true;
    string rtspUrl = "rtsp://127.0.0.1/ai_video/" + this->_sobj->play_token;
    Json::Value VideoStream = this->db->query_video_by_stream_id(this->_sobj->stream_id)[0];
  
    int inWidth     = VideoStream["video_width"].asInt();
    int inHeight    = VideoStream["video_height"].asInt();
    int fps         = VideoStream["video_fps"].asInt();
    int ret ;

    this->vsc = sws_getCachedContext(this->vsc,inWidth, inHeight, AV_PIX_FMT_BGR24, inWidth, inHeight, AV_PIX_FMT_YUV420P, SWS_BICUBIC,   0, 0, 0 );

    this->yuv = av_frame_alloc();
    this->yuv->format = AV_PIX_FMT_YUV420P;
    this->yuv->width = inWidth;
    this->yuv->height = inHeight;
    this->yuv->pts = 0;
    ret = av_frame_get_buffer(this->yuv, 32);
    this->codec = avcodec_find_encoder(AV_CODEC_ID_H264);
    this->vc = avcodec_alloc_context3(codec);
    this->vc->flags |= AV_CODEC_FLAG_GLOBAL_HEADER; 
    this->vc->codec_id = codec->id;
    this->vc->thread_count = 8;
    this->vc->bit_rate = 50 * 1024 * 8;
    this->vc->width = inWidth;
    this->vc->height = inHeight;
    this->vc->time_base = { 1,fps };
    this->vc->framerate = { fps,1 };
    this->vc->gop_size = 50;
    this->vc->max_b_frames = 0;
    this->vc->pix_fmt = AV_PIX_FMT_YUV420P; 
    ret = avcodec_open2(this->vc, this->codec, 0);
    ret = avformat_alloc_output_context2(&this->ic, NULL, "rtsp", rtspUrl.c_str());
    this->ofmt = this->ic->oformat;
    this->vs = avformat_new_stream(ic, codec);
    ret = avcodec_parameters_from_context(this->vs->codecpar, this->vc);
    av_dump_format(ic, 0, rtspUrl.c_str(), 1);
    if (!(this->ofmt->flags & AVFMT_NOFILE))
    {
        ret = avio_open(&this->ic->pb, rtspUrl.c_str(), AVIO_FLAG_WRITE);
    }
    ret = avformat_write_header(this->ic, NULL);
    memset(&this->pack, 0, sizeof(this->pack));
    vpts = 0;
    this->console_log("[INFO]视频播放地址:rtsp://10.25.10.70/ai_video/" + this->_sobj->play_token);
}

void video_push::on_stop_video_play()
{
}

void video_push::on_ffmpeg_send_frame(cv::Mat color_image)
{       
    int ret ;
    uint8_t *indata[AV_NUM_DATA_POINTERS] = { 0 };
    indata[0] = color_image.data;
    int insize[AV_NUM_DATA_POINTERS] = { 0 };
    insize[0] = color_image.cols * color_image.elemSize();
    int h = sws_scale(this->vsc, indata, insize, 0, color_image.rows,  this->yuv->data, this->yuv->linesize);
    if (h <= 0) return ;
    yuv->pts = vpts;
    vpts++;
    ret = avcodec_send_frame(this->vc, this->yuv);
    if (ret != 0) return;
    ret = avcodec_receive_packet(this->vc, &this->pack);
    if (ret != 0 || this->pack.size > 0){
        // cout << "pack size :" << this->pack.size << endl;
    }
    else return ;
    this->pack.pts = av_rescale_q(this->pack.pts, this->vc->time_base, this->vs->time_base);
    this->pack.dts = av_rescale_q(this->pack.dts, this->vc->time_base, this->vs->time_base);
    this->pack.duration = av_rescale_q(this->pack.duration, this->vc->time_base, this->vs->time_base);
    ret = av_interleaved_write_frame(this->ic, &this->pack); 
    
}

/*
cv::String text = "[流ID]:" + this->_sobj->play_token;
cv::Point  text_pt = cv::Point(1100,1035);
cv::Scalar text_color = cv::Scalar(0,0,255);
cv::putText(tmp_frame->cv_frame,text,text_pt,FONT_HERSHEY_SIMPLEX ,0.8,text_color,2.3);
*/