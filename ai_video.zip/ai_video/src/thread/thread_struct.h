/*
 * @Author: SudemQaQ
 * @Date: 2024-01-17 19:42:33
 * @email: mail@szhcloud.cn
 * @Blog: https://blog.szhcloud.cn
 * @github: https://github.com/sang8052
 * @LastEditors: SudemQaQ
 * @LastEditTime: 2024-02-01 14:38:53
 * @Description: 
 */
#pragma once
#include <string>
#include "opencv2/opencv.hpp"


using namespace std;

// 子线程对象
struct sys_thread {
    int thread_id;
    void *th_object;
    string thread_name;
    string object_type;
    sys_thread *next;
    sys_thread *last;
};

// yolo 处理结果的二次封装
struct yolo_result{
    float left;
    float top;
    float right;
    float bottom;
    float confidence;
    int  label;
    string label_text;
    
};

// 视频帧对象 
struct frame_obj{
    int frame_id = -1;
    cv::Mat cv_frame ;
    // 是否需要计算
    bool need_handle = false;
    // 计算的结果
    vector<yolo_result> handle_result;
    long create_time = -1;
    long handle_time = -1;
    frame_obj *next = nullptr;
    

  
};

// 视频流对象
struct stream_obj {
    int  stream_id;
    int  pull_thread_id;
    int  push_thread_id;
    int  ai_thread_id;
    // 是否需要播放
    bool need_play = false;
    // 视频播放的地址
    string play_token;
    string stream_url;
    frame_obj *frames = nullptr;
    stream_obj *last;
    stream_obj *next;
    bool is_ai_result_cache = false;
    vector<yolo_result> ai_result_cache;

};