#include "video_ai.h"

video_ai::video_ai(tools *tools, config *config, conn *conn)
{
    this->_tools = tools;
	this->_config = config;
	this->_conn = conn;
    this->thread_id = 9;

}

void video_ai::set_video_config(stream_obj *sobj)
{
    this->_sobj = sobj;
}


void video_ai::set_default_param(yoloUtils::InitParameter &initParameters)
{
    initParameters.class_names = yoloUtils::dataSets::coco80;
	initParameters.num_class = 80;
	initParameters.batch_size = 8;
	initParameters.dst_h = 640;
	initParameters.dst_w = 640;
	initParameters.input_output_names = { "images",  "output0" };
	initParameters.conf_thresh = 0.25f;
	initParameters.iou_thresh = 0.45f;
	initParameters.save_path = DIR_TMP_PATH;
}

bool video_ai::init_yolo_model(string model_path,int height,int width)
{
   
    set_default_param(this->param);
    this->param.dst_h = this->param.dst_w = 640;
    this->param.batch_size = 1;
    this->param.src_h = height;
    this->param.src_w = width;
    this->console_log("[LOG]模型渲染尺寸:" + to_string(height) + "," + to_string(width));
    this->yolo = new YOLOV8( this->param);
    this->console_log("[LOG]加载模型文件:" + model_path);
    std::vector<unsigned char> trt_file = yoloUtils::loadModel(model_path);
    if(trt_file.empty()) { this->console_log("[ERROR] 模型文件不存在!"); return false;}
    if(!yolo->init(trt_file))  { this->console_log("[ERROR] 加载模型文件的过程中发生错误!"); return false;}
    this->yolo->check();
    this->console_log("[INFO]AI 分析模型准备就绪...");
}

void video_ai::operator()(int _thread_id)
{
    this->thread_id = _thread_id;
	this->console_log("[LOG]启动AI分析模型线程,thread_id:" + to_string( this->thread_id ));
    int last_frame_id = 0;


    while (true)
    {
        if(this->_sobj->frames!=nullptr)
        {
            // 始终保留 当前的frames 链表中 至少存在两个节点
            if(this->_sobj->frames->next!= nullptr){
              
                frame_obj *tmp_frame = this->_sobj->frames;
                if(tmp_frame->need_handle && last_frame_id != tmp_frame->frame_id){
                    last_frame_id = tmp_frame->frame_id;
                    try{
                        tmp_frame->handle_result =  this->cuda_yolo_result(tmp_frame->cv_frame);
                        this->_tools->draw_yolo_result(tmp_frame->cv_frame,tmp_frame->handle_result);
                        this->_sobj->ai_result_cache = tmp_frame->handle_result;
                        this->_sobj->is_ai_result_cache = true;
                        tmp_frame->handle_time = this->_tools->get_ms_timestamp();
                    }
                    catch(...){
                        // 把这帧错误的图片保存下来
                        //string imgpath = "exception_" + to_string(tmp_frame->frame_id) + "_" + to_string(this->_tools->get_ms_timestamp()) + ".jpg";
                        //cv::imwrite(imgpath,tmp_frame->cv_frame);
                        //this->_tools->console_log("[WARNING]AI在处理第[" + to_string( last_frame_id) + "]数据时发生错误",this->thread_id);
                        tmp_frame->need_handle = false;
                        tmp_frame->handle_time = this->_tools->get_ms_timestamp();
                    }
                }
            }
        }

    }
    
}

void video_ai::cuda_yolo_save_img(std::vector<cv::Mat> &imgsBatch,string img_uuid)
{
    yoloUtils::DeviceTimer d_t0; this->yolo->copy(imgsBatch);	      float t0 = d_t0.getUsedTime();
	yoloUtils::DeviceTimer d_t1; this->yolo->preprocess(imgsBatch);  float t1 = d_t1.getUsedTime();
	yoloUtils::DeviceTimer d_t2; this->yolo->infer();				  float t2 = d_t2.getUsedTime();
	yoloUtils::DeviceTimer d_t3; this->yolo->postprocess(imgsBatch); float t3 = d_t3.getUsedTime();
	yoloUtils::save(this->yolo->getObjectss(), param.class_names, param.save_path, imgsBatch,img_uuid);
    this->console_log("[INFO]模型输出文件已经保存到path:" + this->_tools->get_root_path() + "/data/tmp/" + img_uuid + ".jpg" );
    this->yolo->reset();
}

vector<yolo_result> video_ai::cuda_yolo_result(cv::Mat frame)
{
    std::vector<cv::Mat> imgs_batch;
    imgs_batch.reserve(this->param.batch_size);
    imgs_batch.emplace_back(frame.clone());
    this->yolo->copy(imgs_batch);
    this->yolo->preprocess(imgs_batch);
    this->yolo->infer();	
    this->yolo->postprocess(imgs_batch);
    vector<vector<yoloUtils::Box>> boxs = this->yolo->getObjectss();
    vector<yolo_result> results = this->create_yolo_result(boxs[0]);
    this->yolo->reset();
    imgs_batch.clear(); 
    return results;        
}


vector<yolo_result> video_ai::create_yolo_result(vector<yoloUtils::Box> box)
{
    vector<yolo_result> result;
    for(int i=0;i<box.size();i++){
        yolo_result yres;
        yres.top = box[i].top;
        yres.left = box[i].left;
        yres.bottom = box[i].bottom;
        yres.right = box[i].right;
        yres.confidence = box[i].confidence;  
        yres.label = box[i].label;
        yres.label_text =  param.class_names[yres.label] + " " + cv::format("%.4f", yres.confidence);
        result.emplace_back(yres);
    }
    return result;
}

void video_ai::test_ai_opencv(string input_img, string img_uuid)
{
    cv::Mat frame;
    std::vector<cv::Mat> imgs_batch;
    cout << "this->param.batch_size:" << this->param.batch_size<< endl;
	imgs_batch.reserve(this->param.batch_size);
    this->console_log("[LOG]读取测试用的图片数据,path:" + input_img);
   
    frame = cv::imread(input_img);
    if(frame.empty()) this->console_log("[ERROR] 读取输入的图片数据失败...");
    else{
        

        imgs_batch.emplace_back(frame.clone());
        this->console_log("[LOG]读取图片成功");
        cuda_yolo_save_img(imgs_batch,img_uuid);
		imgs_batch.clear(); 

        vector<yolo_result> results  =  this->cuda_yolo_result(frame);
        this->_tools->draw_yolo_result(frame,results);
        this->console_log("[LOG]绘制识别结果,共" + to_string(results.size()) + "个目标");
        string imgname = img_uuid + "_new" + ".jpg";
        string imgpath = DIR_TMP_PATH + imgname;
        cv::imwrite(imgpath , frame);
        std::cout << "save new path:" << imgpath << std::endl;
    }
}

void video_ai::console_log(string log)

{
    this->_tools->console_log(log, this->thread_id);
}

