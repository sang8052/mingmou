/*
 * @Author: SudemQaQ
 * @Date: 2024-01-18 10:54:55
 * @email: mail@szhcloud.cn
 * @Blog: https://blog.szhcloud.cn
 * @github: https://github.com/sang8052
 * @LastEditors: SudemQaQ
 * @LastEditTime: 2024-01-18 13:15:56
 * @Description: 
 */

#pragma once
#include <iostream> 
#include <vector>
#include <mutex>
#include "string"
#define K_APP_NAME "MinMou"
#define K_APP_VERSION "1.0.1"
#define K_APP_BRANCH "DEBUG"

#define HTTP_HOOK_BEFORE 0
#define HTTP_HOOK_AFTER  1
#define HTTP_HOOK_TEST   2

// HTTP 会话 session 的有效时间 
#define HTTP_SESSION_EXPIRE 1800
// 超级token 
#define HTTP_SESSION_SUPER_TOKEN "56e4e6c3-48e1-4710-b92b-0c443090b3be"
// 文件token 的默认过期时间
#define HTTP_FILEDOWNLOAD_EXPIRE 60 * 15 
// 文件流一次读取的字节数
#define FILE_READ_BUFFER 524288
// 临时文件文件夹目录地址
#define DIR_TMP_PATH "./data/tmp"

// 人脸识别的最小人脸比例
#define FACE_MAX_NUM 32
// 人脸位置提取图片存放地址
#define FACE_RESULT_PATH "./data/result/face_position/"
// 人脸框线配置项
#define FACE_RESULT_FONT_SIZE 1.5
#define FACE_RESULT_COLOR 0,0,255
#define FACE_RESULT_COLOR 0,0,255



using namespace std;

extern std::mutex console_lock;
extern const string APP_VERSION;
extern const string APP_AUTHOR_MAIL;
extern const string APP_AUTHOR;
extern const vector <vector<string>> APP_LIBS;

#define IS_DEBUG  1

#define USE_YOLO_FRAME 1
#define USE_STREAM_THREAD 1

class video_props {

	/*
	CAP_PROP_POS_MSEC
	CAP_PROP_POS_FRAMES
	CAP_PROP_FRAME_WIDTH
	CAP_PROP_FRAME_HEIGHT
	CAP_PROP_FPS
	*/
public:

	// 视频文件的位置 单位毫秒
	int pos_msec;
	// 视频流的帧 相对于0的索引值
	int pos_frames;
	// 帧的宽度
	int frame_width;
	// 帧的高度
	int frame_height;
	// 视频帧率信息
	int fps;

};


enum Det {
    tl_x = 0,
    tl_y = 1,
    br_x = 2,
    br_y = 3,
    score = 4,
    class_idx = 5
};

constexpr float kConfThreshold = 0.4;
constexpr float kIouThreshold = 0.6;

#if !defined (K_APP_VERSION)
const char kAppVersion[] = K_APP_VERSION;
#else
const char kAppVersion[] = "MingMou DEBUG Version";
#endif



