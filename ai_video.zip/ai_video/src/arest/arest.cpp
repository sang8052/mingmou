#include "arest.h"




arest::arest(void* th_pools,int thread_id,string config_path,http_content_type *p_ctype)
{
	this->_tools = new tools();
	this->_config = new config(config_path);
	this->_config->load_config();
	this->_conn = new conn(this->_config);
	this->_conn->connect_db(false);
	this->p_ctype = p_ctype;
	this->thread_id = thread_id;
	this->_th_pools = th_pools;

	// 是否开启套接字多路复用
	this->options["reuse_addr"] = 1;
	// socket 并行监听的最大线程数
	this->options["listen_num"] = 8;
	// socket 一次性接收的数据包大小 默认为 64 K
	this->options["buffer_size"] = 64 * 1024;
	// socket 线程数量
	this->options["thread_nums"] = this->_config->get_int_value("app", "APP_API_THREADS", 8);

}



bool arest::bind_socket(int socket_fp, int server_port, string server_host)
{
	struct sockaddr_in server_addr;

	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(server_port);
	server_addr.sin_addr.s_addr = inet_addr(server_host.c_str());

	int reuse_addr = this->options["reuse_addr"].asInt();
	if (reuse_addr == 1) setsockopt(socket_fp, SOL_SOCKET, SO_REUSEADDR, &reuse_addr, sizeof(reuse_addr));

	if (bind(socket_fp, (struct  sockaddr*)&server_addr, sizeof(server_addr)) != 0) {
		this->_tools->console_log("[ERROR]监听TCP SOCKET[" + this->_tools->get_ip_socketaddr(&server_addr) + "]失败,error:" + strerror(errno));
		return false;
	}
	else {
		this->console_log("[INFO]开始监听TCP SOCKET[" + this->_tools->get_ip_socketaddr(&server_addr) + "]");
		return true;
	}

}

void arest::listen_socket(int socket_fp)
{
	this->listen_status = true;

	int s = listen(socket_fp, this->options["listen_num"].asInt());
	while (this->listen_status)
	{
		struct  sockaddr_in session_addr;
		socklen_t addr_length = sizeof(struct  sockaddr_in);
		int session_fp = accept(socket_fp, (sockaddr*)&session_addr, &addr_length);
		if (session_fp != -1) {
			this->on_socket_accpet(session_fp, &session_addr);
		}
	}
}

void arest::on_socket_accpet(int session_fp,sockaddr_in *session_addr)
{
	int child_id = this->find_free_threadid();
	while (child_id  == -1)
	{
		// 等待 1 ms 
		usleep(1000);
		child_id = this->find_free_threadid();
	}
	// 实例化一个 socket_session 线程对象
	session_params* sp = new session_params();
	sp->thread_id = this->thread_id;
	sp->child_id = child_id;
	sp->socket_fp = session_fp;
	sp->session_addr = session_addr;
	sp->_tools = this->_tools;
	sp->_config = this->_config;
	sp->_conn = this->_conn;
	sp->options = this->options;
	sp->_rnode = this->_rnode;
	sp->th_pools =this->_th_pools;
	sp->p_ctype = this->p_ctype;

	socket_session session = socket_session(sp,this->route_list,this->hook_list,&this->busy_thread_ids,&this->socket_threads);
	std::thread th(session, child_id);
	th.detach();
	this->socket_threads.push_back(&th);
}


int arest::http_route_register(string route_path, string method,string func, http_callback callback)
{
	method = this->_tools->str_upper(method);
    for(int i=0;i<this->route_list.size();i++){
		http_route hroute = this->route_list[i];
		if(hroute.route_path == route_path && hroute.method == method ) {
			this->console_log("[WARNING]路由[path:" + route_path + ",method:" +  method +  "]已经存在");
			return -1;
		}
	}
	int route_id = this->route_list.size();
	http_route nroute;
	nroute.route_path = route_path; nroute.method = method;nroute.callback = callback; nroute.route_id = route_id; nroute.callback_func = func;
	this->route_list.push_back(nroute);
	this->console_log("[LOG]路由[route_id:"+to_string(route_id)+",path:"+route_path + ",method:" + method + ",func:" +  func +  "]注册成功");
	return route_id;
}

void arest::http_hook_register(string hook_name, http_hookfunc hook)
{	
	http_hook nhook;
	nhook.hook_name = hook_name; nhook.hook_func = hook;
	this->hook_list.push_back(nhook);	
}

// 初始化 r3 的路由tree 
void arest::init_route_tree()
{
	int size = this->route_list.size();
	this->_rnode = r3_tree_create(size);
	for(int i=0;i<this->route_list.size();i++){
		http_route hroute = this->route_list[i];
		r3_tree_insert_routel(this->_rnode,this->_tools->http_method(hroute.method),hroute.route_path.c_str(),strlen(hroute.route_path.c_str() ),&this->route_list[i]);
	}
	char* errstr;
	int err = r3_tree_compile(this->_rnode,&errstr);
	if (err != 0) {
		string error; error = errstr;
		free(errstr);
        this->console_log("[ERROR]HTTP路由初始化失败,error:" + error);     
    }
	else this->console_log("[INFO]HTTP路由初始化成功");
}

void arest::start_server()
{
	this->init_route_tree();


	string server_host = this->_config->get_string_value("app", "APP_HOST", "0.0.0.0");
	int server_port = this->_config->get_int_value("app", "APP_PORT", 8081);

	this->http_socket = socket(AF_INET, SOCK_STREAM, 0);
	bool bind = this->bind_socket(this->http_socket, server_port, server_host);
	if (bind) this->listen_socket(this->http_socket);

}



void arest::set_options(string option_name, int option_value)
{
	 this->options[option_name] = option_value;
}

int arest::get_options(string option_name )
{
	vector <string> options_names = this->options.getMemberNames();
	if (this->_tools->in_list(options_names, option_name)) return this->options[option_name].asInt();
	else return -1;
}




int arest::find_free_threadid()
{
	for (int i = 1; i <= this->options["thread_nums"].asInt(); i++) {
		if (!this->_tools->in_list(this->busy_thread_ids, to_string(i))) {
			this->busy_thread_ids.push_back(to_string(i));
			return i;
		}
	}
	return -1;
}

void arest::console_log(string log)
{
	this->_tools->console_log(log, this->thread_id,0);
}


