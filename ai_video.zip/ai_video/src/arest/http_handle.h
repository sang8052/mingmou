#pragma once
#include <string>
#include "json/json.h"

#include "socket_handle.h"
#include "arest_struct.h"
#include "arest_handle.h"

#include <cstdlib>
#include <cstring>



using namespace std;

class http_handle {

private:
	
	
	socket_handle* _socket;
	vector <http_route> route_list;
	vector <http_hook>  hook_list;


	long    request_start_time;
	string  request_id;

	vector <string> socket_buffer_lines;
	string socket_request_buffer;
	int socket_body_line_id = 0;
	int request_header_length;

	http_header* request_header;
	Json::Value  request_data_body;
	Json::Value  request_data_query;
	Json::Value  request_data_route;

	vector <string> tmp_upload_files;

	http_header* http_read_header();
	void http_read_body();
	void http_before_route_handle();
	void http_route_handle();
	void http_after_route_handle();
	bool http_hook_handle(string hook_name);

	Json::Value http_parse_query(string query_string);
	Json::Value http_parse_formdata();

	string http_response_body();

	
public:
	session_params *_sp;
	http_header* response_header;

	string 	 response_body;
	string	 response_file_path;
	string   response_file_name;
	bool     response_file = false;
	// 		 请求结束后删除文件
	bool     response_file_remove =  false;
	//       是否允许断点续传
	bool 	 response_allow_range_response = true;
	int 	 response_file_range_start = 0;
	int	 	 response_file_range_end =  -1;
	
	bool http_route_pass = false;

	string request_session_key;
	Json::Value request_session;
	string request_access_token;

	http_handle(socket_handle* socket, session_params* sp,vector <http_route> route_list,vector <http_hook> hook_list);
	
	string get_client_ip();
	string get_user_agent();
	string get_request_id();
	http_header* get_http_header();
	Json::Value get_http_request_body();
	Json::Value get_http_request_query();
	Json::Value get_http_request_route();
	string get_content_type_byext(string ext);

	bool find_request_file_token(string token,Json::Value &file);



	void http_run();
	void console_log(string log);

};