#include "socket_handle.h"



socket_handle::socket_handle(session_params* sp)
{
	this->_sp = sp;
	this->socket_buffer = "";
	this->socket_length = 0;
	this->is_connect = true;

}



void socket_handle::console_log(string log)
{
	this->_sp->_tools->console_log(log, this->_sp->thread_id, this->_sp->child_id);

}

string socket_handle::socket_recv_data()
{
	int buffer_size = this->_sp->options["buffer_size"].asInt();
	char* tmp_buffer = (char*)malloc(buffer_size);
	int recv_length = recv(this->_sp->socket_fp, tmp_buffer, buffer_size, 0);
	this->buffer_size = recv_length;
	if(recv_length > 0){
		this->socket_length = this->socket_length + recv_length;
		this->socket_buffer = string(tmp_buffer,recv_length);
		delete[] tmp_buffer;
		tmp_buffer = nullptr;
		return this->socket_buffer;
	}
	if (recv_length == 0) this->is_connect = false;
	if (recv_length < 0 && errno != EINTR && errno != EWOULDBLOCK && errno != EAGAIN) this->is_connect = false;
	delete[] tmp_buffer;
	tmp_buffer = nullptr;
}

void socket_handle::socket_send_data(string response_data)
{
	string send_buffer;
	int pos = 0;
	int buffer_size = this->_sp->options["buffer_size"].asInt();

	while (response_data.size()!=0)
	{
		if (response_data.size() > buffer_size) pos = buffer_size;
		else pos = response_data.size();
		send_buffer = response_data.substr(0, pos);
		response_data = response_data.substr(pos, response_data.size()-pos);
		send(this->_sp->socket_fp, send_buffer.c_str(), send_buffer.size(), 0);
	}
}

void socket_handle::socket_send_bdata(ifstream &fp,long range_start,long range_end){

	long all_size = 0;
	long ps_start; long ps_end; long ps_last = 0; long ps_now;
	
	int ps_read;
	char buffer[FILE_READ_BUFFER];
	bzero(buffer,sizeof(buffer));

	fp.seekg(0,fp.end);
	all_size = fp.tellg();
	ps_start = range_start > 0 ? range_start : 0;
	ps_end = range_end < all_size ? (range_end > ps_start ? range_end : all_size) : all_size; 
	fp.seekg(0,fp.beg);
	if(ps_start!=0) fp.seekg(ps_start);
	ps_now = ps_start; ps_last = ps_start;
	long send_size = 0;
	while (ps_now < ps_end)
	{
		bzero(buffer,sizeof(buffer));
		int buffer_size = 0;
		if(ps_now + sizeof(buffer) > ps_end) buffer_size = ps_end - ps_now;
		else buffer_size = sizeof(buffer);
		fp.read(buffer,buffer_size);
		ps_now = fp.tellg() < 0 ? all_size : (long)fp.tellg();
		ps_read = ps_now - ps_last;
		send(this->_sp->socket_fp,buffer, ps_read,0);
		send_size = send_size + ps_read;
		ps_last = ps_now;
	}
	fp.close();
	string end_buffer = "\r\n";
	send(this->_sp->socket_fp,end_buffer.c_str(),end_buffer.size(),0);
}

void socket_handle::socket_send_data_ex(Json::Value response)
{
	string payload = this->_sp->_tools->json_encode(response);
	string msg = this->_sp->_tools->str_zfill(to_string(payload.length()),8) + ":" + payload;
	this->socket_send_data(msg);
}

int socket_handle::get_session_type()
{
	vector<string> tmps;
	tmps = this->_sp->_tools->explode(this->socket_buffer, "\r\n");
	if (tmps.size() >= 2) {
		string socket_header = tmps[0];
		if (this->_sp->_tools->str_include(socket_header, "HTTP/")) return SOCKET_TYPE_HTTP;
	}
	else return SOCKET_TYPE_JSON;
}

int socket_handle::socket_recv_length()
{
	return this->socket_length;
}

string socket_handle::socket_read_buffer()
{
	return this->socket_buffer;
}

void socket_handle::socket_run()
{
	string socket_data = "";
	int socket_data_length = 0;
	socket_data = this->socket_buffer;
	if(socket_data.substr(8,1) != ":"){
		this->console_log("[WARNING]无法从SOCKET 报文中读取报文长度！" );
		return ;
	}
	socket_data_length = atoi(socket_data.substr(0,8).c_str());
	while(socket_data.length() < socket_data_length + 9){
		this->socket_recv_data();
		if(this->buffer_size > 0) socket_data = socket_data + this->socket_buffer;
	}
	Json::Value payload;
	try{
		payload = this->_sp->_tools->json_decode(socket_data.substr(9));
		if(payload["topic"].asString() == "arc_soft"){
			if(payload["action"].asString() == "detect_faces") this->arc_soft_detect_faces(payload["data"],payload["msg_id"].asString());
		}
	}
	catch(...){this->console_log("[WARNING]无法解析的SOCKET报文!");return;}
}

void socket_handle::arc_soft_detect_faces(Json::Value data,string msg_id)
{
	string decode_img = this->_sp->_tools->str_base64_decode(data["img"].asString());
	std::vector<uchar> img_data(decode_img.begin(), decode_img.end());
	cv::Mat image = cv::imdecode(img_data, cv::IMREAD_COLOR);
	arc_soft *asoft = new arc_soft(this->_sp->_tools,this->_sp->thread_id,this->_sp->child_id);
    Json::Value faces = asoft->get_face_postion_cv(image);
	Json::Value payload; 
	payload["action"] = "result_detect_faces"; payload["topic"] = "arc_soft";
	payload["data"] = faces ; payload["msg_id"] = msg_id;
	this->socket_send_data_ex(payload);
}
