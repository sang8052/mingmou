
#pragma once
#include <string>
#include "json/json.h"

#include "../extend/tools.h"
#include "../extend/config.h"
#include "../extend/conn.h"


// socket 的头文件
#include "sys/socket.h"
#include <netinet/in.h>
#include "arpa/inet.h"

#include <thread>

#include "arest_struct.h"
#include "socket_session.h"

#include "../api/load.h"
#include "arest_handle.h"
#include "r3.h"


/*
	arest 框架主类
	用于实例化一个 arest 服务对象
*/

class arest
{
	private:
		tools* _tools;
		config* _config;
		conn* _conn;
		void* _th_pools;
		R3Node *_rnode;

		Json::Value options;
		vector<std::thread *> socket_threads;
		vector<string> busy_thread_ids;
		int thread_id;
		bool bind_socket(int socket_fp, int server_port , string server_host);
		void listen_socket(int socket_fp);
		void on_socket_accpet(int session_fp, sockaddr_in* session_addr);
		int  find_free_threadid();
		void console_log(string log);
		int http_socket;
		vector <http_route> route_list;
		vector <http_hook>  hook_list;
		bool running;
		http_content_type *p_ctype;
		MHandle* handle;
		//std::mutex socket_lock;


	public:
		bool listen_status;
		arest(void *th_pools,int thread_id,string config_path,http_content_type *p_ctype);
		void set_options(string option_name, int option_value);
		int  get_options(string option_name);
		int  http_route_register(string route_path,string method,string func,http_callback callback);
		void http_hook_register(string hook_name,http_hookfunc hook);
		void init_route_tree();
		void start_server();

};