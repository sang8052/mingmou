#include "http_handle.h"

http_handle::http_handle(socket_handle* socket, session_params* sp,vector <http_route> route_list,vector <http_hook> hook_list)
{
	this->_sp = sp;
	this->_socket = socket;
	this->hook_list = hook_list;
	this->route_list = route_list;
	this->http_hook_handle("http_create_handle");
	this->socket_request_buffer = this->_socket->socket_read_buffer();
	this->socket_buffer_lines = this->_sp->_tools->explode(this->socket_request_buffer,"\r\n");
}


http_header*  http_handle::http_read_header()
{
	vector<string> tmps;
	this->request_header = new http_header();
	this->request_header->remote_addr = inet_ntoa(this->_sp->session_addr->sin_addr);
	this->request_header->remote_port = this->_sp->session_addr->sin_port;
	

	// 读取首航的 请求类型,请求url,请求协议类型信息
	tmps =this->_sp->_tools->explode(this->socket_buffer_lines[0]," ");
	this->request_header->request_method = this->_sp->_tools->str_upper(this->_sp->_tools->str_trim(tmps[0]));
	this->request_header->request_url = this->_sp->_tools->str_trim(tmps[1]);
	this->request_header->server_protocal = this->_sp->_tools->str_trim(tmps[2]);
	if (this->_sp->_tools->str_include(this->request_header->request_url, "?")) {
		tmps = this->_sp->_tools->explode(this->request_header->request_url, "?", 1);
		this->request_header->document_url = this->_sp->_tools->str_trim(tmps[0]);
		this->request_header->query_string = this->_sp->_tools->str_trim(tmps[1]);
	}
	else this->request_header->document_url = 	this->request_header->request_url;

	// 读取自定义的 头部信息
	Json::Value custom_header;
	int line_id = 1;
	for(line_id; line_id < socket_buffer_lines.size() ; line_id++){
		string tmp_line = socket_buffer_lines[line_id];
		//cout << "[" << line_id << "]" << tmp_line << endl;
		if(tmp_line.size() == 0) {this->socket_body_line_id = line_id + 1; break;}
		else{
				tmps = this->_sp->_tools->explode(tmp_line,":",1);
				if (tmps.size() == 2) {
					string key = this->_sp->_tools->str_lower(this->_sp->_tools->str_trim(tmps[0]));
					string value = this->_sp->_tools->str_trim(tmps[1]);
					custom_header[key] = value;
					if (key == "content-type")	 {
						this->request_header->content_type = this->_sp->_tools->str_lower(value);
						this->request_header->content_type_origin = value;
					}
					if (key == "content-length") this->request_header->content_length = atoi(value.c_str());
					if (key == "authorization")  this->request_header->authorization = value;
					if (key == "host")			 this->request_header->request_host = value;
					if (key == "user-agent")     this->request_header->user_agent = value;
					if (key == "accpet")         this->request_header->accept = value;
					if (key == "referer")        this->request_header->referer = value;
					if (key == "range")			 this->request_header->range = value;
				}
		}
	}
	
	this->request_header->custom_header = custom_header;
	request_data_query = http_parse_query(this->_sp->_tools->url_decode(this->request_header->query_string));
	this->http_hook_handle("http_request_header_handle");
	return this->request_header;

}

void http_handle::http_read_body()
{
	// 获取请求头部中,http boday 以外的数据的总长度
	vector<string> tmps =  this->_sp->_tools->explode(this->socket_request_buffer,"\r\n\r\n",1);
	this->request_header_length = tmps[0].size() + 4;
	this->socket_request_buffer = tmps[1];
	// 处理 application/json 和 application/x-www-form-urlencoded 提交的数据
	//cout << "content_length 长度:" << this->request_header->content_length << endl;
	if (!this->_sp->_tools->str_include(this->request_header->content_type, "multipart/form-data")){

	    // 当数据没有接收完成时 循环接收数据
		while (this->_socket->socket_recv_length() - request_header_length < this->request_header->content_length)
		{
			this->socket_request_buffer =  this->socket_request_buffer + this->_socket->socket_recv_data();	
		}
		// application/json
		if (this->_sp->_tools->str_include(this->request_header->content_type, "application/json"))
			request_data_body = this->_sp->_tools->json_decode(this->socket_request_buffer);

		// application/x-www-form-urlencoded
		else if (this->_sp->_tools->str_include(this->request_header->content_type, "application/x-www-form-urlencoded"))
			request_data_body = http_parse_query(this->_sp->_tools->url_decode(this->socket_request_buffer));

	}
	
	else if (this->_sp->_tools->str_include(this->request_header->content_type, "multipart/form-data")){
		request_data_body = this->http_parse_formdata();
	}
			
	this->http_hook_handle("http_request_body_handle");
	
}


Json::Value http_handle::http_parse_query(string query_string)
{
	Json::Value query;
	vector<string> tmps;

	if (query_string != "") {
		vector<string> querys = this->_sp->_tools->explode(query_string, "&");
		for (int i = 0; i < querys.size(); i++) {
			string item = querys[i];
			tmps = this->_sp->_tools->explode(item, "=");
			string key; string value;
			if (tmps.size() == 2) {
				key = this->_sp->_tools->str_trim(tmps[0]);
				value = this->_sp->_tools->str_trim(tmps[1]);
			}
			else {
				key = this->_sp->_tools->str_trim(tmps[0]);
				value = "";
			}
			query[key] = value;
		}
	}
	return query;
}


Json::Value http_handle::http_parse_formdata()
{

	vector <string> tmps;	vector <string> tmp_lines; 	vector <string> t;
	Json::Value params = Json::arrayValue;Json::Value param; 
	string key; string value; int id = 1; int pid=0;  bool init = true;
	string content_data = "";

	tmps = this->_sp->_tools->explode(this->request_header->content_type_origin, "boundary=", 1);
	string boundary = "--" + tmps[1];
	string boundary_end = boundary + "--";
	while (this->_socket->socket_recv_length() - request_header_length < this->request_header->content_length)
	{
		
		if(!init) { id = 0; this->socket_request_buffer =   this->_socket->socket_recv_data(); } else  init = false;
		tmp_lines = this->_sp->_tools->explode(this->socket_request_buffer,"\r\n");
		

		if(tmp_lines.size() == 1) content_data = content_data + this->socket_request_buffer;
		else{
			for(id;id < tmp_lines.size(); id++){
				if(tmp_lines[id] == boundary || tmp_lines[id] == boundary_end){
					content_data = content_data.substr(0,content_data.size()-2);
					if(param["content_type"].asString() == "text") param["content_body"] = content_data;
					else{
						string tmp_upload_prefix = "tmpupload_";
						param["content_file_path"] = DIR_TMP_PATH + tmp_upload_prefix  + this->_sp->_tools->get_uuid();
						this->_sp->_tools->g_console_log("[DEBUG]写入数据到临时文件,大小" + to_string(content_data.size()) +  ",临时路径:" +  param["content_file_path"].asString());
						if(!this->_sp->_tools->exist_file(DIR_TMP_PATH)) this->_sp->_tools->create_folder(DIR_TMP_PATH);
						this->_sp->_tools->write_file_binary(param["content_file_path"].asString(),content_data);
						this->tmp_upload_files.push_back(param["content_file_path"].asString());
					}	
					params.append(param);
					pid = 0; content_data = "";
					param["content_body"] = "";
					param["content_file_path"] = "";
					param["content_disposition"] = Json::nullValue;
					param["content_type"] = "";
					if(tmp_lines[id] == boundary_end) break;
				}
				else{
					
					if(pid == 0) {
						tmps = this->_sp->_tools->explode(this->_sp->_tools->str_replace(tmp_lines[id], "Content-Disposition: form-data;", ""), ";");
						
						for (int k = 0; k < tmps.size(); k++) {
							string item = tmps[k];
							t = this->_sp->_tools->explode(this->_sp->_tools->str_trim(item), "=", 1);
							key =  this->_sp->_tools->str_trim(t[0]);
							t[1] = this->_sp->_tools->str_trim(t[1]);
							string value; string utf8 = "UTF-8";
							if(t[1].substr(0,5) == utf8) value = t[1];
							else value = t[1].substr(1,t[1].size() - 2);
							param["content_disposition"][key] = value;
						}
					}
					else if(pid == 1){
						if(tmp_lines[id].size() == 0) param["content_type"] = "text";
						else {
							param["content_type"] = this->_sp->_tools->str_trim(this->_sp->_tools->explode(tmp_lines[id], ":", 1)[1]);
							pid = pid + 1 ; id = id + 1 ;
						}
					}
					else {
						if(id != tmp_lines.size() - 1) tmp_lines[id] = tmp_lines[id] + "\r\n";
						content_data = content_data + tmp_lines[id];
					}
					pid = pid + 1;
				}			
			}
			
		}
	}
	return params;
}



void http_handle::http_route_handle()
{

	this->console_log("[DEBUG]请求的[document_url]:" + this->request_header->document_url);
	this->console_log("[DEBUG]请求的[request_url]:" + this->request_header->request_url);
	this->console_log("[DEBUG]请求的[method]:" + this->request_header->request_method);


	match_entry * entry;
    R3Route *matched_route;
	entry = match_entry_create( this->request_header->document_url.c_str());
	entry->request_method = this->_sp->_tools->http_method(this->request_header->request_method);
  	matched_route = r3_tree_match_route(this->_sp->_rnode, entry);
	if(matched_route) {
		for(int i= 0; i< entry->vars.tokens.size; i++){
			string name  = entry->vars.slugs.entries[i].base;
			name = name.substr(0, entry->vars.slugs.entries[i].len);
			string value =  entry->vars.tokens.entries[i].base;
			value = value.substr(0, entry->vars.tokens.entries[i].len);
			this->request_data_route[name] = value;
		}
		http_route *hroute = (http_route*)matched_route->data;
		this->console_log("[DEBUG]请求的[route_id]:" + to_string(hroute->route_id));
		this->console_log("[DEBUG]请求的[callback_func]:" + hroute->callback_func);
		this->http_hook_handle("http_find_route");
		try{
			hroute->callback(this);
		}
		catch(...){
			this->response_header->http_code = 500;
			this->response_header->http_msg = "Server Error";
			this->console_log("[DEBUG]触发未知异常");
			this->http_hook_handle("http_unknow_error");
		}
		
	}
	else {
		this->http_hook_handle("http_miss_route");
		this->response_header->http_code = 404;
		this->response_header->http_msg = "Not Found";
		this->console_log("[DEBUG]没有找到请求的路由");
	}
	match_entry_free(entry);
	

}

void http_handle::http_before_route_handle()
{
	this->request_start_time = this->_sp->_tools->get_ms_timestamp();
	this->request_id = this->_sp->_tools->get_uuid();
	this->response_header = new http_header();
	this->response_header->server_protocal = "HTTP/1.1";
	this->response_header->custom_header["x-request_id"] = this->request_id;
	this->response_header->http_code = 200;
	this->response_header->http_msg = "OK";
	this->response_header->content_type = "application/json; charset=utf-8";

	this->console_log("[LOG][" + this->request_header->request_method + "]:" + this->request_header->document_url
		+ " [client_ip:" + this->_sp->_tools->get_ip_socketaddr(this->_sp->session_addr) + "]"
		+ " [request_id:" + this->request_id + "]"
	);

	if(!this->http_hook_handle("http_before_route_handle")) this->http_route_pass = true;
	else this->http_route_pass = false;
	
} 



void http_handle::http_after_route_handle()
{
	// 计算执行时间
	this->response_header->custom_header["x-using_time"] = to_string( this->_sp->_tools->get_ms_timestamp() - this->request_start_time ) + " ms";
	this->response_header->custom_header["x-client_ip"] = this->get_client_ip();
	this->http_hook_handle("http_after_route_handle");
}

bool http_handle::http_hook_handle(string hook_name)
{
    for(int i=0;i<this->hook_list.size();i++){
		http_hook current = this->hook_list[i];
		if(current.hook_name == hook_name) {
			this->console_log("[DEBUG]执行HOOK 事件:" + hook_name);
			return current.hook_func(this);
		}
	}
	return true;
}

string http_handle::http_response_body()
{
	string response;
	
	
	// 目标暂不支持断点 续传
	// 处理 HTTP RANGE 请求
	bool is_response_range = false;
	if(this->response_header->http_code == 200 && this->response_allow_range_response && this->response_file){
		if(this->request_header->range !="") {
			if(this->_sp->_tools->str_include(this->request_header->range ,"bytes=")){
				is_response_range = true;
				string range = this->request_header->range.replace(this->request_header->range.find("bytes="),6,"");
				if(this->_sp->_tools->str_include(range ,"-")){
					vector<string> tmp = this->_sp->_tools->explode(range,"-",1);
					this->response_file_range_start = atoi(tmp[0].c_str());
					if(tmp.size() == 2)this->response_file_range_end= atoi(tmp[1].c_str());	
					
				}
				else this->response_file_range_start = atoi(range.c_str());	
			}	
			// 默认分片为 2M 
			if(this->response_file_range_end == 0 ) this->response_file_range_end =   this->response_file_range_start + 1024  * 1024 * 2;
			if(this->response_allow_range_response && is_response_range) {
				this->response_header->http_code = 206;
				this->response_header->http_msg = "Partial Content";
			}
		}
	}
	

	response = this->response_header->server_protocal + " " + to_string(this->response_header->http_code) + " " + this->response_header->http_msg + "\r\n";
	response = response + "Server: " + K_APP_NAME " " + APP_VERSION + "\r\n";
	response = response + "Date: " + this->_sp->_tools->format_gmt_current_time() + "\r\n";

	response = response + "Content-Type: " + this->response_header->content_type + "\r\n";

	
	if(this->response_file) {
		int response_file_size = this->_sp->_tools->get_file_size(this->response_file_path);
		string gmt_time = this->_sp->_tools->get_gmt_file_write_time(this->response_file_path);
		response = response + "Etag: " + this->_sp->_tools->str_hash_md5(this->response_file_path + gmt_time) + "\r\n";
		response = response + "Last-Modified: " + gmt_time + "\r\n";
		if(this->response_allow_range_response && is_response_range) {
			if(this->response_file_range_end >= response_file_size ) this->response_file_range_end = response_file_size ;
			else this->response_file_range_end = this->response_file_range_end + 1 ;
			response = response + "Content-Length: " + to_string(this->response_file_range_end - this->response_file_range_start + 1) + "\r\n";
			response = response + "Content-Range: bytes " + to_string(this->response_file_range_start) + "-" + to_string(this->response_file_range_end - 1) + "/" +  to_string(response_file_size) + "\r\n";
		}

		else {
			response = response + "Content-Length: " + to_string(response_file_size) + "\r\n";
		}
	}
	else response = response + "Content-Length: " + to_string(strlen(this->response_body.c_str())) + "\r\n";


	response = response + "Connection: keep-alive" + "\r\n";

	if(this->response_file_name!= "" && this->response_file){
		response = response + "Content-Disposition: keep-attachment;filename=" + this->response_file_name + "\r\n";
	}

	vector <string> super_header = { "date","content_type","content_length","server","connection" };
	vector <string> headers_keys = this->response_header->custom_header.getMemberNames();
	for (int i = 0; i < headers_keys.size(); i++) {
		string header_value = this->response_header->custom_header[headers_keys[i]].asString();
		string header_key = headers_keys[i];
		if (!this->_sp->_tools->in_list(super_header, this->_sp->_tools->str_lower(header_key))) {
			response = response + header_key + ": " + header_value + "\r\n";
		}
	}

	response = response +  "\r\n" ;
	if(this->response_file_path.size() == 0) response = response+  this->response_body + "\r\n";
	this->http_hook_handle("http_response_body_handle");
	return response;
}

string http_handle::get_content_type_byext(string ext)
{
	http_content_type *p = this->_sp->p_ctype;
	while (p->next!=nullptr)
	{
		if(p->ext == ext) return p->content_type;
		p = p->next;
	}
	return this->_sp->p_ctype->content_type;
	
}

bool http_handle::find_request_file_token(string token, Json::Value &file)
{
	Json::Value data; Json::Value response;
	  // 查询 文件是否已经过期了
    string config_key = this->_sp->_config->get_string_value("REDIS_KEY","KEY_FILE_DOWNLOAD","ai_video:file:download:") + token;
    if(!this->_sp->_conn->redis->exists(config_key)){
        data["token"] = token ; data["client_ip"] = this->get_client_ip(); data["user_agent"] = this->get_user_agent();
        response["code"] = 5000303; response["msg"] = "访问文件失败,token 不存在或者已经被删除";
        response["data"] = data;
        this->response_body = this->_sp->_tools->json_encode(response);
 		this->response_header->http_code = 404; 
        this->response_header->http_msg = "Not Found";    
        return false;
    }
    // 找到上传的临时文件信息 
     file = this->_sp->_tools->json_decode(*this->_sp->_conn->redis->get(config_key));
	// 如果文件的路径地址不存在 那么从数据库里查询最新的文件地址
	if(!this->_sp->_tools->exist_file(file["filepath"].asString())){
		ai_db *db = new ai_db(this->_sp->_conn,this->_sp->_config,this->_sp->_tools);
		Json::Value db_files = db->query_file_byid(file["id"].asInt());
		if(db_files.size() > 0){
			file["filepath"] = db_files[0]["filepath"];
			file["delete_expire"] = db_files[0]["delete_expire"];
		}
		// 如果数据库里没有这个文件记录 说明文件已经被删除
		else{
			this->_sp->_conn->redis->del(config_key);
			data["token"] = token ; data["client_ip"] = this->get_client_ip(); data["user_agent"] = this->get_user_agent();
        	response["code"] = 5000303; response["msg"] = "访问文件失败,文件已经被删除";
        	response["data"] = data;
        	this->response_body = this->_sp->_tools->json_encode(response);
        	this->response_header->http_code = 404; 
            this->response_header->http_msg = "Not Found";  
        	return false;
		}
		// 数据库中存在文件 磁盘上找不到文件 
		if(!this->_sp->_tools->exist_file(file["filepath"].asString())){
			data["token"] = token ; data["client_ip"] = this->get_client_ip(); data["user_agent"] = this->get_user_agent();
			data["file_id"] = file["id"].asInt(); data["filepath"] =  file["filepath"].asString();
			response["code"] = 5000301; response["msg"] = "访问文件失败,元数据不存在或已被删除";
            response["data"] = data; 
            this->response_body = this->_sp->_tools->json_encode(response);
            this->response_header->http_code = 404; 
            this->response_header->http_msg = "Not Found";  
            return false;
		}
		db->update_file_token(token,file["filepath"].asString(),file["delete_expire"].asInt());
	}
    this->console_log("[LOG]临时文件路径地址:" + file["filepath"].asString());
    return true;
}



void http_handle::console_log(string log)
{
	this->_sp->_tools->console_log(log, this->_sp->thread_id, this->_sp->child_id);
}

string http_handle::get_user_agent()
{
    return this->request_header->user_agent;
}

Json::Value http_handle::get_http_request_route()
{
    return this->request_data_route;
}


string http_handle::get_client_ip()
{
	vector<string> keys = this->request_header->custom_header.getMemberNames();
	vector<string> header_keys = { "remote_addr","x_forwarded_for","x_real_ip","x_client_ip" };
	for (int i = 0; i < header_keys.size(); i++) {
		if (this->_sp->_tools->in_list(keys, header_keys[i])) return this->request_header->custom_header[header_keys[i]].asString();
	}
	return this->request_header->remote_addr;
}

string http_handle::get_request_id()
{
    return this->request_id;
}

http_header *http_handle::get_http_header()
{
    return this->request_header;
}

Json::Value http_handle::get_http_request_body()
{
    return this->request_data_body;
}

Json::Value http_handle::get_http_request_query()
{
    return this->request_data_query;
}


void http_handle::http_run()
{
	// 解析当前会话的请求头部信息
	this->http_read_header();


	// 解析当前会话的请求body 信息
	this->http_read_body();

	// 执行请求前钩子
	this->http_before_route_handle();

	// 执行路由钩子
	if(!this->http_route_pass)this->http_route_handle();
	else this->console_log("[DEBUG]请求不需要匹配任何路由事件");

	// 执行请求结束后钩子
	this->http_after_route_handle();

	// 响应字符数据
	this->_socket->socket_send_data(this->http_response_body());

	// 如果本次响应中包含文件响应
	if(this->response_file && this->response_file_path != ""){
		//cout << "response file:" << this->response_file_path << ",start:" << this->response_file_range_start << ",end:" << this->response_file_range_end << endl;
		ifstream fp;
		fp.open(this->response_file_path,ios::in|ios::binary);
		this->_socket->socket_send_bdata(fp,this->response_file_range_start,this->response_file_range_end);
	}	

	// 删除本次请求过程中生成的临时文件
	for(int i=0;i < this->tmp_upload_files.size();i++ ){
		string tmp_file = tmp_upload_files[i];
		if(this->_sp->_tools->exist_file(tmp_file)) this->_sp->_tools->remove_file(tmp_file);
	}
	
	if(this->response_file_remove){
		this->_sp->_tools->remove_file(this->response_file_path);
	}


	
}
