#pragma once
#include <string>
#include "json/json.h"

#include "../extend/tools.h"
#include "../extend/config.h"
#include "../extend/conn.h"


#include "sys/socket.h"
#include <netinet/in.h>
#include "arpa/inet.h"

#include "r3.hpp"



#define SOCKET_TYPE_HTTP 1
#define SOCKET_TYPE_JSON 2
#define SOCKET_TYPE_BYTE 3

using namespace std;


// http 的请求头
struct http_header {
public:

	string remote_addr;
	int remote_port;

	int http_code;
	string http_msg;

	string request_method;
	string server_protocal;
	string request_url;
	string document_url;
	string query_string;


	string content_type;
	string content_type_origin;
	int content_length;
	string authorization;
	string request_host;
	string accept;
	string user_agent;
	string referer;
	string range;

	Json::Value custom_header;
};



// 链表指针 存放http 请求的ext => content-type 信息
struct http_content_type{
    string ext;
    string content_type;
    http_content_type *next;
};

// session 会话的参数
struct session_params {
	tools* _tools;
	conn* _conn;
	config* _config;
	R3Node *_rnode;
	int thread_id;
	int child_id;
	int socket_fp;
	sockaddr_in* session_addr;
	Json::Value options;
	http_content_type *p_ctype;
	void* th_pools;
};
