#pragma once
#include <string>
#include "json/json.h"


#include "sys/socket.h"
#include <netinet/in.h>
#include "arpa/inet.h"

#include "arest_struct.h"
#include "../extend/arc_soft.h"




class socket_handle{

	private:
		session_params* _sp;

		sockaddr_in* session_addr;
		// socket 接收的数据的缓冲区
		string  socket_buffer;
		// socket 已经接收的数据的长度
		int socket_length;
	
	public:
		bool is_connect = false;
		int buffer_size = 0;
		socket_handle(session_params *sp);
		void console_log(string log);

		// 接受来自客户端的数据
		string socket_recv_data();
		// 响应来自客户端的数据
		void socket_send_data(string response_data);
	    void socket_send_bdata(ifstream &fp,long range_start=0,long range_end=0);
		void socket_send_data_ex(Json::Value response);

		// 检查会话的类型
		int get_session_type();
		// 读取socket 已经接受的数据的长度
		int socket_recv_length();
		// 读取缓冲区中的数据
		string socket_read_buffer();

		// socket 直接处理对话的方法
		void socket_run();

		void arc_soft_detect_faces(Json::Value data,string msg_id);
	
};