#pragma once

#include "../api/load.h"

// 传入当前请求的 session_params , http_handle 的指针
typedef void(*http_callback)(void*);
typedef bool(*http_hookfunc)(void*);


class http_hook {
	public:
		string hook_name;
		http_hookfunc hook_func;
};

class http_route {
    public:
	int route_id;
	string route_path;
	string method;
	string callback_func;
	http_callback callback;
};