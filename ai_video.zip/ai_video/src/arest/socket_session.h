#include "../extend/tools.h"
#include "../extend/config.h"
#include "../extend/conn.h"

#include "sys/socket.h"
#include <netinet/in.h>
#include "arpa/inet.h"

#include "arest_struct.h"
#include "socket_handle.h"
#include "http_handle.h"
#include "arest_handle.h"


#include <thread>


class socket_session {
	private:
		
		session_params* _sp;
		socket_handle *_socket;
		http_handle *_http;
		vector<string>* _busy_thread_ids;
		vector<std::thread*>* _socket_threads;
		vector <http_route> route_list;
		vector <http_hook> hook_list;
		r3::Tree *_r3tree;
	

	public:
		socket_session(session_params* sp, vector<http_route>route_list,vector<http_hook>hook_list, vector<string> * busy_thread_ids , vector<std::thread*> * socket_threads);
		void release_thread_id(std::thread::id tid, int child_id);
		void console_log(string log);
		void operator()(int child_id);
		
};