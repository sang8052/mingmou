/*
 * @Author: SudemQaQ
 * @Date: 2024-02-01 14:07:52
 * @email: mail@szhcloud.cn
 * @Blog: https://blog.szhcloud.cn
 * @github: https://github.com/sang8052
 * @LastEditors: SudemQaQ
 * @LastEditTime: 2024-02-01 16:43:27
 * @Description: 
 */
#include "socket_session.h"

socket_session::socket_session(session_params *sp,vector<http_route>route_list,vector<http_hook>hook_list, vector<string> *busy_thread_ids, vector<std::thread*> *socket_threads)
{
	this->_sp = sp;
	this->_busy_thread_ids = busy_thread_ids;
	this->_socket_threads = socket_threads;
	this->route_list = 	route_list;
	this->hook_list = hook_list;
	this->console_log("[DEBUG]SOCKET 会话创建成功");

}

void socket_session::console_log(string log)
{
	this->_sp->_tools->console_log(log, this->_sp->thread_id, this->_sp->child_id);
}

// 子线程触发的函数
void socket_session::operator()(int child_id) {

	this->_socket = new socket_handle(this->_sp);
	this->_socket->socket_recv_data();
	try{
		int session_type = this->_socket->get_session_type();
		// 判断socket 会话的请求类型
		if (session_type == SOCKET_TYPE_HTTP) {
			this->console_log("[DEBUG]SOCKET 会话的上层会话类型为:HTTP");
			http_handle* http = new http_handle(this->_socket,this->_sp,this->route_list,this->hook_list);
			http->http_run();
			delete http;
		}
		else{
			this->console_log("[DEBUG]SOCKET 会话的上层会话类型为:SOCKET");
			while(this->_socket->is_connect){
				if(this->_socket->buffer_size > 0) this->_socket->socket_run();
				this->_socket->socket_recv_data();
			}
			this->console_log("[DEBUG]客户端关闭了会话!");
		} 
	}
	catch(...){this->console_log("[WARNING]会话通讯过程中发生未知异常!");}
	// socket handle 对象必须在 socket 会话被关闭前释放
	delete this->_socket;
	shutdown(this->_sp->socket_fp, 2);
	std::thread::id tid = std::this_thread::get_id();
	this->release_thread_id(std::this_thread::get_id(), this->_sp->child_id);
}



void socket_session::release_thread_id(std::thread::id tid, int child_id)
{
	int index = this->_sp->_tools->find_list_index(*this->_busy_thread_ids, to_string(child_id));
	(*this->_busy_thread_ids).erase((*this->_busy_thread_ids).begin() + index);

	for (int i = 0; i < (*this->_socket_threads).size(); i++) {
		std::thread* th = (*this->_socket_threads)[i];
		if (th->get_id() == tid) (*this->_socket_threads).erase((*this->_socket_threads).begin() + i);
	}
}