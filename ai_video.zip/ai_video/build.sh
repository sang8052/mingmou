###
 # @Author: SudemQaQ
 # @Date: 2024-01-18 11:07:32
 # @email: mail@szhcloud.cn
 # @Blog: https://blog.szhcloud.cn
 # @github: https://github.com/sang8052
 # @LastEditors: SudemQaQ
 # @LastEditTime: 2024-01-18 11:24:52
 # @Description: 编译脚本 
###  

cd ./build
cmake ..
make -j48
#cd ../bin && ./mingmou